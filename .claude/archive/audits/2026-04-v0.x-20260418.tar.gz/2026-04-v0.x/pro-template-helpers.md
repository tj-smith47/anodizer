# Pro feature: template helpers (`in` / `reReplaceAll`) and Pro variables

**Docs:** https://goreleaser.com/customization/templates/ (fetched 2026-04-18)
**Anodize site:** crates/core/src/template.rs:530-586 (`reReplaceAll` + `in`); context.rs:436-552 (`PrefixedTag`, `IsRelease`, `IsMerging`, `.Artifacts`, `.Metadata`)
**Status:** implemented

## Contract

**Helpers (Pro, v2.8+):**
- `in` — membership check: `{{ "foo" | in list }}` or `{{ in(value="foo", list=...) }}`
- `reReplaceAll` — regex replace-all: `{{ reReplaceAll "pattern" Message "$1" }}` (Go positional) or named `{{ reReplaceAll(pattern="...", input="...", replacement="...") }}`

**Variables (Pro):**
- `.PrefixedTag` — full tag with monorepo prefix, or tag_prefix-prepended
- `.PrefixedPreviousTag` — previous version of above
- `.Artifacts` — list of artifacts (used in templated_files, release footer/header)
- `.Metadata` — metadata struct (Description, FullDescription, ...)
- `.Var.*` — user-defined variables from `variables:` config
- `.IsMerging` — "true" if running with `--merge`
- `.IsRelease` — "true" if not snapshot and not nightly

## Contract divergences
- [OK] template.rs:530 — `in` function registered. Tests at 1167 (filter form).
- [OK] template.rs:543-564 — `reReplaceAll` named-form function. Uses `regex::Regex::new(pattern).map_err(|e| ...)` — invalid regex error is actionable.
- [OK] template.rs:566-591 — filter form `{{ Field | reReplaceAll(pattern="...", replacement="...") }}`.
- [OK] template.rs:2944-2955 — **Go-style positional form** `{{ reReplaceAll "world" "hello world" "rust" }}` supported via custom parsing. Important for copy-paste compatibility with GoReleaser configs.
- [OK] Tests cover: basic (2869), capture groups (2880), GoReleaser-style commit message rewriting (2893), no-match (2907), invalid regex (2918), all-occurrences (2933), filter form (2964).
- [OK] context.rs:456 — `PrefixedTag` set correctly for monorepo (full tag).
- [OK] context.rs:495 — non-monorepo: `PrefixedTag` = `tag_prefix + info.tag`.
- [OK] context.rs:545-552 — `IsRelease`, `IsMerging` set on context. Tests at 1581-1645.
- [SUGGEST] context.rs:1892 — template test uses `{% if IsRelease %}` (Tera `if`) which differs from Go's `{{ if .IsRelease }}`. If users copy GoReleaser config verbatim, they may write `{{ if .IsRelease }}` which Tera doesn't parse the same way. Verify both syntaxes work or bail with helpful error.
- [SUGGEST] Go-positional `reReplaceAll` parser is ad-hoc — the 3-arg form is handled but error messages for wrong arity (2 or 4 args) should explicitly name `reReplaceAll`.

## Failure-mode coverage
- Invalid regex: bail with pattern in error ✓ (template.rs:558, 586)
- Missing required args in named form: explicit `ok_or_else` with helpful message ✓
- Unknown variable reference: Tera errors bubble through `render_template` ✓

## Idempotency + retry safety
N/A — template rendering is pure.

## Secret hygiene
N/A — template output goes wherever the caller sends it. Redaction at the log layer (not template layer) is the appropriate boundary.

## Test coverage
- `reReplaceAll`: 9 tests covering all major paths ✓
- `in`: filter form registration at 1167 — need a test to verify actual behavior (not just registration)
- `PrefixedTag`: context.rs:1494, 1508 ✓
- `IsRelease`: 1581, 1598, 1615 ✓
- `IsMerging`: 1632, 1645 ✓
- Missing: test for `in` function form (not just filter)
- Missing: test for `.Var.*` custom variable renders
- Missing: test for `.Artifacts` iteration in a real template

## Suggested invariants
1. `reReplaceAll` in named, filter, and Go-positional forms all produce identical output for the same inputs.
2. `{{ in "foo" list }}` (Go positional), `{{ in(value="foo", list=...) }}` (named), and `{{ "foo" | in list }}` (filter) all produce identical output.
3. `.PrefixedTag` and `.Tag` differ IF and only IF `monorepo.tag_prefix` OR `tag.tag_prefix` is set.
4. `.IsRelease` is true ⇔ not (snapshot OR nightly).

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 3 (dual-syntax `{{ if .IsRelease }}` compat check, Go-positional arity error message, missing `in` function-form test)
- CONFIRMED-WORKING: 12 (in filter registered, reReplaceAll named/filter/positional, 9 reReplaceAll tests, PrefixedTag monorepo+non-monorepo paths, IsRelease/IsMerging population, invalid-regex error path)

## Blocker status for A10
None. All findings are test-coverage / DX improvements.
