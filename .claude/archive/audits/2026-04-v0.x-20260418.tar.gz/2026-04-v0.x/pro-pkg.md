# Pro feature: pkgs[] (macOS .pkg)

**Docs:** https://goreleaser.com/customization/pkg/ (fetched 2026-04-18)
**Anodize site:** crates/stage-pkg/src/lib.rs:116 (`if_condition` gate); config at core/src/config.rs:3597
**Status:** implemented

## Contract
Produces macOS `.pkg` installers via `pkgbuild` + `productbuild`. Fields: `id`, `name`, `if`, `ids`, `identifier`, `scripts`, `install_location`, `extra_files`, `replace`, `mod_timestamp`.

## Contract divergences
- [OK] `if_condition` — hard-bails on render error (verified pattern across msi/dmg/nsis/pkg/appbundle). ✓
- [OK] `pkgbuild` and `productbuild` are macOS-only tools. Anodize bails cleanly if absent.
- [SUGGEST] No explicit `--min-os-version` support. GoReleaser Pro docs call out this field. Check config.rs `PkgConfig` — if not in struct, this is a parity gap.

## Failure-mode coverage
- Tool missing (`pkgbuild`/`productbuild`) → bail with helpful message
- `scripts:` missing files → bubble via `?` with context
- Identifier validation — not enforced (GoReleaser doesn't either); a bad identifier surfaces at `pkgbuild` run-time
- `if` render error → hard-bail ✓
- Ids filter → warn + skip empty

## Idempotency + retry safety
Staging via tempfile. Final `.pkg` overwritten on rerun. Acceptable.

## Secret hygiene
No credentials at pkg build stage. Notarization happens in stage-notarize.

## Test coverage
- Build and `if` test paths expected in `crates/stage-pkg/src/lib.rs::mod tests`.
- Live macOS build gated by `pkgbuild` presence.

## Suggested invariants
1. Every successful pkg run registers exactly one `ArtifactKind::MacOsPackage` per (crate, target).
2. `metadata.format` on the artifact is `"pkg"` (not `"appbundle"`) so stage-notarize `run_native_pkg` filters correctly — see notarize.rs:757 which filters BY `format != "appbundle"`. Dependency.

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 1 (check `min_os_version` field parity)
- CONFIRMED-WORKING: 4 (if hard-bail, extra_files, dry-run, check_output)

## HANDOFF items
Live macOS pkg build + notarize staple requires real Apple Developer credentials; see HANDOFF.md.
