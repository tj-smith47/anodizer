# Pro feature: Pro variables (.PrefixedTag / .Artifacts / .Metadata / .Var / .IsMerging / .IsRelease)

**Docs:** https://goreleaser.com/customization/templates/ (fetched 2026-04-18)
**Anodize site:** See pro-template-helpers.md for shared template-layer details; core/src/context.rs:357-552 for variable population; core/src/template.rs for registration
**Status:** implemented

## Contract
See pro-template-helpers.md. This file is a cross-reference for the variable surface specifically.

## Variables matrix

| Variable | Registered (line) | Populated (line) | Test (line) |
|---|---|---|---|
| `.PrefixedTag` | context.rs:357 (docstring) | context.rs:456 (monorepo) / 495 (non-monorepo) | 1494, 1508 |
| `.PrefixedPreviousTag` | context.rs:441 (docstring) | context.rs:487-495 (implicit via tag_prefix) | (verify) |
| `.Artifacts` | template.rs (via context iteration) | populated on refresh | (verify) |
| `.Metadata` | context.rs:773 (JSON fields: Description, FullDescription, ...) | context.rs:686-773 | 1763, 1781, 1802 |
| `.Var.*` | via `variables:` config | (verify population) | (verify) |
| `.IsMerging` | context.rs:361 (docstring) | context.rs:550-552 | 1632, 1645 |
| `.IsRelease` | context.rs:360 | context.rs:545-548 | 1581, 1598, 1615 |

## Contract divergences
- [SUGGEST] Verify `.Artifacts` iteration syntax: Tera uses `{% for a in Artifacts %}` not Go's `{{ range .Artifacts }}`. Users migrating may need a template translator or documentation call-out.
- [SUGGEST] Verify `.Var.CUSTOM` works via Tera's dotted access. Tera may need `Var.CUSTOM` without the leading dot.
- [OK] Variable set covers the Pro surface per docs.

## Failure-mode coverage
- Accessing an unset `.Var.FOO`: Tera errors; bubble. ✓
- Accessing `.Artifacts` before a refresh point: returns empty or stale list. Verify timing.

## Idempotency + retry safety
Pure read. Idempotent.

## Secret hygiene
- `.Var.*` can contain user-defined secrets via `variables:`. When rendered into templated outputs (nfpm scripts, archive contents, ...), the secret becomes content in the artifact. This is by design — templating is the user's responsibility.
- `.Env.*` (OSS) is the canonical env-var accessor; redaction applies at log-layer only.

## Test coverage
Refer to pro-template-helpers.md matrix. Gaps:
- No explicit test for `.Var.CUSTOM` end-to-end.
- No explicit test for `.Artifacts` iteration in a real template.
- No test for `.PrefixedPreviousTag`.

## Suggested invariants
1. All Pro variables listed in GoReleaser docs are reachable from anodize templates.
2. `.IsMerging` reflects the actual merge flag state at run time (not stale).

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 3 (verify .Artifacts iteration works, verify .Var.CUSTOM works, test .PrefixedPreviousTag)
- CONFIRMED-WORKING: 5 (PrefixedTag both paths, IsRelease, IsMerging, Metadata JSON structure, variables field declared)
