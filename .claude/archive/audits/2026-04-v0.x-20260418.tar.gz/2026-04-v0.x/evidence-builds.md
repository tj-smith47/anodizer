# Evidence — Builds (§2.1)

**Category:** build
**Status:** ✅ release-tag proof
**Tier:** OSS
**Ecosystem relevance:** required (Rust builder, targets, flags, env, overrides, hooks, skip, mod_timestamp, report_sizes, partial)

## Covered feature rows

- builder: rust, build.id, build.binary, build.dir, build.command, build.flags, build.env, build.tool, build.targets, build.mod_timestamp, build.overrides, build.hooks.pre/post, build.skip, build.no_unique_dist_dir, partial builds (--single-target), universal_binaries, reportsizes, upx, prebuild pipe, builder: prebuilt
- **Not covered (n-a):** Go-specific builders (go/zig/bun/deno/python-uv/python-poetry), Go matrix axes (goos/goarch/goarm/etc.), ldflags/asmflags/gcflags, gomod.*, buildmode, no_main_check — permanent negative space (§4 of inventory).

## Proof

### Release-tag proof

- **anodize v0.2.5** — https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — published 2026-04-15; assets include `anodize-0.2.5-{linux,darwin,windows}-{amd64,arm64}.tar.gz/.zip` (6 target triples built via cargo/cargo-zigbuild). Body: "Released with [anodize]" — self-built.
- **cfgd v0.3.5** — https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5 — same 6 triples plus UPX-compressed Linux amd64 binary (per `upx:` block in `/opt/repos/cfgd/.anodize.yaml:76-89`) and macOS universal_binary (per `universal_binaries:` block in `/opt/repos/cfgd/.anodize.yaml:155-157`).

### CI workflow runs (release-tag triggered)

- cfgd release.yml run 24442230191 (tag v0.3.5) — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — exercises `--split` + `--crate` + `--strict` + `--verbose` + `--debug` + `--clean` flags; installs zig/cargo-zigbuild/upx via anodize-action.
- cfgd release.yml run 24442229349 (tag core-v0.3.5) — https://github.com/tj-smith47/cfgd/actions/runs/24442229349 — library-only crate path (has-builds=false).
- anodize ci.yml run 24441674093 (master) — https://github.com/tj-smith47/anodize/actions/runs/24441674093 — builds all 6 release targets into `anodize-{linux,macos,windows}` artifacts consumed by release.yml.

### Tests

- `crates/cli/tests/integration.rs::test_e2e_snapshot_release_produces_artifacts` (line 632) — runs full snapshot release, asserts dist/ contents.
- `crates/cli/tests/integration.rs::test_e2e_build_command_matches_goreleaser_pipeline_outputs` (line 3617) — golden build-pipeline output.
- `crates/cli/tests/integration.rs::test_e2e_report_sizes` (line 3546) — asserts `report_sizes: true` prints sizes.
- `crates/cli/tests/integration.rs::test_e2e_cross_platform_format_overrides_check` (line 2538) — format_overrides per-OS (archive category cross-ref).
- `crates/cli/tests/integration.rs::test_e2e_before_hooks_execute` (line 3368) + `test_e2e_before_hooks_dry_run` (line 3437) — global before hooks.
- `crates/core/tests/config_parsing_tests.rs` — 120+ build config parsing tests (targets, cross, flags, features, env, copy_from, overrides).

## Self-hosted config references

- `/opt/repos/anodize/.anodize.yaml:11` `report_sizes: true` — drives reportsizes feature end-of-build.
- `/opt/repos/anodize/.anodize.yaml:45-57` `defaults.targets` + `defaults.cross: auto` — 6 target triples in production.
- `/opt/repos/anodize/.anodize.yaml:60-69` `before.hooks` (`cargo fmt --check`, `cargo clippy`, `cargo test`) + `after.post`.
