# Pro feature: dmgs[] (macOS disk image)

**Docs:** https://goreleaser.com/customization/dmg/ (fetched 2026-04-18)
**Anodize site:** crates/stage-dmg/src/lib.rs:115 (`DmgStage::run`); config at core/src/config.rs:3521 (`DmgConfig.if_condition`)
**Status:** implemented

## Contract
`dmgs[]` produces macOS `.dmg` disk images per Pro docs. Fields: `id`, `name`, `ids`, `use` (`binary` or `appbundle`), `if`, `goamd64`, `extra_files`, `templated_extra_files`, `replace`, `mod_timestamp`. Tooling: `hdiutil` (macOS native) or `mkisofs`/`genisoimage` (Linux fallback). Output: `.dmg` at `dist/macos/<name>.dmg`.

## Contract divergences
- [OK] crates/stage-dmg/src/lib.rs:32-43 — tool detection preference `hdiutil > genisoimage > mkisofs`. Docs mention only hdiutil/mkisofs; adding genisoimage is a Linux-friendly superset. Accepted.
- [OK] crates/stage-dmg/src/lib.rs:113 — default name template is `{{ ProjectName }}_{{ Version }}_{{ Arch }}.dmg`. Docs default: `{{.ProjectName}}_{{.Arch}}`. Anodize adds `_{{ Version }}`, which is STRICTER (includes version) — avoids the common footgun where old DMGs with same ProjectName+Arch get overwritten across versions.
- [WARN] crates/stage-dmg/src/lib.rs:186-191 — `use:` accepts only `binary` or `appbundle`. GoReleaser docs also mention `archive` implicitly (via `ids` on archive IDs). Anodize bails on anything other than those two strings. This is stricter and safer than GoReleaser's permissive parsing but diverges. Cite file:line.
- [OK] crates/stage-dmg/src/lib.rs:156-171 — `if` template hard-bails on render error (`with_context`, then `?`). Matches the strictness policy from stage-nfpm.
- [OK] crates/stage-dmg/src/lib.rs:281 `DEFAULT_NAME_TEMPLATE` uses Tera syntax `{{ ProjectName }}` (no dot). Rendered via `ctx.render_template` which handles both Go-dot and plain.
- [OK] crates/stage-dmg/src/lib.rs:291-295 — auto-appends `.dmg` (case-insensitive) if user omits extension. Good DX.
- [SUGGEST] crates/stage-dmg/src/lib.rs:266-268 — `effective_binaries` collects `(target, path)` tuples, but when there are multiple binaries per crate for a given target (e.g., a CLI with multiple bins), only one gets into the DMG since the iteration is per-source-artifact. No test covers the multi-bin case.
- [SUGGEST] crates/stage-dmg/src/lib.rs:405-407 — `mod_timestamp` applied to the staging dir (not the final DMG). `hdiutil create` may regenerate file timestamps from source metadata; verify the staging-dir timestamp actually propagates to `.dmg` contents. Currently no test asserts.

## Failure-mode coverage
- Tool missing: crates/stage-dmg/src/lib.rs:339-343 bails with explicit "need hdiutil, genisoimage, or mkisofs" ✓
- `if` render error: hard bail ✓ (156-162)
- Empty source artifacts: warn + continue, does not error ✓ (241-262)
- `ids:` filter matching nothing: warn + skip ✓
- extra_files glob error: bubbled up via `?` with context ✓ (369-387)
- Staging dir copy failure: `?` with context ✓
- `hdiutil` / `mkisofs` non-zero exit: crates/stage-dmg/src/lib.rs:428 `log.check_output(output, "dmg")?;` bails ✓

## Idempotency + retry safety
- Staging uses `tempfile::tempdir` which auto-cleans on drop even on error ✓
- Final DMG written directly via `hdiutil create` — if it fails mid-write, a corrupt .dmg may be left in `dist/macos/`. Rerun will overwrite. Acceptable.
- No atomic-write pattern (no `.tmp` + rename). Docs don't require it.

## Secret hygiene
- No credential flow in DMG creation itself (signing/notarization happens in stage-notarize).
- `hdiutil create` argv exposed to `ps`; argv contains only paths and volume name, no secrets ✓

## Test coverage
- `test_dmg_command_hdiutil` crates/stage-dmg/src/lib.rs:496 ✓
- `test_dmg_command_mkisofs` line 541 ✓
- End-to-end via `test_dmg_*_live` at 1020+ — runs only when `hdiutil` exists (macOS CI)
- Missing: test for `if_condition` render failure bailing
- Missing: test for `use: appbundle` mode path
- Missing: test for multi-binary-per-target behavior

## Suggested invariants
1. Every successful dmg run emits exactly one `ArtifactKind::DiskImage` per (crate, target) tuple matching the config.
2. If `replace: true`, the source archive/binary is removed from the artifact list AFTER the DMG registers successfully (order-dependency).
3. `mod_timestamp` — the final `.dmg` st_mtime equals the rendered timestamp (requires live test).

## Findings summary
- BLOCKER: 0
- WARN: 1 (use: accepts only binary|appbundle; archive use missing)
- SUGGEST: 3 (multi-bin per target, mod_timestamp propagation, missing if-render test)
- CONFIRMED-WORKING: 7 (tool detect, if hard-bail, extra_files glob, replace, dry-run, strict error handling, artifact registration)

## HANDOFF items
See HANDOFF.md — DMG `mod_timestamp` end-to-end verification requires a live macOS build.
