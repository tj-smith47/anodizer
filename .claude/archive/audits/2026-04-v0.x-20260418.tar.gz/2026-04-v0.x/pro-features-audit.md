# Pro features deep audit — 2026-04-18

**Auditor:** pro-features-skeptic (Wave A Task #5)
**Source:** 22 rows in `/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md` with `tier = Pro` AND `ecosystem_relevance ∈ {required, strongly-suggested}`. Not-applicable rows (npm, --key) excluded per spawn prompt.
**Mandate:** professional distrust. Docs may lag. Every finding is guilty until cleared by evidence.

## Roll-up

| Category | Count |
|---|---|
| Features audited | 21 (22 rows, release-header+release-footer in one file) |
| BLOCKER | 0 |
| WARN | 5 |
| SUGGEST | 29 |
| CONFIRMED-WORKING findings | ~80 |
| DEFERRED-TO-HANDOFF items | 9 (require live CI or specific OS) |

## WARN findings (non-blocker divergences or hardening gaps)

1. **pro-dmg.md** — `use:` accepts only `binary` or `appbundle`; docs mention `archive` use case implicitly via `ids` on archive IDs. Stricter than GoReleaser, not wrong, but diverges.
2. **pro-msi.md** — `-ext` passed to both `candle` AND `light` in v3 mode; docs pass only to `candle`. Behavioral superset, harmless but diverges.
3. **pro-partial-builds.md** — Artifact path collision in merge silently deduped; should be an error if per-target subdir isolation is supposed to prevent collisions.
4. **pro-partial-builds.md** — `context.json` serialized to `dist/<subdir>/` contains `env_vars` that may include template-referenced secrets. If users upload `dist/` as a CI artifact (common), secrets could leak. Needs docs warning + per-key allowlist.
5. **pro-flag-id.md** — No `--id` clap alias for `--crate`; users migrating from GoReleaser will get a confusing clap error. DX friction.
6. **pro-metadata.md** — `metadata.full_description.from_url` deliberately errors with an actionable message (core has no HTTP client). Known `partial` per inventory; acceptable per classification but diverges from docs.

## Top SUGGEST findings (most impactful)

1. **pro-signs-if.md** — `signature:` and `certificate:` templates silent-fallback on render error (lib.rs:107, 608). A user typo (`{{ .Teg }}`) shadows the intended path. Should hard-bail like `if_condition` does.
2. **pro-partial-builds.md** — `env_vars` in `SplitContext` needs an allowlist or redaction pass before serialization.
3. **pro-release-header-footer-from-url.md** — Rendered header values not validated for CRLF (header injection); `response.text()?` has no body size limit.
4. **pro-template-helpers.md** — `{% if IsRelease %}` (Tera) vs `{{ if .IsRelease }}` (Go) dual-syntax compat check. Users may copy GoReleaser verbatim.
5. **pro-notarize.md** — When `ids:` filter matches nothing, silent skip should become a warn with the filter contents.
6. **pro-flag-prepare.md** — `--prepare --snapshot` composition not validated; may be ambiguous.

## Per-feature file index

| Feature | File | Status | Counts (B/W/S) |
|---|---|---|---|
| archives[].hooks.before/after | pro-archive-hooks.md | implemented | 0/0/2 |
| release.tag (template) | pro-release-tag.md | implemented | 0/0/2 |
| release.header/footer.from_url+from_file | pro-release-header-footer-from-url.md | implemented | 0/0/3 |
| signs[].if | pro-signs-if.md | implemented | 0/1/2 |
| nfpm.if | pro-nfpm-if.md | implemented | 0/0/0 |
| dmgs[] | pro-dmg.md | implemented | 0/1/3 |
| msis[] | pro-msi.md | implemented | 0/1/1 |
| pkgs[] | pro-pkg.md | implemented | 0/0/1 |
| nsis[] | pro-nsis.md | implemented | 0/0/1 |
| app_bundles[] | pro-app-bundle.md | implemented | 0/0/2 |
| notarize.macos_native | pro-notarize.md | implemented | 0/0/3 |
| monorepo | pro-monorepo.md | implemented | 0/0/3 |
| metadata.* (+full_description.from_url partial) | pro-metadata.md | partial (from_url) | 0/1/1 |
| partial builds (--split/--merge) | pro-partial-builds.md | implemented | 0/2/2 |
| CLI continue/publish/announce | pro-continue-publish-announce.md | implemented | 0/0/2 |
| --id flag | pro-flag-id.md | implemented (aliased to --crate) | 0/1/1 |
| --prepare flag | pro-flag-prepare.md | implemented | 0/0/2 |
| --split flag | pro-flag-split.md | implemented | 0/0/2 |
| Template helpers (in / reReplaceAll) | pro-template-helpers.md | implemented | 0/0/3 |
| Pro variables (.PrefixedTag etc.) | pro-variables.md | implemented | 0/0/3 |

## Method

- Pulled docs from goreleaser.com/customization/ and /pro/ (all fetched 2026-04-16/18 per inventory).
- Greped anodize crates for each Pro feature's implementation site; cited file:line for every divergence.
- Followed each config field from parse (core/src/config.rs) through to consumption site (stage-*).
- Traced failure paths: template render errors, exit-code handling, empty-artifact cases, idempotency.
- Cross-checked redaction: env-var suffix matching + prefix matching (redact.rs:7-35) applied to sign/hook outputs.
- Flagged every silent-skip-on-render-error path as SUGGEST or WARN since "ship unsigned/unpublished release" is a quiet failure mode.

## Policy findings (cross-cutting)

**Template render error handling inconsistency:**
- `if_condition` on sign/nfpm/dmg/pkg/msi/nsis/appbundle → HARD-BAIL on render error ✓
- `signature:` template on sign → silent fallback to `{artifact}.sig` (lib.rs:107) ✗
- `certificate:` template on sign → silent fallback to preprocessed string (lib.rs:608) ✗
- Sign `args` template → warn + fall back to raw literal (lib.rs:650-655) ✗
- Hook `cmd` / `dir` / `env` template → silent fallback to raw string (core/src/hooks.rs:23-25) ✗

**Recommendation:** centralize template-rendering-at-user-input with a single policy: "render error at user-configured template site = fatal, unless explicitly opt-in to fallback." Post this policy in core/src/template.rs as a doc comment and enforce via a clippy/lint or code review checklist.

## HANDOFF items (live validation required)

See `HANDOFF.md`. Summary:
- DMG: `mod_timestamp` propagation to `.dmg` contents
- PKG: full end-to-end with real Apple Developer certificates
- MSI: WiX v3 and v4 paths on Windows runner
- NSIS: `makensis` live on Windows
- App bundle: codesign + Info.plist correctness
- Notarize: full `xcrun notarytool submit` + stapler staple round-trip
- Split/merge: matrix test across linux/darwin/windows runners
- release.tag: verify rendered template reaches GH API `tag_name` field
- release.header.from_url: authenticated private mirror fetch with CRLF-guarded headers

## Completion

All 22 qualifying Pro rows audited. Zero BLOCKERs. 5 WARNs + 29 SUGGESTs to be consolidated into `anodize/.claude/known-bugs.md` by A10 per the parity policy ("every finding tracked"). No ship-blocking issues for v0.x.

---
Auditor sign-off: pro-features-skeptic
Date: 2026-04-18
