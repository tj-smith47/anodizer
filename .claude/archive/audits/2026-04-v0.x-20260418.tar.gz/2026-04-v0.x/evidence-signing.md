# Evidence — Signing (§2.6)

**Category:** sign
**Status:** ✅ release-tag proof
**Tier:** OSS + Pro
**Ecosystem relevance:** required (signs[], cmd, signature, args, artifacts, env); strongly-suggested (ids, Pro `if`, stdin/stdin_file, certificate, docker_signs, binary_signs); niche (output)

## Covered feature rows

- signs[], .cmd (gpg + cosign defaults), signature template, args, artifacts enum (none/all/checksum/source/package/installer/diskimage/archive/sbom/binary), ids, Pro `if`, stdin/stdin_file, certificate (cosign/rekor), env, output
- docker_signs[], binary_signs[] (deprecated)

## Proof

### Release-tag proof

- **anodize v0.2.5** — https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — assets include per-artifact sigs: `anodize_linux_amd64.sig`, `anodize_darwin_amd64.sig`, `anodize.exe_windows_amd64.sig` (cosign-signed binaries); `anodize-0.2.5-source.tar.gz.sig` (source archive signed); `anodize-0.2.5-checksums.txt.sig` (checksum file signed). Three distinct `artifacts:` values exercised: `binary`, `source`, `checksum`.
- **cfgd v0.3.5** — https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5 — same shape: `cfgd_{linux,darwin,windows}_{amd64,arm64}.sig`, `cfgd-0.3.5-source.tar.gz.sig`, `cfgd-0.3.5-checksums.txt.sig`.

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — imports `COSIGN_KEY` + `GPG_PRIVATE_KEY` via anodize-action's inline key handling; installs cosign via `install: ...,cosign`; runs binary signing pre-archive via `BinarySignStage` (commit 19801c9) then source/checksum signing post.

### Tests

- `crates/cli/tests/integration.rs::test_e2e_multi_sign_dry_run` (line 1892) — multiple signs[] configs + artifacts enum.
- Unit tests in `crates/stage-sign/src/lib.rs`.

## Known limitations

- **docker_signs[]** wired (per commit `f7d483d "docker_signs as separate stage post-docker"`) but cfgd v0.3.5 did not sign docker images (no `docker_signs:` in config). Status stays ✅ at category level because binary/source/checksum signing proved the signing plumbing end-to-end.
- **Pro `if` condition**: wired per inventory row (§2.6), exercised in tests, but no production release uses it.
- GPG signing path is wired (`/opt/repos/cfgd/.github/workflows/release.yml:137` passes `gpg-private-key` + `GPG_FINGERPRINT`) but no sig file in the release is visibly GPG-armored; cosign is the observed signing backend in production.
