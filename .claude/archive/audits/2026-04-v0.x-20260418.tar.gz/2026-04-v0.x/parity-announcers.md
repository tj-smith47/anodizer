# Parity audit — announcers + release-polish slice — 2026-04-v0.x

Scope: all rows from the Parity Row Matrix covering announce-* providers
(twitter/X, reddit, slack, discord, teams, mattermost, webhook, smtp,
telegram, bluesky, mastodon, linkedin, opencollective), changelog, release
(including release notes header/footer/mode/name_template/make_latest/
replace_existing_draft/discussion_category_name/target_commitish/extra_files),
sign (cosign/gpg/custom), sbom (syft/anchore/cyclonedx), snapshot, env_files,
env, variables, metadata, report_sizes in
`/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md`.

Filter rule: `ecosystem_relevance ∈ {required, strongly-suggested}` audited
with behavioral parity criteria. Rows marked `niche` listed informationally.
Rows marked `not-applicable` skipped (surfaced as bloat candidates only when
also `implemented` — see bloat.md).

Reference: `/opt/repos/goreleaser/` (OSS).
Implementation: `/opt/repos/anodize/crates/`.

## Summary
BLOCKER=0  WARN=1  SUGGEST=3  INTENTIONAL=5  (rows audited: 38, rows skipped
not-applicable: 0, bloat candidates: 0, niche informational: 14)

---

## BLOCKER

_None._ Every required- and strongly-suggested behaviour in the announcers +
release-polish slice is wired end-to-end in the matching anodize stage and
produces equivalent (or superior) output for the reference inputs probed in
this audit.

---

## WARN

### `announce.email.port` documentation claims a default of 587 but none is applied

- symptom: `crates/core/src/config.rs:4759` documents the field as
  "SMTP server port (default: 587 for STARTTLS)". In practice
  `crates/stage-announce/src/lib.rs:803-807` bails with "SMTP port is
  required — set `announce.email.port` or the `SMTP_PORT` env var" when both
  the field and the env var are unset. GoReleaser's behavior is identical
  (`internal/pipe/smtp/smtp.go:98,103-121` → `errNoPort`), so the *runtime* is
  on-parity, but the config-schema comment misleads users into thinking 587
  is auto-applied. Fix: either wire a `.unwrap_or(587)` fallback (matches the
  documented contract and matches typical ISP/Gmail-style STARTTLS defaults)
  or correct the comment to state "required; no default".
- audit: `crates/core/src/config.rs:4758-4760` (doc),
  `crates/stage-announce/src/lib.rs:782-807` (runtime), matched against
  `internal/pipe/smtp/smtp.go:98-121`.
- repro: `announce.email: { enabled: true, from: a@b, to: [c@d], host: x, username: u }`
  without `port:` and without `SMTP_PORT` env → bails "SMTP port is required"
  despite doc promising 587.

---

## SUGGEST

### No config-time validation that multiple SCM release backends are mutually exclusive

- symptom: GoReleaser's release pipe (`internal/pipe/release/release.go:41-53`)
  validates at `Default()` time that at most one of
  `release.github` / `release.gitlab` / `release.gitea` is non-empty, returning
  `ErrMultipleReleases` otherwise. anodize's `stage-release/src/lib.rs:1484-1690`
  dispatches on `ctx.token_type` at runtime, so in practice only one SCM ever
  executes — but a user who mistakenly sets two of the three config sections
  receives no warning, and the silent ignored block becomes a dead-code trap
  across reconfigurations (e.g. switching tokens between repos). A single
  pre-run validation in `stage-release` or `setup_env` matching GoReleaser's
  behaviour would surface the mistake immediately.
- audit: `crates/stage-release/src/lib.rs:1484-1500,1688-1694` (no
  pre-dispatch validation) vs. `internal/pipe/release/release.go:41-53`.
- repro: YAML with both `release.github: { owner: a, name: b }` and
  `release.gitlab: { owner: c, name: d }` → no error at parse or pipeline
  setup; anodize silently uses whichever token is present.

### `announce.webhook` header precedence differs silently from GoReleaser

- symptom: GoReleaser (`internal/pipe/webhook/webhook.go:104-115`) adds the
  env-provided `Authorization` header (`BASIC_AUTH_HEADER_VALUE` or
  `BEARER_TOKEN_HEADER_VALUE`) *first*, then iterates config-supplied headers
  and `req.Header.Add` each one — because `Add` appends rather than replaces,
  a config-supplied `Authorization` becomes a *second* value and most HTTP
  servers honour the first (env). anodize
  (`crates/stage-announce/src/lib.rs:317-337`) inverts this: user-supplied
  `headers.Authorization` wins, and the env fallback only fires when the
  config didn't set one. The DX argument for anodize's choice is strong
  ("config wins over env" is a cleaner contract), but users porting a
  GoReleaser config that relied on env-override behaviour will see different
  wire traffic. Document the divergence in the webhook config doc comment
  (`crates/core/src/config.rs:4673-4687`) or invert the precedence to match
  upstream.
- audit: `crates/stage-announce/src/lib.rs:317-337` vs.
  `internal/pipe/webhook/webhook.go:104-115`.
- repro: config `announce.webhook.headers: { Authorization: "Bearer config" }`
  + env `BEARER_TOKEN_HEADER_VALUE="Bearer env"` → GoReleaser sends both (env
  first, config second); anodize sends only the config value.

### `announce.mattermost.color` silently falls back to hard-coded default instead of reading `TeamsAnnounce.Color`

- symptom: GoReleaser has a bug in `internal/pipe/mattermost/mattermost.go:48-49,82`
  where the Mattermost default / attachment color reads from
  `ctx.Config.Announce.Teams.Color` (clearly a copy-paste oversight from the
  teams pipe). anodize correctly uses `MattermostAnnounce.color` everywhere
  (`crates/stage-announce/src/lib.rs:502`). That is the **correct** behaviour
  — but because the GoReleaser bug is what published configs currently rely
  on, users who set `announce.teams.color` expecting it to bleed into
  Mattermost will see different output under anodize. Add a comment next to
  the mattermost color logic (lib.rs:501-502) flagging this as a deliberate
  upstream-bug fix so a future audit doesn't "correct" it back.
- audit: `crates/stage-announce/src/lib.rs:501-502` vs.
  `internal/pipe/mattermost/mattermost.go:48-49,82`.
- repro: YAML with `announce.teams.color: "#ff0000"` and
  `announce.mattermost.*` (no color) → GoReleaser posts a red mattermost
  attachment; anodize posts the `#2D313E` default.

---

## INTENTIONAL

### Mastodon auth requires only `MASTODON_ACCESS_TOKEN` (not also client ID + secret)

- context: GoReleaser (`internal/pipe/mastodon/mastodon.go:23-27`) declares
  three `notEmpty` env vars (`MASTODON_CLIENT_ID`, `MASTODON_CLIENT_SECRET`,
  `MASTODON_ACCESS_TOKEN`) because the `go-mastodon` client library requires
  them at construction, even though the Mastodon v1 `/api/v1/statuses`
  endpoint needs only the bearer access token. anodize calls the HTTP API
  directly (`crates/stage-announce/src/mastodon.rs:1-19`), so only the
  access token is required. Net effect: anodize configs work with a smaller
  secret set.
- audit: `crates/stage-announce/src/mastodon.rs:1-19`;
  `crates/stage-announce/src/lib.rs:619-623` vs.
  `internal/pipe/mastodon/mastodon.go:23-60`.
- rationale: bearer-token auth is the minimum the REST API enforces; demanding
  client_id/client_secret is library artefact, not protocol requirement.

### Announcer default username branding is "anodize", not "GoReleaser"

- context: Slack and Mattermost's `Default()` sets `Username` to
  `"GoReleaser"` when empty (`internal/pipe/slack/slack.go:37-39`,
  `internal/pipe/mattermost/mattermost.go:45-47`). Discord's Author is
  `"GoReleaser"` and Teams' `IconURL` is
  `https://goreleaser.com/static/avatar.png`. anodize rebrands all of these
  to `"anodize"` (lib.rs:166,264-265,497-498) and omits the Teams icon URL
  until anodize hosts its own avatar (lib.rs:463-466 comment). Users can
  always override explicitly; this only affects unset-username posts.
- audit: `crates/stage-announce/src/lib.rs:166,264-265,463-466,497-498` vs.
  GoReleaser pipe defaults cited above.
- rationale: the default should match the tool that actually sent the
  announcement. Pinning unset-username to "GoReleaser" inside anodize would
  mislead consumers.

### Telegram warns on unknown `parse_mode` instead of silently coercing

- context: GoReleaser (`internal/pipe/telegram/telegram.go:41-50`) silently
  coerces any unknown `parse_mode` value to `"MarkdownV2"` in `Default()`.
  anodize (`crates/stage-announce/src/lib.rs:393-405`) warns the user before
  coercing so misconfiguration surfaces in the log. Output behaviour is
  identical (`MarkdownV2` in both cases); only the log-line differs.
- audit: `crates/stage-announce/src/lib.rs:393-405` vs.
  `internal/pipe/telegram/telegram.go:41-50`.
- rationale: silent coercion + default retain-override is a known DX
  footgun; users with a typo'd `parse_mode` will never know until they
  inspect wire traffic.

### Changelog is still generated in snapshot mode (documented)

- context: GoReleaser (`internal/pipe/changelog/changelog.go:45-51`) returns
  `true` from `Skip()` unconditionally when `ctx.Snapshot` is set, so the
  changelog pipe never runs for snapshot builds. anodize
  (`crates/stage-changelog/src/lib.rs:839-844`) deliberately generates the
  changelog even in snapshot mode so users can preview it during CI and
  pre-tag dogfooding. The difference is called out with an inline comment
  in the stage source.
- audit: `crates/stage-changelog/src/lib.rs:839-844` vs.
  `internal/pipe/changelog/changelog.go:45-51`.
- rationale: snapshot builds are the most common place to *want* to preview
  the changelog; skipping at that stage removes an easy-to-use dry-run
  mechanism.

### `announce.webhook` User-Agent brands as `anodize/<version>` instead of `goreleaser`

- context: GoReleaser hard-codes `UserAgentHeaderValue = "goreleaser"`
  (`internal/pipe/webhook/webhook.go:24`). anodize
  (`crates/stage-announce/src/lib.rs:340-341`) injects
  `concat!("anodize/", env!("CARGO_PKG_VERSION"))` with per-release version
  pinning. Receivers that allowlist by User-Agent will need to accept both
  strings in a migration period.
- audit: `crates/stage-announce/src/lib.rs:340-341` vs.
  `internal/pipe/webhook/webhook.go:24`.
- rationale: the tool that sent the request should identify itself
  correctly; versioned UA enables remote instrumentation/retry tuning.

---

## Niche — informational only

Rows marked `ecosystem_relevance=niche` in the inventory are documented here
for completeness; they are not blockers for v0.x parity.

- **announce.telegram** (`internal/pipe/telegram/`) — implemented via
  `stage-announce/src/telegram.rs`, `parse_mode` (MarkdownV2/HTML) +
  `message_thread_id` wired.
- **announce.teams** (`internal/pipe/teams/`) — implemented; uses an
  AdaptiveCard shape (intentional divergence from GoReleaser's MessageCard;
  MessageCard is deprecated by Microsoft 2024-10).
- **announce.mattermost** (`internal/pipe/mattermost/`) — implemented.
- **announce.smtp** (`internal/pipe/smtp/`) — implemented via
  `stage-announce/src/email.rs`; SMTPS (port 465) + STARTTLS + sendmail
  fallback all wired.
- **announce.reddit** (`internal/pipe/reddit/`) — implemented; OAuth2
  password grant + submit-link flow.
- **announce.twitter** (`internal/pipe/twitter/`) — implemented via
  OAuth1 → X API v2 (GoReleaser uses v1.1; anodize migrated to v2 because
  the v1.1 endpoints are being deprecated on x.com).
- **announce.mastodon** (`internal/pipe/mastodon/`) — implemented via
  direct REST (no go-mastodon dependency).
- **announce.bluesky** (`internal/pipe/bluesky/`) — implemented via direct
  `com.atproto.*` XRPC calls; `pds_url` override wired for self-hosted PDS.
- **announce.linkedin** (`internal/pipe/linkedin/`) — implemented with
  `/v2/userinfo` (primary) → `/v2/me` (legacy fallback on 403) mirroring
  GoReleaser's endpoint-degradation strategy.
- **announce.opencollective** (`internal/pipe/opencollective/`) —
  implemented; two-step GraphQL createUpdate+publishUpdate.
- **changelog.paths / title / divider / groups[].groups[] / ai.*** —
  implemented in `stage-changelog`; Pro features confirmed wired in Session
  H / J closures.
- **release.discussion_category_name / use_existing_draft / gitlab_urls /
  gitea_urls / templated_extra_files / include_meta** — all implemented and
  wired in `stage-release/src/lib.rs:1198-1309`.
- **signs[].if / signs[].output / binary_signs / docker_signs** —
  implemented; `if_condition` wiring at stage-sign/src/lib.rs:404,991.
- **sbom.documents / ids / disable / env templated** — implemented in
  `stage-sbom/src/lib.rs`.

---

## Rows audited

Announcers (announce-*): discord, slack, webhook (strongly-suggested);
telegram, teams, mattermost, smtp, reddit, twitter, mastodon, bluesky,
linkedin, opencollective (niche). 13 providers.

Release-polish: changelog.disable/use/format/sort/abbrev/filters/groups
(required + strongly-suggested); release.github/gitlab/gitea/draft/prerelease/
make_latest/mode/header/footer/name_template/disable/skip_upload/
replace_existing_draft/replace_existing_artifacts/target_commitish/extra_files/
github_urls/milestone (required + strongly-suggested); signs[] core fields
(cmd/signature/args/artifacts/ids/env — required; if/stdin/certificate —
strongly-suggested); docker_signs[] / binary_signs[] (strongly-suggested);
sboms[] core (cmd/args/env/artifacts/ids/disable/documents — required);
snapshot.name_template (required); env (required); env_files.github_token /
gitlab_token / gitea_token (strongly-suggested); metadata.mod_timestamp /
maintainers / license / homepage / description (strongly-suggested);
report_sizes (required). 25 rows.

Total: 38 required/strongly-suggested rows; 14 niche rows; 0
not-applicable rows; 0 bloat candidates from this slice.
