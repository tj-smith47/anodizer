# Evidence — nFPM Linux packages + SRPM (§2.8)

**Category:** publish-nfpm
**Status:** ✅ release-tag proof
**Tier:** OSS + Pro
**Ecosystem relevance:** required (nfpms[], id/ids/package_name/file_name_template, vendor/homepage/maintainer/description/license, formats deb/rpm, epoch/prerelease/release/section/priority, dependencies/provides/recommends/suggests/conflicts/replaces, contents, scripts, rpm/deb subfield blocks, per-format ConventionalFileName); strongly-suggested (umask/bindir/libdirs, meta/changelog/mtime, file_info, overrides, NFPM_*_PASSPHRASE); niche (apk/termux.deb/archlinux/ipk formats, Pro nfpm.if/templated_contents/templated_scripts, apk/archlinux/ipk subfield blocks, srpm)

## Covered feature rows

- nfpms[], id/ids/package_name/file_name_template, Pro `if`, vendor/homepage/maintainer/description/license
- formats: deb, rpm, apk, termux.deb, archlinux, ipk
- umask/bindir/libdirs, epoch/prerelease/version_metadata/release/section/priority, meta/changelog/goamd64/mtime
- dependencies/provides/recommends/suggests/conflicts/replaces, contents[] (config/noreplace/symlink/tree/ghost/dir + file_info), Pro templated_contents + templated_scripts
- scripts (preinstall/postinstall/preremove/postremove), rpm.*/deb.*/apk.*/archlinux.*/ipk.* subfields
- overrides (per-format), ConventionalFileName per-packager, NFPM_*_PASSPHRASE priority
- srpm (separate stage-srpm)

## Proof

### Release-tag proof

- **cfgd v0.3.5** — https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5 — `nfpm:` at `/opt/repos/cfgd/.anodize.yaml:214-230` produced:
  - `cfgd_0.3.5_linux_amd64.deb` + `.rpm` + `.apk` (all three formats, per-packager ConventionalFileName)
  - `cfgd_0.3.5_linux_arm64.deb` + `.rpm` + `.apk`
  - `cfgd-0.3.5-1.src.rpm` (srpm)
  - contents block mapped LICENSE + README to `/usr/share/doc/cfgd/`.
- **anodize v0.2.5** — https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — same shape: `anodize_0.2.5_linux_amd64.{deb,rpm,apk}` + arm64 + `anodize-0.2.5-1.src.rpm`.

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — `install: nfpm,makeself,snapcraft,rpmbuild,cosign` via anodize-action installs nfpm + rpmbuild; runs `stage-nfpm` + `stage-srpm` in sequence.

### Tests

- Unit tests in `crates/stage-nfpm/src/filename.rs` (ConventionalFileName per-packager shape).
- `crates/core/tests/config_parsing_tests.rs` — NfpmConfig parsing coverage (formats, contents enum, subfield blocks).
- Parallel packaging integration: commit `dc0fb7a "packaging parallelism + per-packager ConventionalFileName"` touched this codepath.

## Known limitations

- **archlinux / ipk formats**: wired + test-covered but no production release exercises them (cfgd only configures deb/rpm/apk).
- **termux.deb**: same — wired but unrun.
- **Pro `if` / `templated_contents` / `templated_scripts`**: wired per §5.closures remediation (2026-04-18) but no cfgd/anodize production config uses these.
- **NFPM_*_PASSPHRASE signing**: deb/rpm signature wiring exists; neither production release sets passphrase env, so no live-signed package proof.
