# Pro feature: signs[].if

**Docs:** https://goreleaser.com/customization/sign/ (fetched 2026-04-18)
**Anodize site:** crates/stage-sign/src/lib.rs:373 (`process_sign_configs`) + config.rs:`SignConfig.if_condition`
**Status:** implemented

## Contract
`signs[].if` is a Pro-only templated conditional. Rendered to "false" or empty → skip that sign config (not sign anything); rendered to any other value → proceed. Errors in the template must be fatal (silently skipping would ship an unsigned release).

## Contract divergences
- [OK] crates/stage-sign/src/lib.rs:404-428 — `if_condition` hard-bails on render failure with `anyhow::bail!` citing "silent skip would ship unsigned artifacts." Matches the required strictness.
- [OK] Semantics: trimmed "" or "false" → skip (opt-in). Inverse of `disable:` per docstring at 399-403. Matches GoReleaser.
- [SUGGEST] crates/stage-sign/src/lib.rs:107 — `resolve_signature_path` renders the `signature` template with `.unwrap_or_else(|e| log.warn(...); format!("{}.sig", artifact_path))`. If a user writes a typo in their signature template (e.g., `{{ .Teg }}`), they'll silently get `{artifact}.sig` — which may overwrite an existing sig file from a previous run or shadow the intended output. A template-render failure here should be fatal, same rationale as the `if` branch. Why it matters: a sig path divergence means downstream `release` publishes a sig that doesn't match what operators expected to publish.

## Failure-mode coverage
- Render failure on `if` → hard bail ✓
- Empty trimmed result → skip, logged verbose + remember_skip ✓
- Render failure on sign args (cmd args): crates/stage-sign/src/lib.rs:650-655 falls back silently with a warn. A typo in `{{ .Env.GPG_FINGERPRINT }}` → warn-only → executes sign with raw literal arg, likely fails the sign cmd with a confusing error. Should be fatal.
- Render failure on `signature:` template → silent fallback to `{artifact}.sig` (see SUGGEST above).
- Render failure on `certificate:` template (lib.rs:608-614) → silent fallback to preprocessed string. Same class of bug.

## Idempotency + retry safety
Signing is not idempotent: running twice overwrites the prior `.sig`. This is acceptable — cosign/gpg sigs are deterministic per-key. No half-written state after failure (child process writes to disk via `--output` args).

## Secret hygiene
- stdin/stdin_file: passed as `Stdio::piped()` bytes, never argv-visible. crates/stage-sign/src/lib.rs:282-314. ✓
- env: rendered per-value and passed via `command.envs()`. crates/stage-sign/src/lib.rs:295-297. ✓
- Output redaction: `redact_string` scans env for `*_KEY`/`*_SECRET`/`*_PASSWORD`/`*_TOKEN` suffixes and value prefixes (`ghp_`, `sk-`, `dckr_pat_`, `glpat-`). crates/core/src/redact.rs:7-35. Applied to both stdout AND stderr BEFORE `check_output`, so error messages from failed signing commands don't leak. crates/stage-sign/src/lib.rs:330-361. ✓
- [WARN] crates/stage-sign/src/lib.rs:1020-1026 — docker_signs default args include `"--key=cosign.key".to_string()`. The literal string "cosign.key" is assumed to be a file on disk; harmless. But if a user sets `cmd: cosign` with defaults they'll get a surprising config-free invocation. No secret leak.
- Redact threshold MIN_SECRET_LEN=10 (crates/core/src/redact.rs:24). Some secrets like short GitHub PAT prefixes might not fully match; tolerable.

## Test coverage
- `test_resolve_sign_args` lib.rs:1346 — covers arg template substitution. ✓
- `test_filter_artifacts_*` 1359-1477 — covers `artifacts: checksum|all|none|archive|source|binary|package|installer|diskimage|sbom|snap|any`. ✓
- `if_condition` render-failure path: grep for `if_condition.*bail` in test files → **no test**. Missing: a test case that puts `if: "{{ .Nope }}"` and asserts `run()` returns Err (not just skip).
- `if_condition` skip-on-empty: **no test** (config struct tests exist but no end-to-end skip verification).
- redact.rs has its own unit tests covering GPG/cosign patterns. ✓

## Suggested invariants
1. For every `sign` job that starts, either a `.sig` is emitted and registered as `ArtifactKind::Signature` OR the stage returns Err. Never partial (signature-registered-but-file-missing).
2. No secret string from `env:` appears literally in stdout/stderr/error messages after redaction.
3. `if_condition` render errors propagate as Err, never as silent skips.
4. `certificate:` and `signature:` template render errors propagate as Err (see SUGGEST).

## Findings summary
- BLOCKER: 0
- WARN: 1 (docker_signs default cosign.key literal assumption — docs-surprise)
- SUGGEST: 2 (signature/certificate template render silent-fallback; add missing `if_condition` end-to-end tests)
- CONFIRMED-WORKING: 5 (secret hygiene, stdin piping, if-condition hard-bail, idempotency, artifact registration)

## Blocker status for A10
Ship-blocking: none. The `signature:` template silent-fallback is a pre-existing W3 class tracked since v0.0.1; still a correctness SUGGEST.
