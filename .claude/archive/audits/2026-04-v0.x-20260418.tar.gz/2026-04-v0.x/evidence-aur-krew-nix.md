# Evidence — AUR / Krew / Nix (§2.11)

**Category:** publish-aur, publish-krew, publish-nix
**Status:** partial (wired + CI passes secrets but external index-repo outcomes not independently verified)
**Tier:** OSS
**Ecosystem relevance:** strongly-suggested (aurs[], nix[]); niche (aur_sources[], krews[])

## Covered feature rows

- aurs[], name/ids/homepage/description/maintainers/contributors/license/private_key/git_url, skip_upload/provides/conflicts/depends/optdepends/backup/package/install/commit_msg_template, goamd64/git_ssh_command/url_template/directory/disable
- aur_sources[]
- krews[], ids/goarm/goamd64/url_template/commit_msg_template/homepage/description/short_description/caveats/skip_upload
- nix[], name/ids/goamd64/url_template/commit_msg_template/path/homepage/description/license/skip_upload, dependencies/install/extra_install/post_install/formatter

## Proof

### Release-tag proof

- **cfgd v0.3.5** — configured:
  - nix (`/opt/repos/cfgd/.anodize.yaml:221-229`) → `tj-smith47/nix-pkgs`
  - krew (`/opt/repos/cfgd/.anodize.yaml:230-242`) → `tj-smith47/krew-index`
- AUR is not configured in cfgd v0.3.5 (wired in code but not exercised).

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — env `NIX_PKGS_TOKEN` + `KREW_INDEX_TOKEN` passed.
- Fix specifically for krew: commit `128e003 "krew default upstream + per-crate previous_tag prefix filter"`.
- Fix for krew description: commit `275ed35 "krew description + bump ANODIZE_REV"`.

### Tests

- Unit tests in `crates/stage-publish/src/aur.rs`, `aur_source.rs`, `krew.rs`, `nix.rs` (all have `#[cfg(test)]`).
- Krew ELF-parser (architecture detection) — commit-log shows this as a completed parity item.
- Nix ELF parser for architecture detection — wired.

## Known limitations

- **aurs[] / aur_sources[]**: AUR wiring present + tested but no production release exercises it.
- Downstream index repo state (krew-index, nix-pkgs) not independently verified by archivist; partial pending tap-PR URL capture.
