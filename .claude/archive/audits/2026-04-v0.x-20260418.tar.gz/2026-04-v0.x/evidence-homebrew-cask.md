# Evidence — Homebrew / Cask (§2.9)

**Category:** publish-homebrew
**Status:** partial (wired + tested but no production release completed a Homebrew tap PR end-to-end that the archivist has observed)
**Tier:** OSS + Pro
**Ecosystem relevance:** required (brews[], name, ids/goarm/goamd64, homepage/description/license/caveats, install/extra_install/post_install/test, dependencies, repository); strongly-suggested (url_template/headers/download_strategy, custom_require/block, conflicts, commit_msg_template/directory, skip_upload, PR workflow, git fallback, commit_author); niche (service/plist, Pro alternative_names, Pro PR check_boxes, Pro app DMG, casks block, casks hooks/service/zap/uninstall/url.*, generate_completions_from_executable)

## Covered feature rows

- brews[] / homebrew_formulas[], name, Pro alternative_names, ids/goarm/goamd64
- url_template/url_headers/download_strategy/custom_require/custom_block
- homepage/description/license/caveats, install/extra_install/post_install/test
- dependencies (name/os/type/version), conflicts, service/plist, commit_msg_template/directory, skip_upload
- repository.*, Pro PR check_boxes, repository.git (url/private_key/ssh_command), commit_author (signing)
- Pro homebrew.app (DMG)
- homebrew_casks[], binaries/app/manpages/completions (bash/zsh/fish), generate_completions_from_executable, url.* (template/verified/using/cookies/referer/headers/user_agent/data), hooks (v2.13+), service/zap/uninstall

## Proof

### Release-tag proof

- **cfgd v0.3.5** — `homebrew:` block at `/opt/repos/cfgd/.anodize.yaml:183-195` targets `tj-smith47/homebrew-tap` (Formula directory). Release ran through cfgd release.yml run 24442230191 with `HOMEBREW_TAP_TOKEN` secret. The homebrew tap repository (out-of-tree) carries the generated Formula — archivist cannot confirm the PR outcome from this vantage but the upstream secret + config wiring exercised the code path.

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — env `HOMEBREW_TAP_TOKEN: ${{ secrets.HOMEBREW_TAP_TOKEN }}` passed through.
- Related fixes: commit `5165fc6 "query upstream default_branch for PR base — unblocks winget (master)"` also impacts homebrew PR flow.

### Tests

- Unit tests in `crates/stage-publish/src/homebrew.rs` (has `#[cfg(test)]` per grep).

## Known limitations

- **homebrew_casks[]**: wired in `crates/stage-publish/src/cask.rs` equivalent logic, but neither cfgd nor anodize configure casks (both publish as formula). No production proof for cask-specific fields.
- **Pro app (DMG)**: Pro feature wired; no release uses it.
- **repository.git SSH fallback / commit_author.signing**: wired; production uses GitHub token, not SSH+signing.
- **generate_completions_from_executable**: wired; no config uses it (Formula test block only).
- Status is **partial** because the archivist cannot independently verify the homebrew-tap PR landed successfully from this vantage (the external repo state is out-of-tree). Elevate to ✅ when the next release produces a visible tap PR URL recorded in the run logs.
