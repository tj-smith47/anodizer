# Pro feature: --id flag (CLI)

**Docs:** https://goreleaser.com/pro/ (fetched 2026-04-18)
**Anodize site:** cli/src/lib.rs (via `--crate` alias)
**Status:** implemented (aliased)

## Contract
Pro: `--id` filters release to a specific build id. Anodize uses `--crate <NAME>` instead since Rust workspaces are the common multi-build pattern.

## Contract divergences
- [WARN] Name divergence: `--id` (GoReleaser) vs `--crate` (anodize). Users migrating from GoReleaser will type `--id` and get a clap error. Suggest adding `--id` as a clap alias to reduce friction.
- [OK] Semantics match: both filter the build set to a named entry.

## Failure-mode coverage
- Unknown crate name: clap should error. Verify via `anodize release --crate nonexistent`.
- Multiple `--crate` invocations: clap typically accepts Vec<String>; confirm.

## Idempotency + retry safety
Pure filter. Idempotent.

## Secret hygiene
N/A.

## Test coverage
- Unit tests for `selected_crates` propagation should exist in cli tests.

## Suggested invariants
1. `--crate foo` filters ALL downstream stages (build, archive, sign, ...) to only crate `foo`. Never partial.
2. `--crate <invalid>` bails early with unknown-crate error — not after building 0 artifacts.

## Findings summary
- BLOCKER: 0
- WARN: 1 (no `--id` clap alias — DX friction for GoReleaser migrants)
- SUGGEST: 1 (verify invalid --crate bails early, not empty-artifact-late)
- CONFIRMED-WORKING: 2 (selected_crates filter, config wiring)
