# Evidence — Artifacts / Metadata / Auth / Rust-additive (§2.17 + §3)

**Category:** misc, hooks, template-helpers (rust-additive)
**Status:** ✅ release-tag proof
**Tier:** OSS (+ anodize-additive)
**Ecosystem relevance:** required (dist/artifacts.json, dist/metadata.json, GITHUB_TOKEN/GITLAB_TOKEN/GITEA_TOKEN, announcer secret env vars); strongly-suggested (dist/config.yaml effective config, version_sync, binstall metadata, skip memento, SkipMemento, parallelism helper, ConventionalFileName per-packager, `targets --json`, `resolve-tag`, ANODIZE_CURRENT_TAG/PREVIOUS_TAG, tag hooks, UPX target-triple glob, GORELEASER_FORCE_TOKEN); niche (continue_on_error — missing)

## Covered feature rows

- dist/artifacts.json (emitted end-of-pipeline)
- dist/metadata.json (emitted end-of-pipeline)
- dist/config.yaml (effective config emitted, build parity 2026-04-16)
- GITHUB_TOKEN / GITLAB_TOKEN / GITEA_TOKEN / ForceTokenKind / GORELEASER_FORCE_TOKEN
- **Rust-additive features** (§3):
  - crates.io publish (unique to anodize; see evidence-publish-misc-blob.md)
  - cargo-binstall metadata
  - Cargo-workspace tag→crate resolution
  - version_sync (Cargo.toml ↔ tag alignment)
  - SkipMemento (operator-visible skip summary)
  - ConventionalFileName per-packager (nfpm v2.44 compat)
  - Parallelism helper (`run_parallel_chunks`)
  - `targets --json` subcommand (for anodize-action split matrix)
  - `resolve-tag` subcommand
  - ANODIZE_CURRENT_TAG / ANODIZE_PREVIOUS_TAG env overrides
  - Tag hooks (`tag_pre_hooks` / `tag_post_hooks`)
  - UPX target-triple glob

## Proof

### Release-tag proof

- **anodize v0.2.5** — https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — assets include `artifacts.json` + `metadata.json` at the release tier (direct evidence of dist/ emission; anodize-action's `artifacts` and `metadata` outputs map to these).
- **cfgd v0.3.5** — asset `artifacts.json` attached at release.
- `version_sync: {enabled: true, mode: cargo}` exercised in `/opt/repos/cfgd/.anodize.yaml:109-111` and `:181-183` — commit `c1de526 "version_sync Cargo.toml before tagging"` + `ce3e396 "version_sync updates workspace deps"` + `85108ea "version_sync must regenerate Cargo.lock before committing"`. v0.3.5 succeeded → version_sync proven live.
- `binstall:` block in `/opt/repos/cfgd/.anodize.yaml:157-162` — produces cargo-binstall hints in Cargo.toml for cfgd v0.3.5.

### CI workflow runs

- cfgd release.yml — `resolve` job uses `anodize resolve-tag` via anodize-action `resolve-workspace: true`: https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — outputs `workspace` + `has-builds` consumed by downstream jobs.
- `anodize targets --json` is exercised by anodize-action's `split-matrix` output (Action inventory §2 item "split-matrix").
- SkipMemento commit `1c70bc9 "shared parallelism + skip-memento + tag hooks + ignore_tags wiring"` — wired and visible in release logs; cfgd v0.3.5 workspace has `skip: [announce]` which the memento reports.
- Tag hooks: commit `1c70bc9` + `c1de526` — wired via `tag_pre_hooks` / `tag_post_hooks` on `anodize tag` command.

### Tests

- `crates/cli/tests/integration.rs::test_e2e_build_command_matches_goreleaser_pipeline_outputs` (line 3617) — golden artifacts.json + metadata.json.
- `crates/cli/tests/integration.rs::test_e2e_snapshot_version_in_artifacts` (line 2587)
- `crates/cli/tests/bump_integration.rs` — full 917-line suite covering tag + version_sync + bump inference.

## Known limitations

- **continue_on_error** per-stage (niche missing): anodize is fail-fast by default; documented in §5.
- **GITLAB_TOKEN / GITEA_TOKEN** env resolution: wired but only GITHUB_TOKEN path exercised in production.
