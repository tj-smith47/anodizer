# Pro feature: app_bundles[] (macOS .app)

**Docs:** https://goreleaser.com/customization/app_bundles/ (fetched 2026-04-18)
**Anodize site:** crates/stage-appbundle/src/lib.rs:263 (`if_condition` gate); config at core/src/config.rs:3667
**Status:** implemented

## Contract
Produces macOS `.app` bundles (directory-based bundles). Fields: `id`, `name`, `if`, `ids`, `bundle_id`, `icon`, `info_plist`, `extra_files`, `replace`, `mod_timestamp`.

## Contract divergences
- [OK] `if_condition` hard-bail pattern consistent.
- [OK] Emits `ArtifactKind::Installer` with `metadata.format=appbundle` — required by stage-notarize:564 which filters on this exact metadata key to find bundles to sign. Critical downstream contract.
- [SUGGEST] `Info.plist` template-rendering: if the template fails mid-render, the resulting plist may be malformed and silently propagate to the signed bundle. Verify render errors bail.

## Failure-mode coverage
- Missing icon file → bubble via `?`
- `info_plist` template render error → should bail; verify file:line
- `if` render error → hard-bail (per config.rs:3667 wiring)

## Idempotency + retry safety
Output directory `{ProjectName}.app/` — `create_dir_all` idempotent, file copies overwrite. Acceptable.

## Secret hygiene
No credentials. Codesigning happens at stage-notarize.

## Test coverage
- Command tests expected in lib.rs::mod tests (1745 lines suggests comprehensive).

## Suggested invariants
1. Registered `ArtifactKind::Installer` with `metadata.format="appbundle"` — stage-notarize depends on this exact string.
2. `Info.plist` always contains rendered `CFBundleIdentifier` matching `bundle_id` config.
3. Nested `Contents/MacOS/<bin>` has +x permission (for downstream notarization to succeed).

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 2 (Info.plist render-error propagation, executable bit invariant)
- CONFIRMED-WORKING: 4 (if hard-bail, metadata.format contract, extra_files, dry-run)

## HANDOFF items
Live macOS app bundle build + signing + notarize staple — requires Apple Developer team ID + installed cert; see HANDOFF.md.
