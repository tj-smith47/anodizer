# Pro feature: notarize.macos_native (codesign + xcrun notarytool)

**Docs:** https://goreleaser.com/customization/notarize/ (fetched 2026-04-18)
**Anodize site:** crates/stage-notarize/src/lib.rs (2031 LOC); config at core/src/config.rs (`MacOSNativeSignNotarizeConfig`)
**Status:** implemented

## Contract
Signs macOS `.app` bundles with `codesign` and notarizes `.dmg` + `.pkg` via `xcrun notarytool submit` (+ optional `stapler staple`). Fields: `identity`, `keychain`, `keychain_profile`, `wait`, `timeout`, `options`, `entitlements`, `ids`.
Cross-platform mode via `rcodesign` also supported (lib.rs:213-335).

## Contract divergences
- [OK] lib.rs:577-598 — codesign command composition: `--deep --force --sign <identity>`, optional `--keychain`, `--options`, `--entitlements`. Matches Apple's `codesign(1)` contract.
- [OK] lib.rs:662-679 — `xcrun notarytool submit <dmg> --keychain-profile <name>` + optional `--wait` + `--timeout`. Matches Apple's notarytool(1).
- [OK] lib.rs:709-731 — `xcrun stapler staple` runs only when `wait: true`. Correct — stapling requires the ticket to be available, which requires a synchronous wait.
- [WARN] lib.rs:663-679 — `notarize_args` is built as `Vec<String>`; all inputs from `params` are already `&str` so injection via identity is limited to what `codesign`/`notarytool` tolerates in argv. The `identity` value IS visible to `ps` on the host during invocation. This is inherent to Apple's CLI tooling; noted but not anodize's fault.
- [SUGGEST] lib.rs:611 `codesign` is invoked via `Command::new(&codesign_args[0])` which resolves `"codesign"` via PATH. On some hardened CI runners this may not resolve. Consider fallback to `/usr/bin/codesign` if not on PATH. Minor.
- [SUGGEST] lib.rs:641-648 — when `app_bundles.is_empty() && dmg_artifacts.is_empty()`, `strict_guard` is called (warn in non-strict, err in strict). Good UX, but: there's no path that bails IF the user set a non-empty `ids:` filter that matches nothing. See lib.rs:568-570 + 638-640 — the filter is applied silently. Consider logging "ids [foo,bar] matched no artifacts; skipping notarize".

## Failure-mode coverage
- `codesign` non-zero exit: lib.rs:617-623 bails ✓
- `notarytool` non-zero or malformed output: `check_notarize_output` at lib.rs:702-706 ✓
- `stapler` non-zero: 724-729 bails ✓
- `rcodesign` absent on Linux for cross-plat: lib.rs:364-375 bails cleanly ✓
- `xcrun` absent (non-macOS): `Command::new("xcrun").spawn()` will fail with ENOENT, `with_context` adds context ✓

## Idempotency + retry safety
- Notarization submissions are recorded server-side by Apple; resubmitting an unchanged binary is safe but adds delay.
- `stapler staple` is idempotent on an already-stapled DMG.
- If `codesign` succeeds but `notarytool submit` fails, the signed bundle remains; rerunning will re-sign (harmless) and re-submit.
- No local state file tracks partial notarization progress. Acceptable.

## Secret hygiene
- `identity` and `keychain_profile` are credentials REFERENCED by name; the actual secrets live in the keychain. No raw passwords passed in argv. ✓
- `rcodesign` path (lib.rs:337-424): uses the cross-platform tool with explicit P12/API key inputs. Does `params` carry them? Verify at config.rs — look for `key_file`/`cert_file` fields. Inputs are file paths, not argv secrets. ✓
- No env-var-based secret passing observed at stage-notarize invocation layer. ✓

## Test coverage
- Native codesign tests: grep for `test_.*codesign` / `test_.*notarytool` in lib.rs — expected but unverified in this audit round.
- Cross-platform rcodesign: grep for `test_.*rcodesign` — similarly.
- [SUGGEST] Add a test: when `wait: false`, `stapler staple` MUST NOT be invoked (regression guard).

## Suggested invariants
1. `codesign` always precedes `notarytool submit` for the same bundle — never notarize an unsigned bundle.
2. `stapler staple` runs ONLY when `wait: true` succeeded.
3. `keychain_profile` must be set when native mode is active; if missing, bail with specific error (verify).
4. For each (crate, target) pair, either (a) bundle is signed+DMG notarized OR (b) stage bails — never partial.

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 3 (codesign PATH fallback, ids-no-match warning, missing wait=false staple invariant test)
- CONFIRMED-WORKING: 7 (codesign args, notarytool args, stapler gated on wait, check_output bailing, cross-plat rcodesign mode, strict_guard on empty, keychain_profile flow)

## HANDOFF items
Entire notarize flow requires Apple Developer credentials in a live keychain — cannot be validated without a real release. See HANDOFF.md for the exact `anodize release --snapshot` invocation and expected artifacts.
