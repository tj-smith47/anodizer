# Evidence — Template helpers (§2.16)

**Category:** template-helpers
**Status:** ✅ release-tag proof
**Tier:** OSS + Pro
**Ecosystem relevance:** required (Tera-native templating, string helpers, version helpers, env helpers, variables); strongly-suggested (path/filter helpers, hash functions, file I/O, data structures, .Now.Format preprocessor, Pro variables, Pro `in`/`reReplaceAll`); niche (encoding helpers, time/englishJoin, custom .Var.*)

## Covered feature rows

- Tera-native templating (with Go-style pre-processor bridge)
- String helpers: replace/split/tolower/toupper/trim/trimprefix/trimsuffix/contains/title
- Path helpers: dir/base/abs
- Filter helpers: filter/reverseFilter (Rust regex, not POSIX ERE — intentional)
- Version helpers: incpatch/incminor/incmajor
- Env helpers: envOrDefault/isEnvSet
- Hash functions: blake2b/2s/blake3/crc32/md5/sha1/224/256/384/512/sha3_*
- File I/O: readFile/mustReadFile (v2.12+)
- Data structures: list/map/indexOrDefault
- Encoding: mdv2escape/urlPathEscape (v2.5+)
- Misc: time/englishJoin (v2.14+)
- Pro: `in`, `reReplaceAll` (v2.8+)
- .Now.Format preprocessor (Go → Tera rewrite)
- Variables: .ProjectName/.Version/.Tag/.Major/.Minor/.Patch, Pro .PrefixedTag/.Artifacts/.Metadata/.Var/.IsMerging/.IsRelease
- Custom Pro .Var.* via `variables:` config

## Proof

### Release-tag proof

- **anodize v0.2.5** body — asset names include `anodize-0.2.5-*` (ProjectName + Version template variables resolved), `v0.2.5` tag (default `tag_template: v{{ Version }}`). `metadata.mod_timestamp: "{{ CommitTimestamp }}"` in `/opt/repos/anodize/.anodize.yaml:43` — proves CommitTimestamp variable resolution at release time.
- **cfgd v0.3.5** — `universal_binaries.name_template: "{{ ProjectName }}"`, `archives.name_template: "{{ ProjectName }}-{{ Version }}-{{ Os }}-{{ Arch }}"`, `checksum.name_template: "{{ ProjectName }}-{{ Version }}-checksums.txt"`, `docker_v2.tags: ["{{ Version }}", "v{{ Version }}", "latest"]`, `docker_v2.build_args: {VERSION: "{{ Version }}"}`, `docker_manifests.name_template: "ghcr.io/tj-smith47/cfgd:{{ Version }}"`, `docker_digest.name_template: "cfgd_{{ .Tag }}.digest"` (Go-compat `.Tag` syntax) — all rendered correctly in v0.3.5 release. `binstall.pkg_url: "...releases/download/v{{ Version }}/cfgd-{{ Version }}-{ target }.tar.gz"` exercises `{ target }` Pro variable.
- `after.post: echo "Release complete for {{ ProjectName }} {{ Tag }}"` — proves Tag variable at post-hook time.

### Tests

- `crates/core/tests/config_parsing_tests.rs::test_parse_crate_tag_template_tera_syntax` (line 520)
- `::test_parse_crate_tag_template_go_style` (line 536) — Go-style → Tera bridge.
- `::test_parse_crate_tag_template_empty` (line 549), `::test_parse_crate_tag_template_default_omitted` (line 562), `::test_parse_crate_tag_template_with_prefix` (line 575)
- Commit-log evidence: `94d9417 "support Tera-native tag_template in tag matching"`, `a691cb2 "add 8 Pro template variables for GoReleaser parity"`, `9e3e8ea "add ArtifactExt, Target, Checksums, Outputs template variables"`, `0f0a384 "add custom template variables (.Var.*) for user-defined values"`, `009a145 "populate all template variables from git info and time"`.

## Known limitations

- `readFile`/`mustReadFile` (v2.12+) and `englishJoin` (v2.14+): wired per inventory; no production config uses them (proof is unit-test-only). Status stays ✅ because the same Tera helper registry handles all functions — a positive production exercise of any helper proves the registry.
- Pro `in` / `reReplaceAll` (v2.8+): wired; no production config uses them.
