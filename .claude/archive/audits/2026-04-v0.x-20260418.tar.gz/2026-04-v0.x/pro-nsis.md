# Pro feature: nsis[] (Windows NSIS installer)

**Docs:** https://goreleaser.com/customization/nsis/ (fetched 2026-04-18)
**Anodize site:** crates/stage-nsis/src/lib.rs:124 (`if_condition` gate); config at core/src/config.rs:3631
**Status:** implemented

## Contract
Produces Windows `.exe` installers using NSIS. Fields: `id`, `name`, `if`, `ids`, `template`, `extra_files`, `replace`, `mod_timestamp`. Tool: `makensis`.

## Contract divergences
- [OK] `if_condition` hard-bail pattern consistent with other packagers.
- [OK] Per inventory line 357: `goamd64` n-a (Rust target triples have no amd64 sub-revisions).
- [SUGGEST] Verify `template:` supports both inline string AND path-to-.nsi-file. Docs allow both forms.

## Failure-mode coverage
- `makensis` missing → clean bail
- Template render error on `name:` / `if:` → hard-bail
- extra_files glob error → bubble `?` with context
- `makensis` non-zero exit → `check_output` bails

## Idempotency + retry safety
Standard staging pattern. Final `.exe` overwritten on rerun.

## Secret hygiene
No credentials.

## Test coverage
- Unit tests for command composition expected at end of lib.rs.
- Live Windows build gated by `makensis` binary.

## Suggested invariants
1. Every successful NSIS run registers one `ArtifactKind::Installer` per (crate, target) with `format=nsis`.
2. `if` render failure propagates as Err.

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 1 (template inline vs file form coverage)
- CONFIRMED-WORKING: 4 (if hard-bail, extra_files, dry-run, makensis detection)

## HANDOFF items
Live Windows NSIS build required for end-to-end verification; see HANDOFF.md.
