# Pro feature: --split flag

**Docs:** https://goreleaser.com/pro/ (fetched 2026-04-18)
**Anodize site:** cli/src/commands/release/split.rs:92 (`run_split`); cli/src/commands/release/mod.rs:456 (dispatch)
**Status:** implemented

## Contract
Pro: `--split` runs ONLY the build pipeline filtered to the partial target, writes context.json to `dist/<subdir>/`. See `pro-partial-builds.md` for the full audit — `--split` is the CLI front-end for the partial build machinery.

## Contract divergences
- See pro-partial-builds.md — all contract details are shared.
- [OK] mod.rs:456 references `--split: run only the build stage, serialize artifacts to dist/, then exit`.
- [SUGGEST] `--split` is mutually exclusive with `--merge` — verify clap enforces this.
- [SUGGEST] `--split` with `--prepare` combination: does the skip-list augmentation from `--prepare` still apply? Probably irrelevant since `--split` only runs build. Verify.

## Failure-mode coverage
- See pro-partial-builds.md.

## Idempotency + retry safety
- See pro-partial-builds.md.

## Secret hygiene
- See pro-partial-builds.md's WARN about `env_vars` in context.json.

## Test coverage
- split.rs unit tests; see pro-partial-builds.md.

## Findings summary
- Cross-reference: see pro-partial-builds.md for full findings.
- BLOCKER: 0 (this file)
- WARN: 0 (this file — see partial-builds.md for the shared WARNs)
- SUGGEST: 2 (clap --split + --merge mutex; --split + --prepare interaction)
- CONFIRMED-WORKING: refer to pro-partial-builds.md

