# Pro feature: metadata.mod_timestamp / maintainers / license / homepage / description / full_description

**Docs:** https://goreleaser.com/customization/metadata/ (fetched 2026-04-18)
**Anodize site:** core/src/config.rs:4479 (`MetadataConfig`); core/src/context.rs:686-773 (`populate_metadata_var`)
**Status:** implemented (with `full_description.from_url` partial)

## Contract
Pro: `metadata` block supplies project-level defaults that propagate to nfpm, homebrew, scoop, docker, etc. Fields: `mod_timestamp`, `maintainers`, `license`, `homepage`, `description`, `full_description`, `commit_author`.

`full_description` accepts `ContentSource` (inline | from_file | from_url).

## Contract divergences
- [OK] config.rs:4479 — `MetadataConfig` struct present with all field names matching docs.
- [OK] config.rs:4497 — `full_description: Option<ContentSource>` — enum variant handles Inline/FromFile/FromUrl.
- [PARTIAL] context.rs:752-755 — **`from_url` errors explicitly** with message "`from_url` is not yet supported at metadata context time (core has no HTTP client)". Per inventory line 376: this is a known `partial`. Inline + FromFile work.
- [OK] context.rs:1763 `test_populate_metadata_var_full_description_inline` ✓
- [OK] context.rs:1781 `test_populate_metadata_var_full_description_from_file` ✓
- [OK] context.rs:1802 `test_populate_metadata_var_full_description_from_url_errors` — verifies the clear error message. ✓
- [WARN] Diverges from docs: GoReleaser Pro docs imply `from_url` works at `metadata` time. Anodize deliberately defers to reuse the release-stage HTTP client. Known gap; acceptable per the inventory classification.
- [SUGGEST] Consider reusing `stage-release::resolve_content_source` by moving HTTP client into core. Would close the partial.

## Failure-mode coverage
- FromUrl set → hard-fail with actionable message directing user to `from_file` instead ✓
- FromFile path render error: bubble `?` ✓
- FromFile read error: bubble `?` with path in message ✓

## Idempotency + retry safety
Pure read/compute. Idempotent.

## Secret hygiene
N/A — metadata is intended public info. If a user puts secrets in `maintainers` / `homepage`, that's their bug.

## Test coverage
- `test_populate_metadata_var_full_description_inline` ✓
- `test_populate_metadata_var_full_description_from_file` ✓
- `test_populate_metadata_var_full_description_from_url_errors` ✓
- Missing: integration test — when metadata.full_description is set, does it propagate to nfpm descriptions? To homebrew formula? Probably elsewhere but worth verifying.

## Suggested invariants
1. `.Metadata.FullDescription` template variable equals the resolved content (Inline or FromFile) or the stage bails.
2. `from_url` never silently succeeds; always errors actionably.

## Findings summary
- BLOCKER: 0
- WARN: 1 (from_url partial — known, documented gap)
- SUGGEST: 1 (close the partial by moving HTTP client to core)
- CONFIRMED-WORKING: 5 (struct parse, all three ContentSource variants handled, tests for each, `from_url` explicit error)

## Blocker status for A10
None. The partial is a niche gap per inventory.
