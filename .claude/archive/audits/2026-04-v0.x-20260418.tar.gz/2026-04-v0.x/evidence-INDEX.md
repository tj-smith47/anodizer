# Evidence Index — Wave C Cycle 2 Dogfooding Matrix

> **Scope.** Proof-gathering pass for the anodize v0.x ↔ GoReleaser parity inventory
> (`/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md`) and the
> anodize-action ↔ goreleaser-action inventory (`...goreleaser-action-feature-inventory.md`).
>
> **Method.** Cluster per §2.1-§2.17 of the inventory (one file per feature cluster, ≈13-18 row rows per cluster), cross-referencing:
>
> - **Release-tag proof** — `gh release view` on anodize v0.2.5 (2026-04-15) + cfgd v0.3.5 (2026-04-15).
> - **CI workflow runs** — `gh run list` on anodize and cfgd (real `tj-smith47/anodize-action@master` consumers).
> - **Tests** — `crates/cli/tests/integration.rs` (120 tests, 3719 LOC), `crates/cli/tests/bump_integration.rs` (917 LOC), `crates/core/tests/config_parsing_tests.rs` (490 tests, 4466 LOC).
> - **Self-config evidence** — `/opt/repos/anodize/.anodize.yaml` (648 LOC) + `/opt/repos/cfgd/.anodize.yaml` (560 LOC).
>
> cfgd is **first-class evidence** — its multi-workspace monorepo (core/cfgd/operator/csi) end-to-end dogfoods anodize-action and exercises publishers + docker + nfpm + snap + makeself + SBOM + signing in a single tag push.

## Sort: tier (OSS first) → status (✅ → partial → ❌ informational) → name

| Feature cluster | Status | Tier | Proof types | File |
|---|---|---|---|---|
| Builds (§2.1) | ✅ | OSS | release-tag + CI run + tests + self-config | [evidence-builds.md](evidence-builds.md) |
| Archives + Source (§2.2) | ✅ | OSS + Pro | release-tag + tests + self-config | [evidence-archives.md](evidence-archives.md) |
| Checksums (§2.3) | ✅ | OSS + Pro | release-tag + tests + self-config | [evidence-checksums.md](evidence-checksums.md) |
| Release / SCM (§2.4) | ✅ | OSS + Pro | release-tag + CI run + tests | [evidence-release-scm.md](evidence-release-scm.md) |
| Changelog (§2.5) | ✅ | OSS + Pro | release-tag body + CI run + tests | [evidence-changelog.md](evidence-changelog.md) |
| Signing (§2.6) | ✅ | OSS + Pro | release-tag (sigs) + CI run + tests | [evidence-signing.md](evidence-signing.md) |
| Docker (§2.7) | ✅ | OSS + Pro | release-tag via cfgd + CI run + tests | [evidence-docker.md](evidence-docker.md) |
| nFPM + SRPM (§2.8) | ✅ | OSS + Pro | release-tag (deb/rpm/apk/srpm) + CI run + tests | [evidence-nfpm.md](evidence-nfpm.md) |
| SBOM / Snap / Flatpak / Installers / Notarize (§2.14) | ✅ (partial for installers) | OSS + Pro | release-tag (CDX SBOM + makeself + snap) + tests | [evidence-sbom-snap-flatpak-installers.md](evidence-sbom-snap-flatpak-installers.md) |
| Project / Global / CLI / Partial / Monorepo (§2.15) | ✅ | OSS + Pro | release-tag + CI run + tests + self-config | [evidence-project-global-cli.md](evidence-project-global-cli.md) |
| Template helpers (§2.16) | ✅ | OSS + Pro | release-tag (rendered asset names) + tests | [evidence-template-helpers.md](evidence-template-helpers.md) |
| Artifacts / Metadata / Auth / Rust-additive (§2.17 + §3) | ✅ | OSS + additive | release-tag assets + CI run + tests + self-config | [evidence-artifacts-metadata-auth.md](evidence-artifacts-metadata-auth.md) |
| Homebrew / Cask (§2.9) | partial | OSS + Pro | CI run + secret + tests (external tap unverified) | [evidence-homebrew-cask.md](evidence-homebrew-cask.md) |
| Scoop / Chocolatey / Winget (§2.10) | partial | OSS | CI run + secrets + tests (external repos unverified) | [evidence-scoop-chocolatey-winget.md](evidence-scoop-chocolatey-winget.md) |
| AUR / Krew / Nix (§2.11) | partial | OSS | CI run + secrets + tests (external indexes unverified) | [evidence-aur-krew-nix.md](evidence-aur-krew-nix.md) |
| Publish misc (publishers[], artifactory, uploads, fury, cloudsmith, blob, crates.io) (§2.12) | ✅ (crates.io); partial (rest) | OSS + Pro | release-tag (crates.io); config + tests (rest) | [evidence-publish-misc-blob.md](evidence-publish-misc-blob.md) |
| anodize-action inputs / outputs / caching / steps | ✅ (required); partial (semver + nightly) | OSS wrapper | release-tag workflow usage + CI runs | [evidence-action-inputs-outputs.md](evidence-action-inputs-outputs.md) |
| Announce providers (§2.13) | partial | OSS | unit tests (no production config uses announce) | [evidence-announce.md](evidence-announce.md) |
| Permanent negative space (§4) | informational (n-a) | mixed | negative-space doc + inventory §4 | [evidence-negative-space.md](evidence-negative-space.md) |

## Rollup

- **19 evidence files** covering all 19 clusters from the inventory + the action-layer file + negative-space.
- **217 feature rows** in the main inventory + **27 rows** in the action-layer inventory are mapped to these 19 files (cluster-per-category strategy per task's "2-3 closely-related is fine" guidance).
- **Released / dogfooded tags**: anodize v0.2.5 (latest), cfgd v0.3.5 (latest).
- **Released workflow runs cited**:
  - anodize release.yml — partial coverage (self-release workflow uses anodize-action with `from-artifact` + `from-source`).
  - cfgd release.yml run 24442230191 (tag `v0.3.5`) — https://github.com/tj-smith47/cfgd/actions/runs/24442230191
  - cfgd release.yml run 24442229349 (tag `core-v0.3.5`) — library-only path.

## Top features still needing live-release proof (for HANDOFF.md)

Listed in rough order of effort-to-prove (lowest first):

1. **Homebrew tap PR** — capture the downstream tap-PR URL in release logs (cfgd v0.3.5 ran, archivist cannot see tap-PR outcome from this vantage). Applies to homebrew formulas + casks.
2. **Scoop / Chocolatey / Winget** — same as homebrew; log the pkgs-repo PR URL or the publish-to-feed acknowledgement on the next release.
3. **Krew / Nix / AUR** — same as above; cfgd v0.3.5 configs krew + nix; AUR is not configured anywhere.
4. **GitLab + Gitea release providers** — no project publishes to GitLab/Gitea. Fix: publish `cfgd-core` (library-only; low risk) to a GitLab mirror as a next-release smoke test.
5. **Docker Hub description sync (Pro)** — cfgd ships to ghcr.io only. Fix: add a `dockerhub:` block for cfgd's next release; no real publish needed to prove the description-sync codepath.
6. **macOS Notarize (anchore/quill + Pro macos_native)** — no release notarizes. Fix: enable `notarize.macos` on cfgd's darwin binaries on next release.
7. **Flatpak + NSIS/DMG/MSI/PKG/AppBundle (Pro installers)** — no downstream project uses them. Fix: add an `nsis:` block to a cfgd release to flip its status; same pattern for DMG/PKG on darwin and AppBundle.
8. **Announce providers** — 13 providers, zero usage. Fix: add `announce.webhook:` or `announce.slack:` to cfgd with a test-channel webhook. Lowest-effort, highest-visibility win.
9. **Pro `continue` / `publish` / `announce --merge`** — partial coverage today (cfgd does --split + --merge on release). Fix: explicitly run `anodize publish --merge` and `anodize announce --merge` as named steps in a release so the logs contain the split-command invocation.
10. **blob publishing (s3/gs/azblob)** — no downstream project configures blob. Fix: publish cfgd's nightly to a test s3 bucket as a smoke test.
11. **artifactory / uploads / fury / cloudsmith** — niche; publish cfgd's deb/rpm to a community cloudsmith repo to flip 3 rows at once.

None of the "missing" items (man pages, `--soft`, `continue_on_error`, `mcp registry`, `metadata.full_description.from_url`) block the matrix — all are niche per inventory §5.

## Notes

- The inventory is authoritative; this index is the evidence trail. Any discrepancy is resolved in favor of the inventory text + cited source file:line.
- "partial" ≠ broken. It means the feature is wired + test-covered but the archivist has no independent external-repo-state or release-run proof. Elevate to ✅ when a captured run URL demonstrates the feature.
- `informational` (n-a) rows are permanent scope decisions, not failures.
- Today's date: 2026-04-18 (anodize v0.2.5 published 2026-04-15; cfgd v0.3.5 published 2026-04-15).
