# Pro feature: CLI continue / publish / announce (--merge)

**Docs:** https://goreleaser.com/pro/ (fetched 2026-04-18)
**Anodize site:** cli/src/commands/continue_cmd.rs; cli/src/commands/publish_cmd.rs; cli/src/commands/announce_cmd.rs
**Status:** implemented

## Contract
Pro: `anodize continue --merge` runs post-build pipeline (combining multiple split runs). `anodize publish` runs only the publish pipes. `anodize announce` runs only the announcers.

## Contract divergences
- [OK] cli/src/commands/continue_cmd.rs:40 — `ContextOptions { merge: true, ... }`. Hard-coded — `continue` always implies `--merge`. Matches docs.
- [OK] continue_cmd.rs:47-50 — sets up context then delegates to `release::run_merge`. Consistent with split/merge design in pro-partial-builds.md.
- [SUGGEST] continue_cmd.rs has no `--split` flag because `continue` is only merge. If a user types `anodize continue --split`, current UX should bail clearly. Verify clap setup in cli/src/lib.rs.
- [SUGGEST] When `continue` finds no `context.json` files, is the error message helpful? continue_cmd.rs delegates to `release::run_merge` at split.rs:289-300 which has a good error. ✓

## Failure-mode coverage
- No context.json: clean error (delegated to run_merge) ✓
- Corrupt context.json: bubble with context ✓
- Pipeline stage failure: bubble ✓

## Idempotency + retry safety
Re-running `continue` re-loads all context files and replays merge pipeline. Idempotent.

## Secret hygiene
Uses the same GH token flow as `release`. Inherit secrets from env, not argv.

## Test coverage
- Minimal (this file is only 52 lines) — most logic is in split.rs which HAS tests.
- Missing: test asserting `continue` without any split context exits non-zero.

## Suggested invariants
1. `anodize continue` NEVER runs build stages — only post-build.
2. Exit code is non-zero if no split context is found.

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 2 (clap validation for `continue --split`, end-to-end test for no-context case)
- CONFIRMED-WORKING: 3 (merge=true hard-coded, setup_context flow, delegation to run_merge)
