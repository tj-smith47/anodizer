# Evidence — SBOM / Snapcraft / Flatpak / Installers (DMG/MSI/PKG/NSIS/AppBundle/Makeself) / Notarize (§2.14)

**Category:** sbom, publish-snap, publish-flatpak, dmg, msi, pkg, nsis, appbundle, makeself, notarize
**Status:** ✅ release-tag proof for SBOM + Makeself + Snapcraft; partial for installers (DMG/MSI/PKG/NSIS/AppBundle wired + tested but not in cfgd v0.3.5 config) + flatpak + notarize
**Tier:** OSS + Pro
**Ecosystem relevance:** required (sboms[]); strongly-suggested (DMG/MSI/PKG/NSIS/AppBundle — Pro, notarize); niche (snapcrafts, flatpaks, makeselfs, macos_native notarize Pro)

## Covered feature rows

- sboms[] (syft), cmd/args/env/artifacts/ids/disable/documents
- snapcrafts[] + grade/confinement/base/plugs/slots/layout/apps/assumes/hooks/extra_files
- flatpaks[] + app_id/runtime/sdk/command/finish_args
- Pro dmgs[], Pro msis[] (Wix/wixl + hooks + extra_files), Pro pkgs[] (macOS .pkg), Pro nsis[] (Windows), Pro app_bundles[] (macOS .app)
- makeselfs[] (Linux self-extracting)
- notarize.macos (anchore/quill), Pro notarize.macos_native (codesign/xcrun)

## Proof

### Release-tag proof

- **cfgd v0.3.5** — https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5:
  - `cfgd-0.3.5.cdx.json` (CycloneDX SBOM) — `stage-sbom` proof.
  - `cfgd-0.3.5-{linux,darwin}-{amd64,arm64}-installer.run` (Makeself) — `stage-makeself` proof via `/opt/repos/cfgd/.anodize.yaml:95-100` `makeselfs:` block.
  - `cfgd_0.3.5_amd64.snap` + `cfgd_0.3.5_arm64.snap` (Snapcraft) — `stage-snapcraft` proof via `/opt/repos/cfgd/.anodize.yaml:231-250` `snapcrafts:` block.
- **anodize v0.2.5** — same shape: `anodize-0.2.5.cdx.json`, `anodize-0.2.5-{linux,darwin}-{amd64,arm64}-installer.run`, `anodize_0.2.5_{amd64,arm64}.snap`.

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — `install: nfpm,makeself,snapcraft,rpmbuild,cosign` via anodize-action installs all three tools; env `SNAPCRAFT_STORE_CREDENTIALS` passed for snap-store upload.

### Tests

- `crates/stage-sbom/src/` unit tests.
- `crates/stage-snapcraft/src/lib.rs` — unit tests present (has `#[cfg(test)]`).
- `crates/stage-makeself/src/lib.rs` — unit tests present.
- `crates/stage-dmg/`, `stage-msi/`, `stage-pkg/`, `stage-nsis/`, `stage-appbundle/` — all have `lib.rs` with `#[cfg(test)]` per earlier grep; gate-wiring verified 2026-04-18 in `/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md:354-358`.

## Known limitations

- **DMG/MSI/PKG/NSIS/AppBundle (all Pro)**: wired + unit-tested + feature-spec verified but no production release exercises them. anodize-action auto-install grep patterns miss `pkgs:` / `msis:` / `nsis:` / `dmgs:` / `appbundles:` (Action inventory §6 item 5) — installer tooling (productbuild/wixl/makensis/hdiutil) would need manual install or auto-install wiring. Elevate to ✅ when a downstream project ships a DMG/MSI/PKG/NSIS/AppBundle in a release.
- **flatpaks[]**: wired + tested; no production release uses it.
- **notarize.macos / macos_native**: wired (notarize stage + MacOSNativeSignNotarizeConfig); no production release notarizes macOS assets.
