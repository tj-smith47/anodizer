# Parity audit — build + archive slice — 2026-04-v0.x

Scope: all rows from the Parity Row Matrix sections 2.1 (Builds), 2.2 (Archives),
and build/archive-adjacent rows from 2.15 (Project / Global / CLI / Partial) and
2.17 (Artifacts JSON / effective config / tokens) in
`/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md`.

Filter rule: `ecosystem_relevance ∈ {required, strongly-suggested}` audited with
behavioral parity criteria. Rows marked `niche` listed informationally. Rows
marked `not-applicable` skipped (surfaced as bloat candidates only when also
`implemented` — see bloat.md).

Reference: `/opt/repos/goreleaser/` (OSS @ commit `f7e73e3`).
Implementation: `/opt/repos/anodize/crates/`.

## Summary
BLOCKER=0  WARN=3  SUGGEST=6  INTENTIONAL=3  (rows audited: 55, rows skipped not-applicable: 23, bloat candidates: 2, niche informational: 9)

---

## BLOCKER

_None._ Every required- and strongly-suggested behaviour is wired end-to-end in
the matching anodize stage and produces equivalent (or superior) output for the
reference inputs probed in this audit.

---

## WARN

### archives.format=binary with multiple binaries registers a phantom artifact path

- symptom: When `archives[].format: binary` (or `formats: [binary]`) is used and
  a target produces **more than one** binary per crate, anodize's
  `stage-archive` calls `copy_binary(&path_refs, &archive_path)` which copies
  each binary to `archive_path.parent()` under its original filename, but then
  registers a single `Artifact { kind: Archive, path: archive_path, ... }` —
  and `archive_path` itself is never created on disk in that branch. Any
  downstream stage (checksum, release-upload, sign, blob) that stats
  `artifact.path` will hit ENOENT. GoReleaser handles this path by emitting
  one `UploadableBinary` artifact *per* source binary (archive.go:296-336
  `skip()`).
- audit: `crates/stage-archive/src/lib.rs:304-325` (`copy_binary`) and
  `crates/stage-archive/src/lib.rs:1525` (binary branch) → `lib.rs:1600-1608`
  (single-archive registration) (goreleaser: `internal/pipe/archive/archive.go:143-145,296-336`)
- repro: archive config `{ format: binary, ids: [crate-with-multi-bin] }` where
  the crate's build produces ≥2 `[[bin]]` targets → dist has the raw binary
  files, but `ctx.artifacts` reports a non-existent archive path to downstream
  stages.

### archive `binaries:` filter is an anodize extension with no GoReleaser equivalent

- symptom: `ArchiveConfig.binaries: Option<Vec<String>>` filters archives by
  binary name within a build. GoReleaser has no such field — filtering is
  exclusively by `ids` (build ids). Users copy-pasting configs from GoReleaser
  won't hit this, but the field exists and is wired (stage-archive lib.rs:1071
  and 1094-1105), so a config using both `ids` and `binaries` will silently
  intersect filters in a non-obvious way. Either drop it (bloat) or document
  the divergence.
- audit: `crates/core/src/config.rs:1168` (field) and
  `crates/stage-archive/src/lib.rs:1071,1094-1105` (filter)
  (goreleaser: `internal/config/config.go` — no equivalent field on `Archive`)
- repro: config-only — document in anodize as an extension or remove.

### `build.env` values do not cascade through template engine the way GoReleaser's TemplateEnv does

- symptom: GoReleaser's `base.TemplateEnv` (builders/base/build.go:91-105)
  renders each env entry and then calls `tpl.SetEnv(ee)` so that subsequent
  env-list entries can reference earlier ones via `{{ .Env.KEY }}`. Anodize's
  stage-build iterates `target_env` once, rendering each value independently
  — later entries cannot see earlier entries in the same map. This is
  functionally invisible when `env` is a plain `HashMap` of scalar values,
  but breaks the GoReleaser pattern `env: [FOO={{ .Bar }}, BAZ={{ .Env.FOO }}]`.
- audit: `crates/stage-build/src/lib.rs:1742-1754` (per-env rendering without
  feedback) (goreleaser: `internal/builders/base/build.go:91-105`)
- repro: YAML `builds[].env` with an entry that references another entry set
  earlier in the same list → unresolved reference in anodize.

---

## SUGGEST

### source.prefix_template is suffixed with `/` automatically, GoReleaser passes verbatim

- symptom: Anodize `create_source_archive` does
  `cmd.arg(format!("--prefix={}/", prefix))` — forcing a trailing slash.
  GoReleaser source.go:54-57 passes `--prefix <prefix>` verbatim.
  Result: a user-supplied prefix like `myproj/` becomes `myproj//` in anodize,
  and a prefix `myproj` (no slash) still yields `myproj/` — which *is* what
  most users want, but breaks parity with GoReleaser and with the docs
  saying "prefix_template is passed as-is to git archive --prefix".
- audit: `crates/stage-source/src/lib.rs:65` (`--prefix={prefix}/`)
  (goreleaser: `internal/pipe/sourcearchive/source.go:54-57`)
- repro: set `source.prefix_template: "subdir/"` → archive entries appear
  under `subdir//` in anodize, `subdir/` in GoReleaser.

### No GoReleaser-compat aliases for `GORELEASER_CURRENT_TAG` / `GORELEASER_PREVIOUS_TAG`

- symptom: Anodize honors `ANODIZE_CURRENT_TAG` / `ANODIZE_PREVIOUS_TAG` as
  override env vars (helpers.rs:136, helpers.rs:239). GoReleaser honors
  `GORELEASER_CURRENT_TAG` / `GORELEASER_PREVIOUS_TAG` (git.go:268,292). CI
  jobs migrating from GoReleaser-based pipelines won't pick up their existing
  env vars.
- audit: `crates/cli/src/commands/helpers.rs:136,239`
  (goreleaser: `internal/pipe/git/git.go:268,292`)
- repro: set `GORELEASER_CURRENT_TAG=v1.2.3` in CI, run `anodize release`:
  ignored.

### Token file defaults use `~/.config/goreleaser/...` rather than an anodize-native path

- symptom: `load_token_files` in config.rs:495-549 defaults to
  `~/.config/goreleaser/github_token` etc. when the user doesn't set
  `env_files.github_token`. For migration this is *helpful* (existing
  GoReleaser users keep working tokens), but an anodize-native fallback
  (`~/.config/anodize/...`) should be probed first, then fall back to
  the goreleaser path for compat. Today the branding is inverted.
- audit: `crates/core/src/config.rs:507,514,521`
  (goreleaser: `internal/pipe/env/env.go:42-53`)

### archives[].format_overrides `goos:` / `os:` silently accepts Go-style OS names

- symptom: FormatOverride deserializes `goos` as an alias for `os`
  (config.rs:1195). Values passed through are Go-style (`windows`, `darwin`,
  `linux`). Anodize's canonical OS strings from `map_target` are the same Go
  names, so this works — but users aware of Rust target triples might try
  `apple` or `pc-windows-msvc` and get silent no-ops. A canonical-value
  validator that errors on unknown OS values would catch the typo at config
  load (current behavior: silently ignored match-miss).
- audit: `crates/core/src/config.rs:1192-1201` (FormatOverride),
  `crates/stage-archive/src/lib.rs:773-787` (formats_for_target)
  (goreleaser: `internal/pipe/archive/archive.go:338-354`)

### Build stage ordering: MkdirAll happens inside cargo, pre-hooks fire first

- symptom: GoReleaser build.go:147-155 does
  `os.MkdirAll(filepath.Dir(opts.Path))` BEFORE the pre-hook runs; anodize
  runs pre-hooks first (stage-build/lib.rs:2017-2027), then cargo auto-creates
  the target dir. For a pre-hook that tries to write into the expected dist
  target-dir, GoReleaser succeeds and anodize fails. Low-impact since
  `hooks.dir` is user-controlled, but strictly non-parity.
- audit: `crates/stage-build/src/lib.rs:2017-2027` (pre-hook before dir)
  (goreleaser: `internal/pipe/build/build.go:147-155`)

### Archive-hook aliases land on `BuildHooksConfig` (pre/post) — GoReleaser Pro uses `before/after`

- symptom: `ArchiveConfig.hooks: Option<BuildHooksConfig>` with
  `#[serde(alias = "before")]` / `alias = "after"` on the `pre` / `post`
  fields (config.rs:979,982). This works, but re-using the `BuildHooksConfig`
  type conflates two concepts: per-build pre/post and archive before/after.
  Users reading the serialized `dist/config.yaml` will see `pre:` / `post:`
  even if they wrote `before:` / `after:` — which is *correct behavior* but
  confusing when cross-referencing GoReleaser docs.
- audit: `crates/core/src/config.rs:975-984` (type + aliases)
  (goreleaser: `/customization/archive/` — `before`/`after` docs-only)

---

## INTENTIONAL

### Rust builds are serialised even when `--parallelism > 1`

- note: `stage-build/src/lib.rs:1901` forces `effective_parallelism = 1`
  when `build_jobs.len() > 1`. GoReleaser rust builder registers as
  `AllowConcurrentBuilds() = false` (rust/build.go:51), same behavior.
  Documented rationale in-source — parallel cargo invocations contend on
  the shared `target/` directory. Match.
- audit: `crates/stage-build/src/lib.rs:1896-1901`
  (goreleaser: `internal/builders/rust/build.go:50-51`)

### `target_for_validation` strips `-gnu.X.Y` glibc suffix before checking KNOWN_TARGETS

- note: GoReleaser targets.go:92-101 does the same. Implementation matches.
  Not a gap.
- audit: `crates/stage-build/src/lib.rs:795`
  (goreleaser: `internal/builders/rust/targets.go:90-101`)

### ignore_tags accepts glob patterns (anodize superset over GoReleaser's string-equal filterOut)

- note: GoReleaser git.go:367-384 does plain string equality; anodize
  compiles each entry as a glob pattern. Documented in
  `git.rs:463-466` as matching "GoReleaser's behavior with
  `git describe --exclude`" (which *does* glob). Intentional extension.
- audit: `crates/core/src/git.rs:463-466`
  (goreleaser: `internal/pipe/git/git.go:367-384`)

---

## Niche (informational — not gaps, `ecosystem_relevance=niche`)

- `archives[].meta` (manifest-only archives) — implemented
  (stage-archive/lib.rs:982-1024). Niche because Rust users rarely want
  metadata-only archives.
- `archives[].strip_binary_directory` — implemented
  (stage-archive/lib.rs:1079,1246). Niche.
- `archives[].allow_different_binary_count` — implemented
  (stage-archive/lib.rs:1041). Niche.
- `archives[].templated_files` (Pro) — implemented via
  `TemplatedExtraFile`. Niche.
- `source.templated_files` (Pro) — implemented. Niche.
- `formats: gz` / `formats: none` — implemented
  (stage-archive/lib.rs:1513-1527). Niche.
- `build.no_unique_dist_dir` — implemented
  (stage-build/lib.rs:1554-1565,1924-1949). Niche.
- `prebuild` pipe (main template rendering) — folded into build stage,
  no separate Pipe struct. Functional parity via
  `ctx.render_template` before the target loop.
- `upx` — implemented in `stage-upx`. Niche.

---

## Bloat candidates (implemented ∧ not-applicable) — see bloat.md

- `build.ignore` — implemented (stage-build/lib.rs:1532,1570). Inventory
  row 57 marks `scope=go-specific, ecosystem_relevance=not-applicable,
  parity_status=n-a`. Rust builds use explicit `targets` lists, making
  `ignore` redundant with `targets` set-difference. Disposition **suggest:
  keep but re-classify as portable** — it's a convenience field that saves
  users from re-listing every target when they want to exclude one. OR
  remove if the double-spec (targets + ignore) is considered UX bloat.
  Pending countersign by rust-safety-scanner (OSS).
- `universal_binaries.hooks` + `universal_binaries.mod_timestamp` —
  anodize-additive Pro-ish features not in inventory scope; wired
  (stage-build/lib.rs:447-458, 522-534). Disposition **keep** — they are
  trivial glue and match the upstream universalbinary.go:60-73,232-234
  surface. Not strictly bloat.

---

## Evidence: rows audited (required + strongly-suggested)

### 2.1 Builds
| row | status | evidence |
|---|---|---|
| builder: rust | PASS | `stage-build/src/lib.rs:1230` BuildStage wires cargo/cross/zigbuild; parity with `internal/builders/rust/build.go:136`. |
| builder: prebuilt | PASS | `copy_from` wired in `stage-build/src/lib.rs:1687-1730`. |
| build.id / binary / dir / targets / flags / env / tool / mod_timestamp / overrides / hooks.pre/post / skip | PASS | All fields present on `BuildConfig` (core/config.rs:920-963) and consumed in Phase 1 of `BuildStage::run`. See `stage-build/src/lib.rs:1431-1867`. |
| build.command | PASS | `command` override at `BuildConfig.command` (config.rs:958) → `resolve_build_program` (stage-build/lib.rs:114-147). |
| universal_binaries | PASS | `build_universal_binary` (stage-build/lib.rs:355-580); pre/post hooks wired; `replace` wired. |
| partial builds (`--single-target`) | PASS | `stage-build/src/lib.rs:1464-1474`. |
| reportsizes | PASS | `helpers.rs::run_report_sizes` runs after build; matches `internal/pipe/reportsizes/reportsizes.go:29`. |

### 2.2 Archives
| row | status | evidence |
|---|---|---|
| archives[].id / ids (builds alias) | PASS | config.rs:1155,1175-1177; stage-archive filter at lib.rs:996-1009. |
| archives[].format (singular, deprecated) | PASS | config.rs:1159; stage-archive resolves default (lib.rs:1059). |
| archives[].formats (plural) | PASS | config.rs:1162; stage-archive prioritises plural (lib.rs:1117-1120). |
| archives[].name_template | PASS | `default_name_template` + custom — lib.rs:806,1074. |
| archives[].wrap_in_directory | PASS | `WrapInDirectory` enum supports bool/string (config.rs:1114-1146); stage-archive lib.rs:1146-1166. |
| archives[].files (string/object) | PASS | `ArchiveFileSpec::Glob` / `Detailed` (config.rs:1215-1224); stage-archive renders templates then globs (lib.rs:1189-1223). |
| archives[].builds_info | PASS | `builds_info` defaults mode=0755 matching GoReleaser archive.go:99 (lib.rs:1230-1234). |
| archives[].format_overrides | PASS | singular + plural (config.rs:1192-1201); stage-archive lib.rs:773-787. |
| archives[].hooks.before/after | PASS | serde aliases map to pre/post (config.rs:979-983); stage-archive lib.rs:1089,1612. |
| formats: tar.gz/tgz, tar.xz/txz, tar.zst/tzst, tar, zip, binary | PASS | stage-archive match arms (lib.rs:1402-1527). |
| source archive | PASS | `SourceStage` in stage-source/lib.rs:583. |

### 2.15 Project / Global / CLI / Partial (build-archive-relevant rows)
| row | status | evidence |
|---|---|---|
| project_name | PASS | Config.project_name (core/config.rs), `infer_project_name` in cli/helpers.rs:618-632 mirrors project.go:22-43. |
| dist | PASS | Config.dist; used throughout. |
| git.tag_sort (-version:refname / -version:creatordate) | PASS | core/git.rs:468-489. `smartsemver` Pro-only — out of scope for this slice. |
| git.prerelease_suffix | PASS | core/git.rs:471,482-485. |
| git.ignore_tags / ignore_tag_prefixes | PASS | core/git.rs:463-466. |
| monorepo.tag_prefix / dir | PASS | `MonorepoConfig` (config.rs:5176-5188); `Config::monorepo_tag_prefix` (config.rs:280). |
| env (global env list) | PASS | `Config.env`; expanded in `env.rs` / context.rs. |
| env_files.github_token / gitlab_token / gitea_token | PASS | core/config.rs:440-549. (SUGGEST about default path branding above.) |
| before / after hooks | PASS | `HooksConfig` (config.rs:5063-5072); run at `cli/commands/release/mod.rs:325-338, 511-516`. |
| snapshot.name_template | PASS | config.rs:4451-4458; used in release/mod.rs:423-450. |
| partial builds --split/--merge | PASS | `PartialConfig` + `resolve_partial_target` (core/partial.rs:69-109) and `split.rs`. |
| CLI: release, build, check, healthcheck, init, completion, continue/publish/announce (--merge) | PASS | commands/ modules. |
| Flag: --auto-snapshot / --clean / --config / --draft / --fail-fast / --release-notes / --release-notes-tmpl / --skip / --snapshot / --timeout / --single-target / --parallelism / --split / --prepare / --id | PASS | All wired in ReleaseOpts/BuildOpts. |

### 2.17 Other / Auth / Artifacts JSON
| row | status | evidence |
|---|---|---|
| dist/artifacts.json | PASS | `write_metadata_and_artifacts` in helpers.rs:580-589. |
| dist/metadata.json | PASS | same, helpers.rs:533-577. metadata.mod_timestamp wired at helpers.rs:591-607 matching `internal/pipe/metadata/metadata.go:80`. |
| dist/config.yaml (effective config) | PASS | `write_effective_config` in helpers.rs:497-509; called unconditionally in release/mod.rs:454 matching GoReleaser `effectiveconfig.go:19`. |
| GITHUB_TOKEN / GITLAB_TOKEN / GITEA_TOKEN | PASS | helpers.rs token resolution; multiple-token gate at helpers.rs:428-462. |

---

## Notes for Wave A consolidation (A10)

- Treat WARNs 1–3 as `known-bugs.md` additions.
- SUGGEST entries each warrant a known-bugs entry per user rule "every finding
  is actionable"; only the user can deprioritise.
- Bloat candidates need OSS rust-safety-scanner (A6) countersign before any
  removal/repurposing. Recorded in `bloat.md`.
