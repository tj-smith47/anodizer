# Pro feature: nfpm.if (templated conditional)

**Docs:** https://goreleaser.com/customization/nfpm/ (fetched 2026-04-18)
**Anodize site:** crates/stage-nfpm/src/lib.rs:983-1000 (`if_condition` gate); config at core/src/config.rs:2980 (`NfpmConfig.if_condition` with `#[serde(rename="if")]`)
**Status:** implemented

## Contract
Pro: `nfpm.if` is a template-conditional that skips the nfpm config entry when rendered to "false" or empty string. Render error = fatal.

## Contract divergences
- [OK] serde rename `"if"` → `if_condition` matches YAML/JSON surface (can't use `if` as a Rust field name).
- [OK] lib.rs:983-989 — render failure is fatal via `with_context` + `?`. Explicit rationale in comment (978-982). Correct per policy.
- [OK] lib.rs:990-999 — empty or "false" → skip with verbose log + `remember_skip` for post-run summary. Correct.
- [OK] Comment 978-982 references W1 in pro-features-audit.md from the prior audit round. Policy is codified.

## Failure-mode coverage
- Template render error: hard-bail ✓
- Empty result: skip + remember_skip ✓
- "false" literal: skip + remember_skip ✓
- Any other value (e.g., "true", "1", "0", "maybe"): proceed ✓ — Note: "0" does NOT skip; only "false"/empty. GoReleaser docs state "false or empty." Matches.

## Idempotency + retry safety
N/A (conditional, not a stateful operation).

## Secret hygiene
N/A.

## Test coverage
- Config field deserialize + rename test: likely in config.rs tests.
- End-to-end skip behavior: verify a test exists at `tests/` or in lib.rs::mod tests that proves `if: "false"` → stage.run() completes without nfpm_id being built.

## Suggested invariants
1. An nfpm config with `if: "false"` must never produce any package artifacts.
2. An nfpm config with `if: "{{ .Env.MISSING }}"` → render err → Err; stage doesn't partially proceed.

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 0
- CONFIRMED-WORKING: 4 (render error hard-bail, empty→skip, "false"→skip, remember_skip for summary)

## Blocker status for A10
None. Closed per 2026-04-18 inventory.
