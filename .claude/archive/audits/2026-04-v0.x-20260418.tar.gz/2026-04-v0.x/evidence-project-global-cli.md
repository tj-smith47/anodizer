# Evidence — Project / Global / CLI / Partial / Monorepo / Includes / Metadata / Hooks (§2.15)

**Category:** metadata, misc, hooks, cli, partial
**Status:** ✅ release-tag proof
**Tier:** OSS + Pro
**Ecosystem relevance:** required (project_name, dist, git, before/after hooks, snapshot, CLI release/build/check/init/completion, --clean/--config/--draft/--release-notes/--skip/--snapshot); strongly-suggested (tag_sort, prerelease_suffix, ignore_tags, Pro monorepo.tag_prefix/dir, Pro metadata block, env_files, Pro split/merge partial, healthcheck, --auto-snapshot/--fail-fast/--crate(Pro id)/--parallelism/--timeout/--single-target, --prepare Pro, continue/publish/announce); niche (Pro includes, template_files, Pro nightly, jsonschema, CLI changelog preview, mcp registry, man pages, --soft, continue_on_error)

## Covered feature rows

- project_name, dist, git.tag_sort / prerelease_suffix / ignore_tags / ignore_tag_prefixes (Pro)
- Pro monorepo.tag_prefix / dir (WorkspaceConfig native)
- Pro includes[].from_file/from_url
- Pro metadata.mod_timestamp/maintainers/license/homepage/description (full_description.from_url = partial per §5)
- env (global list), env_files.github_token / gitlab_token / gitea_token
- Pro template_files[]
- before / after hooks
- snapshot.name_template, Pro nightly
- Pro partial builds --split/--merge (Rust-native ANODIZE_SPLIT_TARGET replaces GGOOS/GGOARCH)
- CLI: release, build, check, healthcheck, init, completion, jsonschema, Pro changelog preview, Pro continue/publish/announce (--merge)
- Flags: --auto-snapshot, --clean, --config, --draft, --fail-fast, Pro --id (--crate), Pro --key (n-a), Pro --nightly, --parallelism, Pro --prepare, --release-notes (+ --release-notes-tmpl), --skip, --snapshot, Pro --split, --timeout, --single-target
- **Missing (niche)**: `goreleaser man` (mangen), `--soft` flag, `continue_on_error`, `mcp registry`

## Proof

### Release-tag proof

- **anodize v0.2.5** exercises: project_name=`anodize`, dist=`./dist`, git.tag_sort=`-version:refname`, tag block with `default_bump: patch`/`tag_prefix: v`/`release_branches`, metadata block with homepage/license/maintainers/mod_timestamp, env (`RELEASE_TYPE=stable`), variables.repo_url/description (Pro custom template variables), before/after hooks, snapshot.
- **cfgd v0.3.5** exercises workspaces (monorepo): 3 workspaces (cfgd-core, cfgd, cfgd-operator, cfgd-csi-node) each with their own tag prefix (`v{{Version}}`, `core-v{{Version}}`, `operator-v{{Version}}`, `csi-v{{Version}}`) — `/opt/repos/cfgd/.anodize.yaml:102-...`. Per-workspace skip blocks (`skip: [announce]`). Tag scan uses `branch_history: full` (gap fix from commit `2d3d0dac`).

### CI workflow runs

- cfgd release.yml run 24442230191 (tag v0.3.5) — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — `args: release --verbose --debug --strict --merge --crate cfgd` — exercises 5 flags simultaneously; resolve stage runs `anodize resolve-tag` via anodize-action's `resolve-workspace: true` (outputs workspace, crate-path, has-builds).
- cfgd release.yml run 24442229349 (tag core-v0.3.5) — library-only workspace path (has-builds=false) — library-crate branch exercised.
- anodize release.yml (when tagged) runs `release --split --clean` on build matrix and `release --merge` on aggregator job — partial split/merge proof per `/opt/repos/anodize/.github/workflows/release.yml`.

### Tests

- `crates/cli/tests/integration.rs`:
  - `test_check_valid_config` (line 10), `test_check_with_config_flag` (line 125, 160, 192), `test_help_output` (line 89), `test_version_output` (line 113), `test_init_generates_config` (line 53), `test_healthcheck_succeeds` (line 366), `test_completion_bash_produces_output` (line 334), `test_completion_zsh_produces_output` (line 354)
  - `test_release_help_shows_timeout_flag` (line 208), `test_build_help_shows_timeout_flag` (line 224), `test_timeout_kills_long_running_release` (line 240), `test_release_invalid_timeout_value` (line 438)
  - `test_skip_flag_skips_specified_stages` (line 1413), `test_release_help_shows_new_flags` (line 386), `test_build_help_shows_new_flags` (line 417)
  - `test_e2e_workspace_all_force_detects_crates` (line 978), `test_e2e_workspace_snapshot_produces_artifacts` (line 1046), `test_e2e_init_workspace_generates_depends_on` (line 1119), `test_e2e_check_workspace_invalid_depends_on` (line 1184), `test_e2e_workspace_change_detection_without_force` (line 1235), `test_e2e_workspace_dependency_ordering` (line 2250), `test_e2e_multiple_crates_release` (line 2894)
  - `test_e2e_auto_snapshot_dirty_repo` (line 3322), `test_e2e_before_hooks_execute` (line 3368), `test_e2e_before_hooks_dry_run` (line 3437)
  - `test_e2e_dry_run_no_side_effects` (line 716), `test_e2e_full_dry_run_all_stages` (line 2668)
- `crates/core/tests/config_parsing_tests.rs` — 490 tests covering full config surface (20+ blocks).
- `crates/cli/tests/bump_integration.rs` — 917 lines of tag/bump integration tests.

## Known limitations

- **CLI: man pages (`goreleaser man`)** — missing per inventory §2.15 and §5; not a blocker (niche).
- **Flag `--soft`** (check only) — missing per inventory §2.15.
- **`continue_on_error`** — missing per §2.17; anodize is fail-fast by default.
- **`mcp registry` pipe** — missing; MCP ecosystem still forming (no Rust consumer demand yet).
- **`metadata.full_description.from_url`** — partial; `FromFile` + inline work, URL resolution deferred per core/src/context.rs:754.
- **Pro `nightly` channel** — CLI-level flag + NightlyConfig wired, but anodize has no nightly release branch; not in v0.2.5 pipeline.
- **Pro `includes[]` from_url/from_file** — wired but no production config uses it.
- **Pro `template_files[]`** — stage wired via `TemplateFileConfig` + `stage-templatefiles`; no production config exercises it.
