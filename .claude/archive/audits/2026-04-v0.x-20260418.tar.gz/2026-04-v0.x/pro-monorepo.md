# Pro feature: monorepo (tag_prefix / dir)

**Docs:** https://goreleaser.com/customization/monorepo/ (fetched 2026-04-18)
**Anodize site:** core/src/config.rs:5157-5183 (`MonorepoConfig`); core/src/git.rs:401 (`strip_monorepo_prefix`); core/src/context.rs:436-495 (`PrefixedTag` population)
**Status:** implemented

## Contract
Pro: `monorepo` config filters tag discovery by `tag_prefix` and changes the meaning of `.Tag` / `.PrefixedTag`:
- `monorepo.tag_prefix`: tags in git already HAVE the prefix (e.g., `subproject1/v1.2.3`). `.Tag` is stripped to `v1.2.3`, `.PrefixedTag` retains full `subproject1/v1.2.3`.
- `monorepo.dir`: scope the release to changes under that directory.

Anodize extends with `WorkspaceConfig` for Cargo workspaces (native rust-additive).

## Contract divergences
- [OK] config.rs:5176-5182 — `MonorepoConfig { tag_prefix, dir }` present.
- [OK] context.rs:456 — when `monorepo` configured, `.PrefixedTag` = full tag (including prefix), `.Tag` = stripped version. Matches docs.
- [OK] git.rs:401 — `strip_monorepo_prefix` utility separates the stripping logic; unit tests at 2054, 2062, 2067, 2072 cover match/no-match/empty-prefix/partial-match. ✓
- [OK] context.rs:487-495 — Non-monorepo: prepend `tag.tag_prefix` (OSS field) to construct `.PrefixedTag`. Handles the case where the repo uses `TagConfig.tag_prefix` but NOT monorepo. Correct precedence.
- [SUGGEST] config.rs:5172-5174 — doc comment notes: "When `monorepo` is configured, it takes precedence over `tag.tag_prefix`." Verify ALL places that read `tag_prefix` honor this precedence — grep in context.rs for `tag_prefix` shows multiple sites; audit each.
- [SUGGEST] `monorepo.dir`: how is it used? Does it filter changelog entries (only changes under that dir)? Does it filter files globbed by `extra_files`? Expected behavior per GoReleaser: filter changelog. Verify wiring.

## Failure-mode coverage
- Tag found with matching prefix but `dir` is outside the repo → file-existence check needed. Bail if `dir` doesn't exist.
- Monorepo.tag_prefix set but NO tags match → tag discovery returns empty → bail at first need-tag context (release, changelog).

## Idempotency + retry safety
Pure read/parse logic. Idempotent.

## Secret hygiene
N/A.

## Test coverage
- git.rs:2054-2080 — strip_monorepo_prefix unit tests ✓
- git.rs:2086 — `test_find_latest_tag_with_monorepo_prefix_filters_and_returns_full_tag` ✓
- Missing: test asserting `monorepo.dir` filters changelog entries
- Missing: test asserting `TagConfig.tag_prefix` is ignored when `MonorepoConfig` is set

## Suggested invariants
1. When `monorepo.tag_prefix = "subproject1/"`, `.Tag` never contains `"subproject1/"` as a prefix.
2. When `monorepo.tag_prefix` is set, `.PrefixedTag` always retains the full prefix.
3. `monorepo.dir` filters changelog entries strictly — no commits outside the dir appear.

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 3 (monorepo.dir changelog filtering verification, tag_prefix precedence audit, test for tag_prefix-ignored-when-monorepo)
- CONFIRMED-WORKING: 4 (strip_monorepo_prefix, PrefixedTag population, MonorepoConfig struct, unit tests for strip)

## Blocker status for A10
None. SUGGESTs are for test coverage and behavior verification.
