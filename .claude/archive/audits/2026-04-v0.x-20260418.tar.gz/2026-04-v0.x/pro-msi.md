# Pro feature: msis[] (Windows MSI)

**Docs:** https://goreleaser.com/customization/msi/ (fetched 2026-04-18)
**Anodize site:** crates/stage-msi/src/lib.rs; config at core/src/config.rs:3555,3560
**Status:** implemented

## Contract
Produces Windows `.msi` installers. Fields: `id`, `name`, `if`, `ids`, `use`, `wxs`, `extra_files`, `replace`, `mod_timestamp`, `hooks`, `files`, `goamd64`. Tooling: WiX v4 (`wix build`) or v3 (`candle` + `light`).

## Contract divergences
- [OK] crates/stage-msi/src/lib.rs:52-60 — detects v4 `wix` then falls back to v3 `candle`+`light`. Docs allow either.
- [OK] Config at config.rs:3555 — `if_condition`, `hooks: BuildHooksConfig`, `extra_files: Vec<String>` match docs. Per inventory, `goamd64` is Go-specific (n-a for Rust target triples) so not implemented — accepted.
- [WARN] crates/stage-msi/src/lib.rs:1926-1945 — candle gets `-ext` args; light also gets `-ext`. The WiX extension list is propagated to both. GoReleaser passes `-ext` only to `candle` per docs. No BLOCKER but diverges — behavior is "superset" and harmless, but worth noting.
- [SUGGEST] stage-msi/src/lib.rs:291 (per inventory) — `if_condition` hard-bails on render failure. Good. Check the test exists: see below.

## Failure-mode coverage
- Wix missing: crates/stage-msi/src/lib.rs bails early with "need wix (v4) or candle+light (v3)" ✓
- candle exit non-zero: lib.rs:586-599 — `check_output` bails ✓
- light exit non-zero: lib.rs:600+ — `check_output` bails ✓
- hooks.pre/post failures: bubble via `?` ✓
- extra_files glob error: bubble via `?` ✓
- Staging cleanup: `tempfile::tempdir` auto-cleans ✓

## Idempotency + retry safety
Each run produces fresh staging dir. Overwrites final `.msi`. Hook side-effects are user-managed. WiX invocation argv visible to `ps` — contains no secrets (just paths).

## Secret hygiene
No credentials involved at MSI stage. Signing moves to stage-sign/notarize.

## Test coverage
- crates/stage-msi/src/lib.rs:745-755 — covers candle+light basic invocation template
- crates/stage-msi/src/lib.rs:1926-1945 — ext propagation test ✓
- Live test gated by presence of `wix`/`candle`+`light` binaries on CI

## Suggested invariants
1. Every successful MSI run emits one `ArtifactKind::Installer` per (crate, target) with metadata `format=msi`.
2. `hooks.pre` runs before candle invocation; `hooks.post` runs after `light` successfully produces the .msi.
3. WiX version detection is deterministic — prefers v4 over v3 if both installed (so users can upgrade piecemeal).

## Findings summary
- BLOCKER: 0
- WARN: 1 (`-ext` passed to `light` diverges from docs; harmless superset)
- SUGGEST: 1 (ensure if_condition render-failure test exists)
- CONFIRMED-WORKING: 6 (v3/v4 detection, extension handling, hooks wiring, replace, dry-run, check_output bailing)

## HANDOFF items
Live MSI build validation requires Windows+WiX runner; see HANDOFF.md.
