# Dedup scan — anodize/crates — 2026-04-v0.x

Scanned `crates/` (cli + core + stage-*) against the extraction rubric: duplication,
near-duplication, diverged copies. Test code is included only when the duplication
risks silent behavior drift with production.

## Summary

BLOCKER=6  SUGGEST=5

---

## BLOCKER (extract-now)

### expand_env_vars — diverged shell-style env expansion
- duplicates:
  - `crates/stage-build/src/lib.rs:805` — `fn expand_env_vars(input: &str) -> String`
  - `crates/cli/src/pipeline.rs:476` — `fn expand_env_vars(s: &str) -> String`
  - `crates/stage-sign/src/lib.rs:163` — `fn expand_shell_vars(s: &str, vars: &HashMap<&str, &str>) -> String` (similar char-by-char `$`/`${` parser; takes an explicit vars map rather than process env, but the parsing machinery is the same)
- proposed target: `crates/anodize-core/src/env_expand.rs` with signatures
  `expand_from_process_env(s: &str) -> String` and
  `expand_from_map(s: &str, vars: &HashMap<&str, &str>) -> String`.
- rationale: **The two `expand_env_vars` implementations behave differently for the
  same input.** `stage-build` accepts `$1` / `$5` etc. (`is_ascii_alphanumeric || '_'`
  at the first post-`$` char), whereas `cli/pipeline` rejects them (`is_ascii_alphabetic
  || '_'`) and preserves the literal `$5`. A YAML config header value like `Bearer $5XYZ`
  expands differently depending on which code path reads it. This is exactly the
  "one fix, two places to update" problem; GoReleaser matches shell rules and
  never expands `$<digit>` (the cli version is the correct semantics — consolidating
  on it fixes a bug in stage-build).

### set_file_mtime — two implementations, two different crates
- duplicates:
  - `crates/core/src/util.rs:203` — `pub fn set_file_mtime(path: &Path, mtime: SystemTime) -> Result<()>` (uses `std::fs::FileTimes`; also sets atime)
  - `crates/stage-build/src/lib.rs:1098` — `fn set_file_mtime(path: &Path, epoch_secs: i64) -> Result<()>` (uses the `filetime` crate; mtime only, no atime)
- proposed target: core. Extend the core variant with an `i64`-epoch convenience
  (`set_file_mtime_epoch(path, epoch_secs)`); delete the stage-build duplicate and
  drop the `filetime` dependency from stage-build.
- rationale: `stage-build/binary::apply_mod_timestamp` sets a build artifact mtime
  from `SOURCE_DATE_EPOCH`; `core::util::apply_mod_timestamp_to_staging` does the
  same for source-staging files. They already differ: one sets atime+mtime, the
  other mtime only. Reproducible-build semantics must not diverge between
  stage-build and core-driven staging.

### expand_env_vars test coverage is duplicated too
- duplicates:
  - `crates/cli/src/pipeline.rs:1558-1826` — 10+ tests covering braced/unbraced/missing/unclosed-brace/trailing-dollar cases
  - `crates/stage-build/src/lib.rs:3856-3888` — 4 tests covering a narrower subset (dollar_var, brace_var, missing_var, no_vars)
- proposed target: once the function is unified in `anodize-core::env_expand`, move
  all tests to that module and delete the stage-build copies.
- rationale: right now stage-build's reduced test surface hides the `$5` bug above;
  its tests never exercise the digit-after-dollar case because that's not how
  stage-build callers happen to use it today. A regression at either site would
  pass one suite and fail the other.

### retry-with-exponential-backoff loop (5+ open-coded copies, drift)
- duplicates:
  - `crates/stage-docker/src/lib.rs:811-944` — build retry (attempts = `job.max_attempts`, base = `job.base_delay`, cap = `job.max_delay`, multiplier `2^(n-2)`)
  - `crates/stage-docker/src/lib.rs:964-1074` — push retry (same shape, different log wording)
  - `crates/stage-docker/src/lib.rs:2658-2800` — manifest create/push retry (same shape, copied twice within one function)
  - `crates/stage-release/src/lib.rs:345-373` — `retry_upload<F, Fut>` (async; MAX_ATTEMPTS=10, INITIAL=50ms, MAX=30s, multiplier `2^(n-1)`)
  - `crates/stage-release/src/lib.rs:651-697` — inline 3-attempt retry for fetch-content-URL (backoff `500 << (attempt-1)` ms; treats 4xx as fatal)
  - `crates/stage-release/src/lib.rs:2233-2340` — 10-attempt retry for `upload_asset` via octocrab (open-coded; same 50ms / 30s constants as `retry_upload` but re-declared)
- proposed target: `crates/anodize-core/src/retry.rs` with a single sync+async API:
  ```
  pub struct RetryPolicy { pub max_attempts: u32, pub base: Duration, pub cap: Duration, pub multiplier_exponent_offset: u32 }
  pub fn retry_sync<T, F>(policy: &RetryPolicy, label: &str, mut f: F) -> Result<T>
    where F: FnMut(u32) -> ControlFlow<Result<T>, anyhow::Error>;
  pub async fn retry_async<T, F, Fut>(policy: &RetryPolicy, label: &str, mut f: F) -> Result<T>
    where F: FnMut(u32) -> Fut, Fut: Future<Output = ControlFlow<Result<T>, anyhow::Error>>;
  ```
  `ControlFlow::Break(Err(fatal))` aborts the loop (e.g. 4xx, bad-config errors);
  `ControlFlow::Continue(err)` triggers backoff+retry; success returns via `Break(Ok)`.
- rationale: **Already diverged.** The three docker retries use `2^(n-2)`
  starting the doubling on attempt 3; the octocrab upload retry uses `2^(n-1)`
  starting the doubling on attempt 2; the release-body fetch uses
  `500 << (attempt-1)` ms which is its own third formula. Six call sites, three
  backoff formulas, identical problem. Next fix will land in whichever one
  the author had in mind and the other five will silently drift.

### docker URL-segment encode sets duplicated across backends
- duplicates:
  - `crates/stage-release/src/gitea.rs:24` — `SEGMENT_ENCODE_SET: &AsciiSet = &NON_ALPHANUMERIC.remove(b'-').remove(b'_').remove(b'.');`
  - `crates/stage-release/src/gitlab.rs:30` — identical `SEGMENT_ENCODE_SET` (byte-for-byte copy)
  - `crates/stage-release/src/gitlab.rs:26` — `PATH_ENCODE_SET` (identical contents, renamed)
  - `crates/stage-release/src/lib.rs:23` — `fn percent_encode_path` with a third, different encode set (keeps `-_.~` AND `/:@!$&'()*+,;=`; closer to Go's `url.PathEscape`)
- proposed target: `crates/anodize-core/src/url.rs` already has `percent_encode_unreserved`.
  Add `percent_encode_path_segment` (RFC 3986 unreserved + `-._~`, equivalent to
  `NON_ALPHANUMERIC.remove(b'-').remove(b'_').remove(b'.')`) and re-export it
  from the backend modules; delete the three local copies.
- rationale: **Already diverged.** `stage-release/lib.rs::percent_encode_path`
  uses a pchar-tolerant set (GitHub tags are fine with `+!$&'()`), while the
  per-backend gitea/gitlab sets encode everything except `-_.~`. If a user creates
  a tag like `v1.0.0+beta`, the three backends emit three different URLs. The
  `url` core module exists specifically because this was a prior incident; the
  extraction didn't go far enough.

### Force-token env-var parsing is duplicated in the same file
- duplicates:
  - `crates/cli/src/commands/helpers.rs:394-406` (inside `setup_env`)
  - `crates/cli/src/commands/helpers.rs:700-710` (inside `resolve_scm_token_type`)
- proposed target: extract `fn resolve_force_token(config: &Config) -> Option<ForceTokenKind>`
  into `crates/cli/src/commands/helpers.rs` and call from both sites.
- rationale: two identical blocks, 13 lines each, both reading `ANODIZE_FORCE_TOKEN`
  / `GORELEASER_FORCE_TOKEN` with the same fallback ladder. Whoever updates one
  (e.g. adds a new token kind) will miss the other, and the compat matrix will
  silently desync.

---

## SUGGEST (extract-when-touched)

### `blake3_file` and `crc32_file` reimplement the 8192-buf chunked read
- sites: `crates/stage-checksum/src/lib.rs:66-96`
- proposed target: generalise `anodize_core::hashing::hash_file_with` to accept a
  hasher adapter trait (or add a `hash_file_streaming` that takes
  `impl FnMut(&[u8])`) so blake3 and crc32 can reuse the I/O loop.
- rationale: the I/O loop is identical (open, read 8KB into buf, loop until n==0);
  only the hasher method differs. Not a BLOCKER because blake3 and crc32
  hashers don't implement `Digest`, so the current split is defensible — but
  any future change to the streaming read (e.g. swap to `std::io::copy` + a
  Hasher-Writer wrapper) will need to be made in three places.

### User-Agent `"anodize"` header spread across 11 HTTP call sites
- sites: `stage-release/src/lib.rs:{54,118}`, `stage-publish/src/util.rs:{514,999}`,
  `cli/src/commands/release/milestones.rs:{195,252,321,363,406,448}`,
  `stage-announce/src/discourse.rs:29` (the only one that versions it:
  `concat!("anodize/", env!("CARGO_PKG_VERSION"))`)
- proposed target: `pub const USER_AGENT: &str = concat!("anodize/", env!("CARGO_PKG_VERSION"));`
  in `anodize_core`. Optional helper: `fn default_client() -> reqwest::blocking::ClientBuilder`
  that applies it + a 30s timeout.
- rationale: eleven literals diverge on "anodize" vs "anodize/<version>" and
  force each caller to remember to set a UA. Low-risk when touched, not urgent
  enough for a dedicated refactor today.

### `blocking::Client::builder().timeout(...)` setup repeated 14 times
- sites (non-exhaustive): `cli/src/pipeline.rs:562`, `stage-release/src/lib.rs:647`,
  `stage-publish/src/{chocolatey,crates_io,dockerhub,cloudsmith}.rs` (6 sites),
  `stage-announce/src/{bluesky,reddit,webhook}.rs`,
  `stage-changelog/src/lib.rs:{1440,1570}`, `stage-publish/src/util.rs:994`
- proposed target: `anodize_core::http::blocking_client(timeout: Duration) -> Result<reqwest::blocking::Client>`
  (sets default UA + timeout + `tls_built_in_root_certs`).
- rationale: every builder lands on different timeout values (10s, 30s, 60s) and
  only a subset sets UA. Low churn individually, but centralising fixes the UA
  drift above for free.

### `trim_end_matches('/')` URL-base normalization at 14 sites
- sites: `stage-release/src/{lib,gitea,gitlab}.rs` (9 sites), `core/src/scm.rs:108`,
  `stage-changelog/src/lib.rs:{1396,1549}`, `stage-publish/src/chocolatey.rs:{736,786}`
- proposed target: `anodize_core::url::join(base, path)` or a
  `UrlBase::new(&str)` newtype that trims on construction and exposes `format!`-style
  joining.
- rationale: every call site does `base.trim_end_matches('/')` then `format!("{base}/...")`.
  Not a divergence risk — the semantics match everywhere — but a missed trim on
  a new call site would quietly produce `https://api.example.com//resource`.

### `reqwest` HTTP-retry for transient errors exists in five shapes
- duplicates (covered under the retry BLOCKER above, but worth flagging as its
  own concern because the shared policy is *HTTP-specific retry classification*):
  `stage-release/src/lib.rs:{345-373,651-697,2233-2340}`,
  `stage-publish/src/util.rs:420-471`, `stage-publish/src/crates_io.rs:120-194`.
  The crates.io index poller also open-codes back-off and transient-error
  handling with yet another formula.
- proposed target: if the BLOCKER extraction lands, the HTTP-specific bits
  (treat 4xx as fatal, retry on 5xx + transport errors, respect `Retry-After`)
  can fold into a `retry_http_sync`/`retry_http_async` adapter on top of the
  generic policy.
- rationale: kept separate so the BLOCKER can land without also taking on
  HTTP-error classification semantics.
