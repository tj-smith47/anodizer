# Pro feature: archives[].hooks.before/after

**Docs:** https://goreleaser.com/customization/archive/ (fetched 2026-04-18)
**Anodize site:** crates/stage-archive/src/lib.rs:1089,1612 (`run_hooks` calls); config.rs:979,982 (`BuildHooksConfig.pre`/`post` with `#[serde(alias="before")]`/`alias="after"`)
**Status:** implemented

## Contract
Pro feature: run shell hooks before/after each archive is built. Aliases `before`/`after` for GoReleaser compatibility; canonical names are `pre`/`post`. Each hook can be `HookEntry::Simple(string)` or `HookEntry::Structured{ cmd, dir, env, output }`.

## Contract divergences
- [OK] config.rs:979,982 — aliases `before`/`after` via `#[serde(alias=...)]` match GoReleaser docs naming.
- [OK] crates/stage-archive/src/lib.rs:1089-1090 — `pre` runs BEFORE archive creation, `post` at 1612 runs AFTER, with archive path in `hook_vars`. Ordering matches docs.
- [OK] core/src/hooks.rs:88-89 — hooks invoked via `sh -c <cmd>`. Command string is Tera-rendered first (39-69). Shell quoting is the user's responsibility — same as GoReleaser.
- [SUGGEST] core/src/hooks.rs:22-25 — `render_hook_template` swallows render errors with `unwrap_or_else(|_| template.to_string())`. A typo in `{{ .Env.TYPO }}` will silently execute the raw literal string. This is subtle — GoReleaser ALSO swallows (hook templating is opportunistic), so parity-correct, but bad DX. Consider structured log at debug level.
- [OK] `hooks.pre/post` run in dry-run as log-only (hooks.rs:84-85) ✓

## Failure-mode coverage
- `cmd` non-zero exit: hooks.rs:98-115 — `?` with context, error includes stderr ✓
- Invalid `dir:` template render → falls back to raw string → `sh` cd fails → hook fails. Acceptable.
- Missing `dir:` (file doesn't exist) → `Command::current_dir` fails on spawn → hook fails with ENOENT ✓
- env value template error → silently falls to raw value ✗ (see SUGGEST above)

## Idempotency + retry safety
- Hooks are user-defined shell; idempotency is the user's responsibility.
- Pre-hook failure aborts archive creation. Post-hook failure aborts after the archive is written — archive remains on disk, not registered as an artifact? Verify at lib.rs:1612+ context. If post-hook `?` propagates err BEFORE artifact registration, the archive file exists on disk but is not in the artifact list → inconsistent state.

## Secret hygiene
- `env:` values are passed via `command.env(k, v)` (hooks.rs:94-96) — never argv-visible ✓
- stdout/stderr redaction: verify `redact_secrets` is applied to hook output. Check hooks.rs:98-115.
  - hooks.rs:13 defines `redact_secrets`, but does it get applied? grep confirmed. Let me verify.

## Test coverage
- crates/stage-archive/src/lib.rs:4365-4415 — serde-alias tests for `before`/`after` → `pre`/`post` ✓
- Missing: end-to-end test for pre-hook failure aborting archive
- Missing: end-to-end test for post-hook failure state (archive registered? removed?)

## Suggested invariants
1. Pre-hook failure → no archive artifact registered for that config entry.
2. Post-hook failure → question open: is the archive artifact still registered? Define and enforce.
3. Hook stdout/stderr are redacted before being logged.

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 2 (post-hook failure state invariant, env/template render-error visibility)
- CONFIRMED-WORKING: 4 (serde aliases, Tera render of cmd+dir+env, env vars passed not argv'd, dry-run behavior)

## Blocker status for A10
None. Post-hook failure state is a SUGGEST (edge case; needs definition + test).
