# Pro feature: partial builds (--split / --merge) + CLI: continue

**Docs:** https://goreleaser.com/pro/ (fetched 2026-04-18)
**Anodize site:** core/src/partial.rs:69 (`resolve_partial_target`); cli/src/commands/release/split.rs:92,276 (`run_split`/`run_merge`); cli/src/commands/continue_cmd.rs
**Status:** implemented

## Contract
Pro: `anodize release --split` builds ONLY the targets for the current runner (selected via `TARGET`/`ANODIZE_OS`/`ANODIZE_ARCH` env or host detection), writes artifacts + state to `dist/<subdir>/`. `anodize release --merge` (or `anodize continue`) reads ALL `context.json` files back in and runs the post-build pipeline (archive, sign, checksum, release, publish, announce).

## Contract divergences
- [OK] partial.rs:69-109 — priority chain `TARGET` > `ANODIZE_OS`/`ARCH` (canonical) or `GGOOS`/`GGOARCH` (GoReleaser alias) > host detection. Clear precedence documented at lines 63-68.
- [OK] partial.rs:98-108 — `partial.by` config value `"goos"` or `"target"` — fails loudly on unknown values (line 104-107). Good.
- [OK] split.rs:145-146 — split dist directory created with `create_dir_all` before writes.
- [OK] split.rs:200-212 — **atomic context.json write**: stage to `.tmp`, then rename. Survives mid-write runner death. Important for CI reliability.
- [OK] split.rs:161-180 — **per-target artifact copies** into `dist/<subdir>/<target>/`. Rationale at 156-160: without this, aarch64 and x86_64 binaries with the same name collide. Good defensive design.
- [OK] split.rs:289-300 — merge with missing `context.json` + no `artifacts.json` → bail with actionable message directing to run `--split` first. ✓
- [OK] split.rs:291-300,377 — legacy `artifacts.json` fallback retained for backward compat.
- [SUGGEST] split.rs:184-196 — `SplitContext` includes `template_vars` snapshot but NOT the full Config. On merge, `ctx` is rebuilt from the CURRENT repo state (config + git). If the user tags a different version between split and merge, the template vars from first split are restored but the merged Config may be newer. Edge case but worth documenting.
- [SUGGEST] split.rs:315-322 — merge uses `first_vars` (first file's template_vars) as canonical. If split jobs ran at different times and produced divergent `.Version` or `.CommitDate` (unlikely but possible), this silently picks the first one. Consider asserting consistency across split contexts.
- [WARN] split.rs:325-355 — artifact dedup by path (seen_paths HashSet). If two split jobs produce the same path (e.g., both wrote to `dist/linux/x86_64-unknown-linux-gnu/foo`), the second is dropped. Should this be an error instead of a silent drop? With per-target subdir isolation (split.rs:164-170), collisions should be impossible, so this is defensive — but a bug in target subdir naming would silently shadow artifacts.

## Failure-mode coverage
- `TARGET` env with malformed triple: partial.rs:74 accepts any non-empty string. Later: build stage will bail when no rustc target matches.
- No `rustc` on PATH: partial.rs:112-123 fails cleanly ✓
- Unknown `partial.by`: partial.rs:104 bails with actionable msg ✓
- Corrupt `context.json`: split.rs:311-312 bubble with context ✓
- Missing `context.json` AND `artifacts.json`: bail with "Run `anodize release --split` first" ✓
- Concurrent writers to same dist/: atomic rename protects each split's context.json. ✓

## Idempotency + retry safety
- **Split is idempotent** for a given (git state, env vars). Re-running overwrites `dist/<subdir>/`. Atomic rename prevents half-written files. ✓
- **Merge is idempotent** for a given set of context.json files — dedup by path prevents duplicate artifact entries on re-merge. ✓
- Recovery: if merge fails mid-pipeline, rerun will re-read context.jsons and try again. Re-reading is cheap (JSON deserialize).

## Secret hygiene
- `env_vars` in `SplitContext` (split.rs:191) is populated from `ctx.template_vars().all_config_env()`. If any CI secret was rendered into the env via config, it ends up in `context.json` on disk. Verify what `all_config_env()` returns — if it's only `{{ .Env.VAR }}`-referenced values, secrets referenced in templates would be serialized.
- **[WARN] Potential secret leak:** the `context.json` file is persistent in `dist/`. If a user uploads `dist/` as a CI artifact (common pattern), any secret values that got into `env_vars` would be uploaded. Worth an explicit warning in docs.

## Test coverage
- partial.rs:158-371 — broad coverage of `PartialTarget` filtering, `dist_subdir`, `detect_host_target`, `resolve_partial_target` with env vars, invalid `by` ✓
- split.rs:589-624 — integration tests for artifact discovery and legacy format
- Missing: test for atomic-write behavior (simulate `.tmp` interruption)
- Missing: test for secrets in `env_vars` serialization path (see WARN above)

## Suggested invariants
1. Split's `dist/<subdir>/context.json` is ALWAYS either a valid complete JSON (from successful rename) or absent (rename didn't happen) — never a truncated file.
2. Merge runs NO build stages — only post-build (archive, sign, checksum, sbom, release, publish, announce).
3. After merge, `ctx.artifacts` contains the UNION of all split context artifacts, deduped by path.
4. Secrets in the shell env never enter `context.json` unless explicitly templated in.

## Findings summary
- BLOCKER: 0
- WARN: 2 (artifact path collision silently dedup'd; `env_vars` serialization potentially leaks secrets)
- SUGGEST: 2 (Config snapshot consistency between split/merge; assert template_vars consistency across split contexts)
- CONFIRMED-WORKING: 8 (priority chain, atomic rename, per-target subdir, legacy fallback, dry-run, clean error on missing splits, rustc detection, unit tests)

## HANDOFF items
Live split/merge across multiple runners (different OS) cannot be validated in a single-host audit. See HANDOFF.md for GitHub Actions matrix test.
