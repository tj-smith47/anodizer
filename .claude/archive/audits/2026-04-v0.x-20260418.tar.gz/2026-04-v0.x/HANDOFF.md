# HANDOFF — items requiring live execution

Deferred from A5 (`pro-features-skeptic`) — these cannot be validated without
an actual release or without platform-specific CI runners. Hooks will deny
release attempts from the agent; these MUST be run by the user.

**Date:** 2026-04-18
**Source audits:** `/opt/repos/anodize/.claude/audits/2026-04-v0.x/pro-*.md`

---

## 1. DMG mod_timestamp propagation (pro-dmg.md)

**Goal:** verify `dmg.mod_timestamp` sets the mtime of files inside the `.dmg` (not just the staging dir).

**Setup:**
```
# In a test repo with darwin binary
anodize init
# add to .anodize.yaml:
#   dmgs:
#     - mod_timestamp: "1600000000"
anodize release --snapshot
```

**Expected:**
- `dist/macos/*.dmg` exists
- Mounting the DMG and inspecting `ls -la` on files → mtime is `2020-09-13 12:26:40 UTC` (unix 1600000000)

**Rollback:** delete `dist/`.

---

## 2. Notarize full round-trip (pro-notarize.md, pro-pkg.md, pro-app-bundle.md)

**Goal:** exercise `codesign --deep --force --sign` + `xcrun notarytool submit --wait` + `xcrun stapler staple` end-to-end with real Apple Developer credentials.

**Setup:** requires a macOS Sonoma+ host with:
- Apple Developer ID cert installed in keychain
- A `notarytool` keychain-profile (see `xcrun notarytool store-credentials`)
- `.anodize.yaml` with `notarize.macos_native: { identity: "Developer ID Application: ..." , keychain_profile: "...", wait: true }`

**Invocation:**
```
anodize release --snapshot
```

**Expected artifacts:**
- `dist/macos/<project>_<ver>_<arch>.app/Contents/_CodeSignature/CodeResources`
- `dist/macos/<project>_<ver>_<arch>.dmg` with stapled notarization ticket (verify via `stapler validate`)
- `dist/macos/<project>_<ver>_<arch>.pkg` signed with `productsign`

**What to watch:**
- `xcrun notarytool submit --wait --timeout ...` can block minutes. Confirm the wait-then-staple sequence fires.
- Stapler MUST NOT run when `wait: false`.
- Any mid-flight abort leaves the signed `.app`/`.dmg` on disk — rerun should re-sign safely.

**Rollback:** revoke the submission from App Store Connect if the release is unintended; `rm -rf dist/`.

---

## 3. MSI Windows v3/v4 path (pro-msi.md)

**Goal:** verify anodize detects `wix` (v4) vs `candle`+`light` (v3) and produces a valid `.msi`.

**Setup:** Windows runner with either:
- WiX v4: `wix` in PATH, OR
- WiX v3: both `candle` and `light` in PATH

**Invocation:**
```
anodize release --snapshot --crate <name>
```

**Expected:**
- `dist/windows/<name>_<ver>_<arch>.msi` exists
- `msiexec /i <file>.msi /l*v log.txt /quiet TARGETDIR=C:\test` succeeds

**Watch for:** the `-ext` flag being passed to BOTH candle and light in v3 mode (see pro-msi.md WARN). Verify WiX accepts this without error.

---

## 4. NSIS Windows path (pro-nsis.md)

**Goal:** `makensis` invocation produces a runnable `.exe`.

**Setup:** Windows runner with NSIS installed (`makensis` on PATH).

**Invocation:**
```
anodize release --snapshot --crate <name>
```

**Expected:**
- `dist/windows/<name>-installer.exe` runnable
- Silent install via `<file>.exe /S` completes without UAC prompt (or with correct elevation request)

---

## 5. Split/merge matrix (pro-partial-builds.md, pro-flag-split.md)

**Goal:** exercise `--split` across multiple runners and `--merge` on a coordinator.

**Setup:** GitHub Actions workflow:
```yaml
jobs:
  split:
    strategy:
      matrix:
        include:
          - os: ubuntu-latest
            target: linux
          - os: macos-latest
            target: darwin
          - os: windows-latest
            target: windows
    runs-on: ${{ matrix.os }}
    steps:
      - uses: anodize-action@...
        with:
          args: release --split
          env:
            ANODIZE_OS: ${{ matrix.target }}
      - upload-artifact: dist/

  merge:
    needs: split
    runs-on: ubuntu-latest
    steps:
      - download-artifact: dist/
      - uses: anodize-action@...
        with:
          args: continue --merge
```

**Expected:**
- Each split job produces `dist/<os>/context.json` atomically (no `.tmp` residue)
- Merge loads all three context.jsons and produces a unified `dist/` artifact list
- Deduplication by path never silently drops unique artifacts
- Release is published ONCE from the merge job

**Watch for (WARN from pro-partial-builds.md):**
- Grep the uploaded `context.json` files for any environment-variable secret values (GH_TOKEN, SIGNING_KEY, ...). If found → confirmed env_vars serialization leak.

---

## 6. release.tag template round-trip (pro-release-tag.md)

**Goal:** verify rendered `release.tag` reaches the GitHub API `tag_name` field.

**Setup:** Test repo with tag `v1.2.3`. `.anodize.yaml`:
```
release:
  tag: "{{ .Version }}-custom"
```

**Invocation:**
```
anodize release  # not snapshot — needs real API
```

**Expected:**
- GitHub release created with `tag_name: "1.2.3-custom"` (not `v1.2.3`)
- Verify via `gh release view 1.2.3-custom`

**Rollback:** `gh release delete 1.2.3-custom --yes`

---

## 7. release.header.from_url with private mirror (pro-release-header-footer-from-url.md)

**Goal:** verify authenticated header fetch, retry on 5xx, fast-fail on 4xx.

**Setup:** local wiremock or `python -m http.server` with routes returning 500 x2 then 200.

**.anodize.yaml:**
```
release:
  header:
    from_url: "http://localhost:8080/header-{{ .Tag }}.md"
    headers:
      Authorization: "Bearer {{ .Env.MY_TOKEN }}"
```

**Invocation:** `MY_TOKEN=abc123 anodize release --snapshot`

**Expected:**
- Three HTTP requests (two 500s + one 200) with the Authorization header on each
- Release body contains the fetched content

**Watch for:**
- CRLF injection: if `MY_TOKEN` contains `\r\n`, does reqwest reject or silently send? (SUGGEST in audit).

---

## 8. Cosign full round-trip with keyless (pro-signs-if.md)

**Goal:** sign a checksum with cosign keyless (`--bundle`).

**Setup:** OIDC-enabled CI runner (GHA).

**.anodize.yaml:**
```
signs:
  - cmd: cosign
    signature: "${artifact}.sigstore.json"
    args: ["sign-blob", "--bundle=${signature}", "${artifact}", "--yes"]
    artifacts: checksum
```

**Expected:**
- `dist/checksums.txt.sigstore.json` emitted alongside `dist/checksums.txt`
- `cosign verify-blob --bundle dist/checksums.txt.sigstore.json dist/checksums.txt` succeeds

---

## 9. Monorepo full cycle (pro-monorepo.md)

**Goal:** verify `.Tag` is stripped and `.PrefixedTag` retains the prefix for a monorepo release.

**Setup:** Monorepo with tags `subproject1/v1.2.3`, `.anodize.yaml` with `monorepo: { tag_prefix: "subproject1/" }`.

**Invocation:** `anodize release --snapshot`

**Expected:**
- `.Tag` renders as `v1.2.3`
- `.PrefixedTag` renders as `subproject1/v1.2.3`
- Artifact names use `.Tag` (shorter)
- Release on GH tagged with `.PrefixedTag`

---

## Safety notes

- None of these runs should be initiated by the agent. Hooks will deny.
- After each live run, save logs under `~/.anodize-audit-logs/` for later correlation to audit findings.
- If a finding from the audit is confirmed by a live test, update the corresponding `pro-*.md` file's "CONFIRMED-WORKING" list.
- If a new issue is discovered during live runs, append to `anodize/.claude/known-bugs.md` with file:line citation and test steps.

---

# Wave C addendum — dogfooding live-release wishlist (2026-04-18)

Added by Wave C cycle 2 (`evidence-collector` → this HANDOFF). These clusters are `partial` in `docs/site/content/dogfooding/_index.md` — wired + unit-tested, but no production run proves the end-to-end path. Each flips to ✅ once a live release exercises it. Ordered cheapest-first.

## C-1. Announce providers (13 rows flip with one line)

**What:** 13 announce providers (Twitter/X, Discord, Slack, Teams, Mattermost, Reddit, Telegram, OpenCollective, Mastodon, BlueSky, Webhook, SMTP, LinkedIn) wired + unit-tested in `crates/core/src/announce/`; zero production usage.

**Cheapest flip:** add `announce.webhook:` block to the next cfgd release (`https://httpbin.org/post` works as a smoke target).

**Capture:** release-workflow announce-step log (`POST → 200 OK`) → paste into `evidence-announce.md`, flip cluster to ✅.

## C-2. Downstream package-manager tap PRs

**What:** Homebrew tap PR, Scoop bucket PR, Chocolatey push, Winget manifest PR, Krew plugin.yaml PR, Nix nixpkgs PR. Publishers are wired; cfgd already configures most. No release has captured the downstream URLs yet.

**Cheapest flip:** on the next cfgd release, the anodize publishers already emit these URLs — just capture them into the evidence files.

**Capture:** `homebrew_tap_pr_url`, `scoop_bucket_pr_url`, `chocolatey_push_log`, `winget_manifest_pr_url`, `krew_plugin_pr_url`, `nixpkgs_pr_url` → `evidence-homebrew-cask.md`, `evidence-scoop-chocolatey-winget.md`, `evidence-aur-krew-nix.md`.

## C-3. Docker Hub description sync

**What:** `dockerhub:` block pushes README to Docker Hub via registry API. Wired; never exercised.

**Cheapest flip:** add `dockerhub: { username: …, password: { from_env: DOCKERHUB_TOKEN } }` to a cfgd release. Description-sync runs against existing image metadata — no image publish required.

**Capture:** API PATCH response (logged INFO) → `evidence-docker.md`.

## C-4. macOS notarize

**What:** `notarize.macos` runs `xcrun notarytool submit` + staples. Wired; no production run has exercised Apple notarization.

**Cheapest flip:** enable `notarize.macos` on cfgd darwin binaries for the next release. Requires Apple Developer Program membership + app-specific password.

**Capture:** `notarytool` output (`Status: Accepted`), final stapled binary checksum → `evidence-sbom-snap-flatpak-installers.md` (or carve out `evidence-notarize.md`).

## C-5. GitLab / Gitea release providers

**What:** Alternative release backends for GitLab / self-hosted Gitea. Wired in `crates/core/src/release/{gitlab,gitea}.rs`; no production run.

**Cheapest flip:** mirror `cfgd-core` to a free GitLab instance; run `anodize release` targeting GitLab as the SCM backend (snapshot first, then real).

**Capture:** release URL, asset upload log → `evidence-release-scm.md`.

## C-6. Pro installers (NSIS / DMG / MSI / PKG / AppBundle / Flatpak)

**What:** Six Pro-tier installers. NSIS is lowest-friction (no Apple/Flathub approval, no PKG signing).

**Cheapest flip:** add `nsis:` block to a cfgd release on Windows. Runs `makensis` against a generated `.nsi` template.

**Capture:** `.exe` installer asset URL, `makensis` log → `evidence-sbom-snap-flatpak-installers.md`.

## C-7. `blob` publishing + artifactory/uploads/fury/cloudsmith

**What:** Four object-storage / artifact-hosting publishers: `blob` (S3/GCS/Azure), JFrog Artifactory generic uploads, `fury` (gem.fury.io), Cloudsmith.

**Cheapest flip:** test S3 bucket or free Cloudsmith community plan for one cfgd release.

**Capture:** upload URLs, response logs → `evidence-publish-misc-blob.md`.

---

## Flip procedure (when a live release lands an item)

1. Edit the relevant `evidence-<slug>.md` file — add release run URL, asset URL, or log excerpt as proof.
2. Bump the file's Status line (`Status: partial` → `Status: ✅ proven`).
3. Update `evidence-INDEX.md` — flip the row in the table.
4. Edit `docs/site/content/dogfooding/_index.md` — flip the cluster's status in the appropriate section.
5. `cd /opt/repos/anodize/docs/site && zola check` — confirm no broken links.
6. Commit: `docs: flip <feature> to ✅ — <release-tag> dogfood proof`.

No Wave C re-run needed — manual proof updates are the correct shape here.
