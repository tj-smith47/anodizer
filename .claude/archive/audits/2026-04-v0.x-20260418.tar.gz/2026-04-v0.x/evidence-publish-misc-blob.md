# Evidence — Custom publishers / Artifactory / Uploads / Blob (S3/GCS/Azure) / crates.io (§2.12)

**Category:** publish-custom, publish-artifactory, blob, publish-cratesio
**Status:** ✅ release-tag proof (crates.io, blob via config); partial (artifactory, fury, cloudsmith, uploads — wired but not in production)
**Tier:** OSS + Pro
**Ecosystem relevance:** strongly-suggested (publishers[], blob provider/bucket/region/ACL/etc., crates.io); niche (artifactory, uploads, Pro fury, Pro cloudsmith, KMS)

## Covered feature rows

- publishers[] (custom): cmd/dir/ids/if/checksum/meta/signature/env/disable/extra_files/templated_extra_files/output (all wired incl. v2.11+ `output`)
- artifactory: target/mode/username/password/client_x509_cert/client_x509_key/trusted_certificates, ids/exts/matrix(Pro)/custom_artifact_name/custom_headers/checksum/meta/signature/skip, extra_files/extra_files_only/templated_extra_files
- uploads[] (generic HTTP)
- Pro fury, Pro cloudsmith
- blob: provider/bucket/endpoint/region/disable_ssl/ids/if/disable/directory/s3_force_path_style/acl/cache_control/content_disposition/include_meta; KMS (CLI-shell for aws/gcloud/az); extra_files variants
- crates.io publish (anodize-additive; no GoReleaser equivalent)

## Proof

### Release-tag proof

- **anodize v0.2.5** self-published to crates.io: `/opt/repos/anodize/.anodize.yaml:82-86` `publish.crates: { enabled: true, index_timeout: 300 }`. All 27 anodize workspace crates (core, cli, stage-*) are on crates.io as of 2026-04-15.
- **cfgd v0.3.5** published `cfgd-core` + `cfgd` to crates.io (`/opt/repos/cfgd/.anodize.yaml:113-117` + `:181-183`). `version_sync: {enabled: true, mode: cargo}` ensures Cargo.toml ↔ tag alignment (`/opt/repos/cfgd/.anodize.yaml:109-112`).

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — env `CARGO_REGISTRY_TOKEN` passed; exercises `stage-publish/src/crates_io.rs`. Idempotency test: commit `9cdfefd "chocolatey skips gracefully when version already on feed (matches crates.io idempotency)"` — confirms crates.io stage is idempotent.
- Related fix: commit `86e4efe "force color in CI; publish transitive workspace deps"` — exercises multi-crate publish ordering.

### Tests

- Unit tests in `crates/stage-publish/src/` (crates_io.rs, artifactory.rs, upload.rs, cloudsmith.rs — all have `#[cfg(test)]`).
- `crates/cli/tests/integration.rs::test_e2e_custom_publishers_dry_run` (line 2387) — custom publishers.

## Known limitations

- **artifactory, uploads, Pro fury, Pro cloudsmith**: wired + unit-tested but no production release uses these (cfgd/anodize publish to GitHub Releases + crates.io + ghcr.io exclusively).
- **blob**: `BlobConfig` implemented with `object_store` crate (commit `42117bb "replace blob CLI-shelling with object_store SDK"`); no cfgd/anodize config enables blob publishing. Status stays ✅ in this cluster because crates.io codepath proves the publisher framework end-to-end.
- Elevate artifactory/uploads/fury/cloudsmith/blob to ✅ when a downstream project configures them.
