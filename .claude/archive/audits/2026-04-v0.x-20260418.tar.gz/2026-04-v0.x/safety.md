# Rust safety scan — anodize — 2026-04-v0.x

Scope: `/opt/repos/anodize/crates/`. Complements rust-convention-auditor
(which owns Hard Rules: output routing, unwrap-in-lib, error typing).
This sweep covers panic paths, unsafe, concurrency, Drop/resource safety,
clippy correctness/suspicious/perf, and module-boundary drift.

## Summary
BLOCKER=0  WARN=6  SUGGEST=4

## BLOCKER
_(none)_

## WARN

### Publisher template render panics with user-controlled data
- symptom: `tera.render(...).unwrap_or_else(|e| panic!(...))` in 6 publishers
  treats render as infallible, but Tera rendering CAN fail at runtime when
  user-supplied context values or templated_extra_files inject syntax or
  trigger filter errors. Publisher stage crashes instead of surfacing
  `Result::Err` to the pipeline.
- audit:
  - crates/stage-publish/src/homebrew.rs:389 (cask)
  - crates/stage-publish/src/homebrew.rs:1220 (formula)
  - crates/stage-publish/src/chocolatey.rs:206 (nuspec)
  - crates/stage-publish/src/chocolatey.rs:238 (install script)
  - crates/stage-publish/src/chocolatey.rs:254 (dual install script)
  - crates/stage-publish/src/aur.rs:200 (PKGBUILD)
  - crates/stage-publish/src/aur.rs:279 (.SRCINFO)
- fix sketch: return `Result<String>` from the generators, let callers
  `.with_context("publisher: render X")?` instead of panicking.

### Unsafe env-mutation blocks missing per-block SAFETY comments
- symptom: only the first `unsafe { remove_var(...) }` block has a SAFETY
  comment; the next two reference "see set_env_var_single_threaded" but
  the anti-pattern hook does not parse cross-function comments, and a
  future edit that splits `resolve_force_token` off its caller could
  break the single-threaded invariant silently.
- audit:
  - crates/cli/src/commands/helpers.rs:421 (missing SAFETY block)
  - crates/cli/src/commands/helpers.rs:424 (missing SAFETY block)
- fix sketch: add a SAFETY comment above each `unsafe` block spelling
  out "caller guarantees single-threaded setup" — mirror the pattern at
  line 414-418.

## SUGGEST

### Restate "infallible" justifications on tera parse panics (lib-code)
- symptom: hardcoded-template `add_raw_template(...).unwrap_or_else(|e| panic!(...))`
  is justified only inline as "programmer bug", but the comment style
  varies across publishers, and only `nix.rs:305-306` actually says
  "programmer bug" explicitly. homebrew/chocolatey/aur/winget/scoop use
  the same pattern without that framing, which will invite future
  removal/refactor attempts. Unify on a single justification style or
  extract a `parse_trusted_template(raw: &'static str) -> Tera` helper.
- audit:
  - crates/stage-publish/src/homebrew.rs:304, 949
  - crates/stage-publish/src/chocolatey.rs:148, 231, 245
  - crates/stage-publish/src/aur.rs:121, 231
  - crates/stage-publish/src/winget.rs:281, 461, 468, 475
  - crates/stage-publish/src/krew.rs:146
  - crates/stage-publish/src/scoop.rs:160, 181
- fix sketch: introduce `core::template::parse_static_template(name, raw)`
  with a documented invariant; callers call the helper; no more
  per-publisher panic justifications.

### No `module-boundaries.md` for anodize → Command drift
- symptom: `Command::new` (std + tokio) called across 35 files / 171 sites.
  Without a documented adapter layer there is no mechanical gate to
  prevent future drift (e.g. a non-stage module shelling out to `git`).
  `anodize/.claude/rules/` only carries `anti-patterns.md`.
- audit: 35 files (see grep output). Notably `core/src/git.rs` owns 9
  git invocations; `core/src/hooks.rs` owns 1 hook-runner; the rest are
  stage-local and legitimate.
- fix sketch: write `anodize/.claude/rules/module-boundaries.md` listing
  the allow-list (git.rs, hooks.rs, stage-*/src/lib.rs) and extend the
  post-edit hook to deny `Command::new` in new files outside that set.
  Mirror cfgd's `module-boundaries.md`.

### `clippy::arithmetic_side_effects` would light up ~100+ sites
- symptom: pedantic lint not currently enabled; if ever flipped on, it
  would flag internal counters (`counts.major += 1`), vector indices,
  and git offset math. None are reachable with user-input-derived
  magnitudes, so the lint is pedantic for anodize — mentioning it so
  future `-W clippy::pedantic` rollout is a scoped effort, not a drop-in.
- audit: see `cargo clippy -- -W clippy::arithmetic_side_effects` output
  (examples: crates/cli/src/commands/bump/inference.rs:79-82,
  crates/core/src/template_preprocess.rs:121-1213, crates/core/src/git.rs:235).
- fix sketch: keep the lint disabled; if ever turned on, allow-list
  the internal-counter modules.

### SemaphoreGuard Drop swallows `send` error silently
- symptom: `crates/stage-docker/src/lib.rs:2348` uses `let _ = self.sender.send(())`
  in Drop. If the receiver is dropped before the guard (e.g. main thread
  panics in `std::thread::scope`), the send fails and no token is ever
  returned. In practice thread::scope joins all children before dropping
  `sem_rx`, so the race cannot occur — but the code silently tolerates a
  future refactor that breaks that ordering.
- audit: crates/stage-docker/src/lib.rs:2346-2350
- fix sketch: leave as-is but extend the doc comment on `SemaphoreGuard`
  to cite the thread::scope join-order invariant that makes the error
  unreachable.

## Clippy delta (not covered by rust-convention-auditor)

- `cargo clippy --workspace --all-targets --all-features --no-deps -- -D warnings -W clippy::correctness -W clippy::suspicious -W clippy::perf`: **clean** (0 warnings, 0 errors).
- The project already runs `-D warnings` in CI via the post-edit hook's
  `/verify` suggestion, so the correctness/suspicious/perf tiers add
  nothing new. No delta to report.

## Non-findings (checked and clear)

- `unsafe impl Send/Sync` — zero occurrences.
- `static mut` — zero occurrences.
- `RefCell` — zero occurrences.
- `std::mem::forget` — zero occurrences.
- `std::sync::Mutex` across `.await` — zero occurrences (only stage-release
  uses async, and no `.lock()` crosses an await point in that crate).
- Drop impls — only `SemaphoreGuard` (see SUGGEST above).
- `TempDir` drop ordering — `publisher.rs` correctly uses a named `_tpl_dir_guard`
  binding so the tempdir lives to end of scope, not the always-dropped `_`.
- Non-test `unreachable!/todo!/unimplemented!/panic!` — all remaining
  non-test panics are either (a) hardcoded `http::Uri::parse` of
  `api.github.com` / `uploads.github.com` literals, or (b) static-regex
  initialisers inside `LazyLock::new(…)`, or (c) tera template parse of
  `const` templates. All programmer-bug categories, documented inline.
  The runtime-reachable cases (tera *render* with user data) are listed
  as WARN above.

## Bloat countersign

OSS rows in `bloat.md` (1 candidate: `build.ignore`):

- **build.ignore** — disposition: **keep** (reject remove).
  Independent evidence:
  - wired to `is_target_ignored` (`crates/stage-build/src/lib.rs:588-594, 1570`)
  - surfaced in CLI `targets` command (`crates/cli/src/commands/targets.rs:195`)
  - 4 dedicated tests (`crates/stage-build/src/lib.rs:3298-3335`)
  - documented in `docs/site/content/docs/reference/configuration.md` and
    `docs/site/static/schema.json`
  - removing would break a published user-facing config key for no
    correctness gain; the finder's non-binding "keep + reclassify
    inventory to ecosystem_relevance=niche" is the right call.

No other OSS `disposition=remove` candidates existed to evaluate.
