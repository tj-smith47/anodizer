# Evidence — Announce providers (§2.13)

**Category:** announce-*
**Status:** partial (all 13 providers wired + unit-tested; neither cfgd nor anodize uses announce providers in production)
**Tier:** OSS
**Ecosystem relevance:** strongly-suggested (discord, slack, webhook); niche (telegram, teams, mattermost, smtp, reddit, twitter, mastodon, bluesky, linkedin, opencollective, discourse)

## Covered feature rows

- discord, slack (channel/blocks/attachments), telegram (parse_mode MarkdownV2/HTML + message_thread_id), teams (AdaptiveCard intentional divergence), mattermost, webhook (custom HTTP broadcast), smtp (email), reddit, twitter, mastodon (form-encoded POST), bluesky (AT Proto), linkedin, opencollective, discourse

## Proof

### Release-tag proof

- None — neither anodize nor cfgd configures an `announce:` block. The SMTP_PASSWORD secret is passed to both workflows (`/opt/repos/cfgd/.github/workflows/release.yml`: `SMTP_PASSWORD: ${{ secrets.SMTP_PASSWORD }}`) but no `announce.smtp:` config uses it in the checked-in `.anodize.yaml` snapshots.

### Tests

- Unit tests in `crates/stage-announce/src/` — every provider module (discord, slack, telegram, teams, mattermost, webhook, email, reddit, twitter, mastodon, bluesky, linkedin, opencollective, discourse) has a module + tests.
- Commit `4c6d86c "Session L — config defaults, ANODIZE_FORCE_TOKEN, announce provider parity"` — closed announce provider parity gaps.

## What would elevate to ✅

- Any production release with an `announce:` block exercising at least one provider. The announcer skip memento (commit `1c70bc9 "shared parallelism + skip-memento"`) would visibly list the skipped provider today; configuring even `announce.webhook:` with a test endpoint would prove the wiring end-to-end at release time.
