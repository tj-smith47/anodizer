# Evidence — Docker (§2.7)

**Category:** docker
**Status:** ✅ release-tag proof (via cfgd; anodize itself does not ship docker images)
**Tier:** OSS + Pro
**Ecosystem relevance:** required (image_templates, dockerfile, skip_push, docker_v2, docker_v2.platforms); strongly-suggested (extra_files, use, build_flag_templates, push_flags, retry, docker_manifests, docker_v2.sbom/labels/annotations/build_args); niche (docker v1 deprecated, templated_dockerfile, Pro skip_build, templated_extra_files, dockerdigest, Pro dockerhub description sync)

## Covered feature rows

- dockers[] (v1, deprecated), image_templates, dockerfile, Pro templated_dockerfile, extra_files, Pro templated_extra_files, use (docker/buildx/podman), build_flag_templates, Pro skip_build, skip_push (bool/auto), push_flags, retry (attempts/delay/max_delay)
- docker_v2 pipe, platforms (multi-arch), sbom (inline), labels/annotations, build_args
- docker_manifests, dockerdigest, Pro dockerhub

## Proof

### Release-tag proof

- **cfgd v0.3.5** — https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5 — `docker_v2:` at `/opt/repos/cfgd/.anodize.yaml:243-261` produced ghcr.io/tj-smith47/cfgd:0.3.5 (amd64+arm64, inline SBOM, annotations, build_args VERSION). `docker_manifests:` at :262-270 created multi-arch manifest. `docker_digest:` at :271-272 produced cfgd_v0.3.5.digest.
- anodize itself does not publish docker images (CLI, not service). Feature proof via cfgd only.

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — exercises anodize-action `docker-registry: ghcr.io` + `docker-password` inline QEMU + buildx setup.

### Tests

- crates/cli/tests/integration.rs::test_e2e_docker_staging_dry_run (line 2464)
- Unit tests in crates/stage-docker/src/ (lib.rs has #[cfg(test)])

## Known limitations

- docker v1 (deprecated): implemented but no production config exercises it.
- Pro dockerhub description sync: DockerHubConfig wired; cfgd publishes ghcr.io not Docker Hub — no production proof.
- podman backend: wired; only buildx exercised in CI.
- retry / push_flags / templated_dockerfile / templated_extra_files / Pro skip_build: wired; not exercised in cfgd v0.3.5.
