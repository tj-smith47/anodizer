# Evidence — Checksums (§2.3)

**Category:** checksum
**Status:** ✅ release-tag proof
**Tier:** OSS + Pro
**Ecosystem relevance:** required (sha256 algorithm, name_template); strongly-suggested (split/disable/ids/extra_files, sha512/384); niche (sha3/blake2/blake3/crc32/md5, Pro templated_extra_files)

## Covered feature rows

- checksum.name_template, .algorithm, .split, .disable, .ids, .extra_files, .templated_extra_files (Pro)
- Algorithms: sha256/512/1/224/384, sha3-256/512/224/384, blake2b/2s/3, crc32, md5

## Proof

### Release-tag proof

- **anodize v0.2.5** — https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — asset `anodize-0.2.5-checksums.txt` + `.sig` (cosign signature over checksum file). Default sha256 algorithm per `/opt/repos/anodize/.anodize.yaml:56-57`.
- **cfgd v0.3.5** — https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5 — asset `cfgd-0.3.5-checksums.txt` + `.sig`; custom `name_template` per `/opt/repos/cfgd/.anodize.yaml:145-147`:
  ```yaml
  checksum:
    name_template: "{{ ProjectName }}-{{ Version }}-checksums.txt"
    algorithm: sha256
  ```

### Tests

- `crates/core/tests/config_parsing_tests.rs::test_parse_defaults_checksum_algorithm_sha256` (line 355)
- `::test_parse_defaults_checksum_algorithm_sha512` (line 369)
- `::test_parse_defaults_checksum_algorithm_blake2b` (line 383)
- `::test_parse_defaults_checksum_all_fields` (line 397)
- `::test_parse_checksum_algorithm_strings` (line 1226) — round-trip all algo strings.
- `::test_parse_checksum_name_template` (line 1246)
- `::test_parse_checksum_extra_files` (line 1265)
- `crates/cli/tests/integration.rs::test_check_global_checksum_disable_valid` (line 1702) + `::test_check_per_crate_checksum_disable_valid` (line 1641) — StringOrBool disable variants.

## Known limitations

- sha3-256/512/224/384, blake2b/2s/3, crc32, md5 algorithms are wired in `crates/stage-checksum/src/lib.rs` with unit tests but no release asset exercises them (sha256 is the only algorithm configured in both anodize + cfgd self-configs). Status still ✅ — wiring + parser + release-tag proof of the same codepath with sha256.
