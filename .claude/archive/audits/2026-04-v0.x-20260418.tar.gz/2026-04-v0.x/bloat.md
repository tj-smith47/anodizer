# Bloat candidates — 2026-04-v0.x

Rows from the Parity Row Matrix where `parity_status=implemented` AND
`ecosystem_relevance=not-applicable`. Disposition stays `—` until countersigned
by `rust-safety-scanner` (OSS rows) or `pro-features-skeptic` (Pro rows).

Schema per row:
- **feature** — inventory row name
- **tier** — OSS | Pro
- **audit** — file:line in anodize (evidence of implementation)
- **inventory** — row ref in
  `/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md`
- **finder** — audit agent that flagged the row
- **finder rationale** — why the implementation looks misaligned with
  ecosystem_relevance
- **disposition** — `remove` | `repurpose` | `hide` | `keep` | `—`
- **countersign** — agent that confirmed the disposition (or `—`)

---

## OSS candidates (awaiting `rust-safety-scanner` / A6 countersign)

### build.ignore
- tier: OSS
- audit: `crates/stage-build/src/lib.rs:588-594` (`is_target_ignored`),
  `crates/stage-build/src/lib.rs:1532,1570` (per-build wiring),
  `crates/core/src/config.rs:734-741` (`BuildIgnore` struct)
- inventory: row 57 (scope=go-specific, ecosystem_relevance=not-applicable,
  parity_status=n-a)
- finder: `parity-auditor-build-archive` (A2)
- finder rationale: Inventory marks this Go-specific and `n-a`, but anodize
  ships a full `BuildIgnore { os, arch }` struct wired through the build
  stage. Rust users drive the target matrix with explicit `targets:` lists,
  so `ignore` is redundant — the same exclusion can be expressed by omitting
  the target from `targets:`. The field *does* read more ergonomically for
  users with a large default target list who want to drop one (e.g. the
  global `defaults.targets` scenario).
- disposition: keep
- countersign: rust-safety-scanner — reject remove: wiring reaches `is_target_ignored` (stage-build/src/lib.rs:588-594), surfaces in `targets` CLI (cli/src/commands/targets.rs:195), 4 dedicated tests (stage-build/src/lib.rs:3298-3335), and ships in configuration.md + schema.json; removing would break a user-facing config surface. Re-classify inventory row to `scope=portable, ecosystem_relevance=niche`.
- suggested disposition (non-binding): **keep** — re-classify inventory row
  to `scope=portable, ecosystem_relevance=niche` rather than remove the
  wiring, since `defaults.targets + per-build ignore` is a legitimate
  ergonomic win. Alternative **remove** if the double-spec is considered
  UX bloat.

---

## Pro candidates (awaiting `pro-features-skeptic` / A8 countersign)

_(No Pro bloat candidates from the build + archive slice.)_

---

## Notes

- Rows NOT listed here were either `parity_status=missing`, `ecosystem_relevance ∈
  {required, strongly-suggested, niche}`, or unambiguously Rust-native and
  appropriate.
- Two additional anodize-additive wirings were considered and dismissed as NOT
  bloat:
  - `UniversalBinaryConfig.hooks` + `UniversalBinaryConfig.mod_timestamp` —
    these track upstream `internal/pipe/universalbinary/universalbinary.go:60-73,232-234`
    and are trivial glue.
  - `archives[].binaries:` (anodize extension filter) — flagged as WARN in
    `parity-build-archive.md`, not bloat, because it is not present in
    GoReleaser at all (no parity row to evaluate "applicability" against).
