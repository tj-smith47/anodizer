# Parity Audit — Publishers Slice (Wave A Task A3)

Audited 2026-04-18 by `publishers-auditor` against GoReleaser `HEAD` (commit `f7e73e3`) using the Section 2.8–2.12 rows from `/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md` filtered to `ecosystem_relevance ∈ {required, strongly-suggested}`.

Slice scope: homebrew (formula + cask), scoop, nix, aur, aursources, krew, chocolatey, winget, nfpm (deb/rpm/apk/archlinux/pacman/termux/ipk), docker, docker manifests, blobs (s3/gcs/azureblob), release-scm (github/gitlab/gitea release create), milestones, upload, artifactory, publishers.custom, snapcraft.

Skipped per filter rule (`niche` = informational, `not-applicable` = skipped entirely): telegram/teams/mastodon/etc. are **announcers**, not publishers (routed to Task #4). `fury` / `cloudsmith` / `dockerhub` / `npm` are `niche`; brief spot-checks only. Bloat candidates (implemented rows with `not-applicable` relevance): none observed in publisher slice — see bottom.

Filter stats: 40 required rows, 65 strongly-suggested rows scanned.

---

## BLOCKER

### B1. nfpm passphrase env var name uppercases the format packager
- `audit: crates/stage-nfpm/src/lib.rs:636-637 (goreleaser: internal/pipe/nfpm/nfpm.go:636-637)`
- GoReleaser: `fmt.Sprintf("NFPM_%s_%s_PASSPHRASE", nfpmID, packager)` with `nfpmID` upper-cased via `strings.ToUpper(nfpmID)` on nfpm.go:634, but the packager (`deb`, `rpm`, `apk`, …) stays **lowercase** because it is passed verbatim from the format loop.
- Anodize: `let fmt_upper = fmt.to_uppercase(); format!("NFPM_{id_upper}_{fmt_upper}_PASSPHRASE", …)` — upper-cases both ID and packager, producing e.g. `NFPM_MYID_DEB_PASSPHRASE` instead of GoReleaser's `NFPM_MYID_deb_PASSPHRASE`.
- Impact: env var names are case-sensitive on Unix. A user who migrates a config that relies on `NFPM_MYID_deb_PASSPHRASE` (documented GoReleaser env name) will silently have their passphrase not resolved; signing falls back to level-2 (`NFPM_MYID_PASSPHRASE`) or fails.
- Fix: stop upper-casing the format; keep `NFPM_{ID_UPPER}_{format_lowercase}_PASSPHRASE`.

### B2. Snapcraft default `name_template` does not match GoReleaser
- `audit: crates/stage-snapcraft/src/lib.rs:627-629 (goreleaser: internal/pipe/snapcraft/snapcraft.go:103,120-122)`
- GoReleaser default: `{{ .ProjectName }}_{{ .Version }}_{{ .Os }}_{{ .Arch }}{{ with .Arm }}v{{ . }}{{ end }}{{ with .Mips }}_{{ . }}{{ end }}{{ if not (eq .Amd64 "v1") }}{{ .Amd64 }}{{ end }}` (constant `defaultNameTemplate`, applied in `Default` when empty).
- Anodize: falls back to `format!("{snap_name}_{version}_{arch}.snap")` — missing `_Os`, missing Arm/Mips/Amd64-variant suffixes.
- Impact: snap filename is different from what GoReleaser users expect; breaks any downstream reference to the `.snap` artifact path, and in multi-arch matrices collapses to the same filename across `linux-amd64v3`/`linux-amd64v1` because Amd64 variant is dropped.
- Fix: wire the GoReleaser default into `SnapcraftConfig::name_template` during config resolution (not just use-site), and emit the same template string.

### B3. blob `content_disposition` forces a default GoReleaser never applies
- `audit: crates/stage-blob/src/lib.rs:406-419 (goreleaser: internal/pipe/blob/upload.go:268-291)`
- GoReleaser: `WriterOptions.ContentDisposition = disp` where `disp = tmpl.Apply(conf.ContentDisposition)`. When the user does not set `content_disposition`, `disp` is empty and **no Content-Disposition header is set**.
- Anodize: `let disp_template = ... .unwrap_or("attachment;filename={{Filename}}")` — unconditionally applies `attachment;filename=<name>` when user leaves it blank.
- Impact: breaks in-browser preview (images, PDFs, HTML) for users migrating from GoReleaser who rely on S3 default behavior; changes the HTTP response for every object.
- Fix: only set `attrs.insert(Attribute::ContentDisposition, …)` when the user's `content_disposition` is non-empty. Retain the `"-"` sentinel to disable, but stop synthesizing a default.

### B4. Release body `Checksums` template var is a string, not a map
- `audit: crates/stage-release/src/lib.rs:1085-1098 (goreleaser: internal/pipe/release/body.go:24-44)`
- GoReleaser: when multiple checksum files exist (`checksum.split=true`), `fields["Checksums"]` is a `map[string]string` keyed by `ExtraChecksumOf` (per-artifact name). Single-file case stores the raw string.
- Anodize: always concatenates every checksum file's contents with `"\n"` into a single string. Template code like `{{ range $name, $content := .Checksums }}{{ $name }}: {{ $content }}{{ end }}` from the GoReleaser cookbook silently breaks.
- Impact: release header/footer templates that iterate per-artifact checksums produce no output. Edge case since `split` defaults to false, but the docs promote the map form.
- Fix: expose Checksums as a map when ≥2 checksum artifacts exist; preserve the string form for the single-file case.

---

## WARN

### W1. Docker V1 push retry predicate is far broader than GoReleaser's
- `audit: crates/stage-docker/src/lib.rs:96-120 (goreleaser: internal/pipe/docker/docker.go:389-418)`
- GoReleaser `isRetriablePush` retries **only** on `io.EOF` and HTTP 500/502/503/504/506/510 via exact string match `"received unexpected HTTP status: N <text>"`. Everything else is fatal.
- Anodize `is_retriable_error` also retries on: `"dial tcp"`, `"connection refused"`, `"connection reset"`, `"timeout"`, `"TLS handshake"`, `"i/o timeout"`, `"server misbehaving"`, `"no such host"`, `"REFUSED_STREAM"`, `"registry returned status"`, plus case-insensitive matching.
- Impact: pushes that GoReleaser would fail fast (and surface a real misconfig, e.g. unreachable registry, DNS failure) anodize will sit through 10× retries at exponential backoff (up to 5 m cap) before erroring. Wastes CI time on unrecoverable errors.
- Fix: either narrow the predicate to GoReleaser's set, or document the divergence in the inventory as intentional superiority. Current state is undocumented and contradicts `defaults match` claim in section 2.7.

### W2. Docker `skip_push` template compares case-insensitively
- `audit: crates/stage-docker/src/lib.rs:692-694 (goreleaser: internal/pipe/docker/docker.go:343,346)`
- GoReleaser: `if strings.TrimSpace(skip) == "true"` / `== "auto"` — **exact case**.
- Anodize: `rendered.trim().eq_ignore_ascii_case("true")` in `SkipPushConfig::Template`.
- Impact: a user template that produces `"TRUE"` skips push in anodize but not GoReleaser, and vice versa for `"True"`. Diverging behavior for templated skip values.
- Fix: use exact `== "true"` and `== "auto"` comparisons.

### W3. Docker `use` accepts `podman` as a first-class backend; GoReleaser rejects it
- `audit: crates/stage-docker/src/lib.rs:367-376 (goreleaser: internal/pipe/docker/docker_test.go:1501)`
- GoReleaser: only `{docker, buildx}` are registered imagers. An invalid `use: podman` errors with `invalid use: podman, valid options are [buildx docker]`.
- Anodize: accepts `use: podman` and transparently shells out to `podman build`.
- Impact: intentional superiority (podman is useful for rootless CI), but **undocumented** in the inventory (row `docker.use (docker/buildx/podman)` is marked `implemented` for OSS parity). Deserves a note that this is additive.
- Fix: edit inventory row 2.7 `docker.use` notes to mark `podman` as rust-additive; or drop podman to match GoReleaser strictly.

### W4. Artifactory exposes a generic `ARTIFACTORY_SECRET` fallback GoReleaser does not have
- `audit: crates/stage-publish/src/artifactory.rs:393-397 (goreleaser: internal/http/http.go:168-178)`
- GoReleaser: only per-instance env `ARTIFACTORY_<NAME>_SECRET` / `_USERNAME` (reading from `ctx.Env`, not process env).
- Anodize: per-instance env, plus a generic `ARTIFACTORY_SECRET` fallback that GoReleaser does not support; also reads `std::env::var` (process env) rather than ctx env map.
- Impact: users could set `ARTIFACTORY_SECRET` intending it to be a fallback for one instance and discover it's applied to every instance. Also: `env:` config entries in `.anodize.yaml` that mask the secret at the project layer won't propagate through process env.
- Fix: remove the generic `ARTIFACTORY_SECRET` fallback, or document it in the inventory. Route env lookups through the context env map (same refactor applies to upload.rs).

### W5. Upload env lookup reads process env, not anodize context env
- `audit: crates/stage-publish/src/upload.rs:54-56 (goreleaser: internal/http/http.go:163-164,176-177)`
- GoReleaser reads `ctx.Env[key]` so `env:` blocks + `env_files:` feed the secret resolver.
- Anodize reads `std::env::var` directly for `UPLOAD_<NAME>_USERNAME` and `UPLOAD_<NAME>_SECRET`.
- Impact: same as W4 — `env:` loaded from project YAML or an env file does not reach the uploader. Users documenting secrets in `env:` will find them ignored.
- Fix: route through the context env resolver (same helper used by tmpl).

### W6. nfpm passphrase env lookup reads process env, not anodize context env
- `audit: crates/stage-nfpm/src/lib.rs:638,646,652 (goreleaser: internal/pipe/nfpm/nfpm.go:640)`
- GoReleaser: `if v, ok := ctx.Env[k]; ok` — reads project env map.
- Anodize: `std::env::var(&var)` — reads process env.
- Impact: `NFPM_PASSPHRASE` defined in `.anodize.yaml` `env:` block is invisible to the signer.
- Fix: read via ctx env resolver.

---

## SUGGEST

### S1. Commit author default name/email document the wrong GoReleaser value
- `audit: crates/stage-publish/src/util.rs:670-676 (goreleaser: internal/commitauthor/author.go:11-13)`
- Comments claim "Mirrors GoReleaser's default of \"goreleaser\"" and "\"goreleaser@carlosbecker.com\"".
- Actual GoReleaser defaults: `goreleaserbot` / `bot@goreleaser.com` (author.go:11-13).
- Impact: doc inaccuracy; the anodize defaults (`anodize` / `bot@anodize.dev`) are intentional branding — fine — but the comment misleads future maintainers.
- Fix: update the comment to state "GoReleaser uses `goreleaserbot` / `bot@goreleaser.com`; we use anodize-branded defaults instead."

### S2. Commit author `signing.format` default is not applied on enable
- `audit: crates/stage-publish/src/util.rs:867-884 (goreleaser: internal/commitauthor/author.go:49-52)`
- GoReleaser: when `signing.enabled == true` and `signing.format == ""`, sets `format = "openpgp"` in `Default()`.
- Anodize: sets `-c gpg.format=<value>` only if `fmt.is_some()`; no default.
- Impact: a user with `enabled: true` and no `format:` gets their system's default (`openpgp` for gpg-configured, but could be `ssh` or `x509` on others). GoReleaser users expect `openpgp` regardless.
- Fix: when `signing.enabled == Some(true)` and `format` is None, pass `-c gpg.format=openpgp`.

### S3. AUR `defaults.conflicts` / `defaults.provides` strip `-bin`; GoReleaser uses ProjectName verbatim
- `audit: crates/stage-publish/src/aur.rs:385-398 (goreleaser: internal/pipe/aur/aur.go:58-63)`
- GoReleaser: `pkg.Conflicts = []string{ctx.Config.ProjectName}` and `pkg.Provides = []string{ctx.Config.ProjectName}`.
- Anodize: strips `-bin` suffix from the package name; equivalent in the common case (`ProjectName == stripped package`) but diverges if user sets `Name: foo-bin` with `ProjectName: foo-cli` — GoReleaser emits `conflicts=[foo-cli]`, anodize emits `conflicts=[foo]`.
- Impact: edge case; rarely triggered.
- Fix: use `ctx.Config.project_name` (or the equivalent), not the stripped name.

### S4. Homebrew commit_author defaults are not applied in `Default` pass
- `audit: crates/stage-publish/src/homebrew.rs:786 (goreleaser: internal/pipe/brew/brew.go:77)`
- GoReleaser runs `commitauthor.Default(brew.CommitAuthor)` in its `Default` pipe so subsequent stages see populated name/email and normalized signing format.
- Anodize resolves them lazily inside `resolve_commit_opts`. Functionally equivalent but means that error messages referencing the author field at config-validation time show empty strings.
- Impact: minor; no behavioral break.
- Fix: normalize at config-resolution time or wait until we add a proper Default pass per stage.

### S5. Snapcraft `builds` alias (deprecated) is not accepted
- `audit: crates/stage-snapcraft/src/lib.rs — no reference to "builds" (goreleaser: internal/pipe/snapcraft/snapcraft.go:123-126)`
- GoReleaser accepts legacy `snaps.builds` and folds it into `snaps.ids` with a deprecation notice.
- Anodize: no serde alias; users migrating a `.goreleaser.yaml` with `builds:` will get an unknown-field warning (or be silently dropped if the parser is lenient).
- Impact: config migration papercut.
- Fix: add `#[serde(alias = "builds")]` on `SnapcraftConfig::ids`, or emit a deprecation warning.

### S6. Blob ACL list adds `log-delivery-write` not validated by GoReleaser; missing none from GoReleaser's list
- `audit: crates/stage-blob/src/lib.rs:319-328 (goreleaser: internal/pipe/blob/upload.go:113-119)`
- GoReleaser validates against AWS SDK enum (`ObjectCannedACLPrivate` through `ObjectCannedACLBucketOwnerFullControl`) which excludes `log-delivery-write`.
- Anodize includes `log-delivery-write`.
- Impact: additive; a user can set an ACL GoReleaser would reject. Minor.
- Fix: decide whether to align with AWS SDK or GoReleaser. Document choice in inventory.

### S7. Milestone `Repo` default fallback to git SCM differs
- `audit: crates/cli/src/commands/release/milestones.rs:41 (goreleaser: internal/pipe/milestone/milestone.go:30-41)`
- GoReleaser: when `Repo.Name == ""`, calls `git.ExtractRepoFromConfig(ctx)` and assigns to `milestone.Repo` at `Default` time.
- Anodize: resolves via `resolve_milestone_repo` which reads crate release config or returns empty, then skips with a warning. No `ExtractRepoFromConfig` fallback that parses `.git/config` remote URL.
- Impact: a config with only crates[*].release.github.owner/name will work, but a top-level `milestones:` block without per-crate release config will skip on "repo not configured" where GoReleaser would infer from `git remote`.
- Fix: add an upstream-inferred fallback by parsing the git remote.

### S8. Docker manifest `create_flags` / `push_flags` template rendering scope
- `audit: crates/stage-docker/src/lib.rs:2609 (goreleaser: internal/pipe/docker/manifest.go)`
- Not re-verified end-to-end — flagged for cross-check. Ensure that `create_flags` and `push_flags` lists receive the same `{{ .Tag }}` / `{{ .Env.* }}` template context as the V1 docker path.
- Fix: add a focused test.

### S9. Homebrew `skip_upload` rendered value comparison is stricter than GoReleaser
- `audit: crates/stage-publish/src/homebrew.rs:1242-1259 (goreleaser: internal/pipe/brew/brew.go:143-149)`
- GoReleaser: `strings.TrimSpace(brew.SkipUpload) == "true"` / `== "auto"`.
- Anodize: matches exactly after `trim()`; also logs a warning on unrecognized values. Parity OK but the `unrecognized value` warning is additive. Fine.

### S10. Docker V2 retry predicate diverges from V1 intentionally
- `audit: crates/stage-docker/src/lib.rs:129-133 (goreleaser: internal/pipe/docker/v2/docker.go:544-549)`
- Parity OK — narrow predicate (`manifest verification failed for digest`) matches.

---

## INTENTIONAL (documented superiority, no action)

- **I1. Docker supports `podman` backend** — additive over GoReleaser's `{docker, buildx}`. See W3 — move from WARN to INTENTIONAL once inventory annotates it.
- **I2. Homebrew installs guessed for `UploadableBinary` artifacts** — parity with GoReleaser's `installs()` is preserved.
- **I3. Cask multi-platform `on_macos { on_intel / on_arm }` nesting** — additive vs GoReleaser's flatter cask template; OK because Homebrew Cask supports this since 2024.
- **I4. Blob KMS via CLI shell rather than gocloud.dev** — documented intentional divergence in inventory (row 2.12 `blob KMS`).

---

## Niche — informational only

- **Chocolatey** (`implemented`, `niche`): spot-check not performed. Flag for audit if community adoption grows.
- **Krew** (`implemented`, `niche`): passes commit_msg_template correctly via `kind: "plugin"`.
- **aur_sources[]** (`implemented`, `niche`): same default commit msg as aur (`"Update to {{ .Tag }}"`).
- **dockerhub description sync** (Pro, `niche`): not audited this pass.
- **fury / cloudsmith** (Pro, `niche`): not audited.

---

## Bloat candidates (implemented ∧ not-applicable)

None identified in publisher slice.  `publish-npm` is the only `not-applicable` publisher row (Pro) and is `n-a` in anodize (not implemented). No appends to `bloat.md`.

---

## Counts

- BLOCKER: 4 (nfpm packager casing, snapcraft name_template, blob content_disposition default, release Checksums map)
- WARN:    6 (docker retry breadth, docker skip_push case, docker podman undocumented, artifactory env generic fallback, upload process-env, nfpm process-env)
- SUGGEST: 10
- INTENTIONAL: 4
- Niche: 5 informational
- Bloat candidates: 0

All findings reference exact file:line in both codebases. Every BLOCKER and WARN is actionable and will be tracked in `/opt/repos/anodize/.claude/known-bugs.md` when Task A10 consolidates.
