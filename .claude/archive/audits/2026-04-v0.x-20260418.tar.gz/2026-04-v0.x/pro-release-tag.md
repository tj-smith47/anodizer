# Pro feature: release.tag (templated)

**Docs:** https://goreleaser.com/customization/release/ (fetched 2026-04-18)
**Anodize site:** core/src/config.rs `ReleaseConfig.tag`; crates/stage-release/src/lib.rs uses `tag` as the GH release tag override
**Status:** implemented

## Contract
Pro: `release.tag` is a template rendered to produce the GitHub release tag name. When unset, defaults to the current git tag.

## Contract divergences
- [OK] Config field is present. Rendered at release time.
- [SUGGEST] Verify: if rendered `release.tag` differs from `ctx.git.tag`, does the release correctly use the rendered value in the GitHub API call? Specifically the tag passed to `POST /repos/:owner/:repo/releases`. Failure mode: create a release tagged `v1.2.3-rc1` while the local git tag is `v1.2.3` — if the API call uses the local tag, the release is wrongly named.
- [SUGGEST] Does the rendered tag need to match an EXISTING git tag on the remote? GH requires the tag to exist for `tag_name` to be valid. If `release.tag` produces a template-computed tag with no corresponding git ref, the GH API will create it anyway (for draft/release creation). Verify this behavior is documented / intentional.

## Failure-mode coverage
- Template render error → bubble via `?` when used in release args.

## Idempotency + retry safety
- Re-running `anodize release` with the same `release.tag` template and git state produces the same rendered tag. Idempotent. ✓

## Secret hygiene
No credentials involved.

## Test coverage
- Template rendering tests for `ReleaseConfig.tag` expected in stage-release tests.
- Missing: regression test asserting the GH API call uses the RENDERED tag, not the raw git tag.

## Suggested invariants
1. The GitHub release's `tag_name` field equals the rendered `release.tag` template (or git tag if unset).
2. Every reference to "tag" in downstream announce pipes uses the rendered value (not raw git tag).

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 2 (end-to-end verify rendered tag reaches GH API, document remote-existence requirement)
- CONFIRMED-WORKING: 2 (config field wired, template rendering)

## HANDOFF items
End-to-end: live `anodize release` with `release.tag: "{{ .Version }}-custom"` and verify GH API call. See HANDOFF.md.
