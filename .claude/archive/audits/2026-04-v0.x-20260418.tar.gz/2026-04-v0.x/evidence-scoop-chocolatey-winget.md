# Evidence — Scoop / Chocolatey / Winget (Windows) (§2.10)

**Category:** publish-scoop, publish-chocolatey, publish-winget
**Status:** partial (wired, CI runs, but external tap/pkgs repo state not independently verified by archivist)
**Tier:** OSS
**Ecosystem relevance:** strongly-suggested (scoops[], wingets[]); niche (chocolateys[])

## Covered feature rows

- scoops[], persist/pre_install/post_install/depends/shortcuts, repository.*, use: archive/msi/nsis
- chocolateys[], package_source_url/title/authors/project_url/use, dependencies/api_key/source_repo, require_license_acceptance/license_url/release_notes/summary/description/tags, skip_publish/icon_url/copyright/project_source_url/docs_url/bug_tracker_url
- wingets[], publisher/publisher_url/publisher_support_url/privacy_url, package_identifier/package_name/use/product_code/url_template, path/homepage/description/license_url/copyright/copyright_url/release_notes/installation_notes, dependencies/tags/skip_upload, repository.*/commit_author.*

## Proof

### Release-tag proof

- **cfgd v0.3.5** — all three Windows publishers configured in `/opt/repos/cfgd/.anodize.yaml`:
  - scoop (`:196-200`) → `tj-smith47/scoop-bucket`
  - chocolatey (`:201-211`) → native nupkg push (commit `248c904 "native nupkg (no choco CLI)"`, commit `8ae51f9 "chocolatey push uses multipart/form-data + NuGet UA"`)
  - winget (`:212-220`) → `tj-smith47/winget-pkgs` with package_identifier `TJSmith.cfgd`
- Related assets: `cfgd-0.3.5-windows-amd64.zip` + `-arm64.zip` + `cfgd.exe_windows_amd64.sig` (Windows signing for chocolatey/winget).

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — env `SCOOP_BUCKET_TOKEN`, `CHOCOLATEY_API_KEY`, `WINGET_PKGS_TOKEN` all passed through to release step.
- Fix for winget specifically: commit `5165fc6 "query upstream default_branch for PR base — unblocks winget (master)"` and `248c904 "native nupkg"`.
- Fix for chocolatey idempotency: commit `9cdfefd "chocolatey skips gracefully when version already on feed"`.

### Tests

- Unit tests in `crates/stage-publish/src/scoop.rs`, `chocolatey.rs`, `winget.rs` (all have `#[cfg(test)]` per grep).

## Known limitations

- The archivist cannot observe the downstream tap / pkgs-repo state (scoop-bucket, chocolatey community feed, winget-pkgs). Status stays **partial** until a tap-PR URL / nupkg feed URL is captured in release-run logs. Elevate to ✅ when the next release pins tap-PR URLs in the run output.
- chocolatey `use:` options (archive vs installer) — only default wired in cfgd config.
