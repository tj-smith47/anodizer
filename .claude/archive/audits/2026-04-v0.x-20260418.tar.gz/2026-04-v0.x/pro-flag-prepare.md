# Pro feature: --prepare flag

**Docs:** https://goreleaser.com/pro/ (fetched 2026-04-18)
**Anodize site:** cli/src/commands/release/mod.rs:48,54-60; lib.rs:126
**Status:** implemented

## Contract
Pro: `--prepare` runs local build/archive/sign/checksum/sbom stages but SKIPS release/publish/announce. Artifacts land in `dist/` for operator inspection before the real release. Local-only equivalent to "dry-run but write-files-real."

## Contract divergences
- [OK] mod.rs:54-60 — `apply_prepare_mode_to_skip` pushes `release`, `publish`, `announce` into `skip` if not already there. Idempotent (check at line 56 prevents duplicate push).
- [OK] mod.rs:65-67 — applied BEFORE any stage wiring. Correct ordering.
- [OK] Doc comment at 51-53 declares the intent clearly.
- [SUGGEST] Check: if user passes BOTH `--prepare` and `--skip=publish`, the idempotency logic handles this — but does the exit message reflect the extra-skipped stages? Nice-to-have.
- [SUGGEST] `--prepare` vs `--snapshot`: both suppress release. What if a user passes `--prepare --snapshot`? Should these be mutually exclusive OR do they compose? Currently mod.rs:77-79 validates `--snapshot && --nightly` as incompatible but not `--prepare && --snapshot`. Verify intent.

## Failure-mode coverage
- Build failure → propagate (same as normal release) ✓
- Archive/sign/sbom failure → propagate ✓
- No `release`/`publish`/`announce` ever called → no upstream side effects. ✓

## Idempotency + retry safety
Rerunning `--prepare` overwrites `dist/`. Safe to re-run.

## Secret hygiene
N/A — local only.

## Test coverage
- mod.rs:1018,1033,1049 — unit tests for `apply_prepare_mode_to_skip` covering empty/preserves-user/idempotent ✓
- Missing: end-to-end test asserting no network call to GH happens under `--prepare` mode.

## Suggested invariants
1. With `--prepare`, NO network I/O to release targets (GH API, docker push, etc.) occurs.
2. `dist/` contains all artifacts a real release would produce, minus the publication side effects.
3. `apply_prepare_mode_to_skip` is idempotent — double-invocation is a no-op.

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 2 (validate --prepare/--snapshot composition, end-to-end no-network assertion)
- CONFIRMED-WORKING: 4 (skip list augmentation, pre-wiring ordering, idempotent, unit tests)
