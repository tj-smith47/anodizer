# Pro feature: release.header.from_url / from_file and release.footer.from_url / from_file

**Docs:** https://goreleaser.com/customization/release/ (fetched 2026-04-18)
**Anodize site:** core/src/config.rs:1376 (`ContentSource::FromUrl { from_url, headers }`); crates/stage-release/src/lib.rs:607-700 (`resolve_content_source`)
**Status:** implemented

## Contract
`release.header` / `release.footer` accept:
- inline string
- `{ from_file: <path> }` — file path (templated) is read
- `{ from_url: <url>, headers: { <K>: <V>, ... } }` — HTTP GET with optional auth headers

Body is template-rendered after resolution.

## Contract divergences
- [OK] lib.rs:618-622 — `resolve_content_source` dispatches on `ContentSource` enum. All three variants covered.
- [OK] lib.rs:625-629 — `from_file` path is template-rendered, then read; file read errors bubble with context.
- [OK] lib.rs:631-712 — `from_url`: URL and header values template-rendered (keys are literal per docs, line 636).
- [OK] lib.rs:647-712 — retry loop: 3 attempts, 500ms * 2^n backoff (500ms / 1s / 2s). Retries on network errors + 5xx; fast-fail on 4xx. GoReleaser docs don't specify retry; this is anodize-additive but sensible.
- [OK] lib.rs:647-649 — `reqwest::blocking::Client` with 30s timeout. Reasonable default.
- [SUGGEST] lib.rs:660-663 — headers are set via `req.header(k.as_str(), v.as_str())`. If `v` contains a CRLF, this could enable header injection. `reqwest` MAY reject such values but behavior depends on version. Consider validating no `\r` or `\n` in rendered header values before calling `.header()`. Why it matters: if a user uses `{{ .Env.AUTH }}` and the env var is attacker-controlled in a CI pipeline with mixed secrets, this becomes a surface.
- [SUGGEST] lib.rs:668 — `response.text()?` has no explicit size limit. A hostile/broken URL could return gigabytes of body, exhausting memory. Consider `bytes_limit` or at least a `Content-Length` check.

## Failure-mode coverage
- 4xx: bail immediately with HTTP code in error ✓
- 5xx: retry per loop, fail with "HTTP 5xx (attempt N/3)" ✓
- Network error: retry per loop ✓
- All retries exhausted: `last_err` returned via `bail!` (not shown in snippet but implied at lib.rs:712+) ✓
- Timeout: 30s per attempt, total ~36s worst-case ✓
- Template render error on URL or headers: bubble via `with_context` ✓

## Idempotency + retry safety
- `from_url` fetches content each run; if the URL serves changing content, the release body varies. This is the user's contract — acceptable.
- No caching; re-running is idempotent in the sense of "same URL = same HTTP call pattern."

## Secret hygiene
- Header values like `Authorization: Bearer <token>` are rendered at call time. Values are passed via `req.header`, never logged. ✓
- If the HTTP call fails with the URL in the error, the URL may include a query-string secret — bail message at lib.rs:671-675 prints the URL verbatim. Consider redacting URL query strings or using `url.path()` only.
- The `rendered_headers` vec stores secrets in memory until `resolve_content_source` returns. Not persisted.

## Test coverage
- `test_resolve_content_source_from_file` lib.rs:4557 ✓
- `test_resolve_content_source_from_file_not_found` 4571 ✓
- `test_resolve_content_source_from_file_path_is_template_rendered` 4582 ✓
- `test_content_source_from_url_with_headers_parses` 4601 — parser test only, not fetch
- Missing: live HTTP integration test with `wiremock` or similar — retry logic, 4xx fast-fail, 5xx retry-and-eventually-fail, header propagation
- Missing: URL-bail-error redaction regression test (if SUGGEST 2 is addressed)

## Suggested invariants
1. Every `from_url` HTTP request that is reported as success → response body is non-empty (or explicit empty allowed by docs — check).
2. Any `?` error path for URL fetch never logs the URL if it contains query-string secrets (SUGGEST above).
3. Rendered header values contain no CRLF (SUGGEST above).

## Findings summary
- BLOCKER: 0
- WARN: 0
- SUGGEST: 3 (CRLF validation in header values, response body size limit, URL redaction in error messages)
- CONFIRMED-WORKING: 6 (file read, URL fetch, template rendering of URL+headers+file-path, retry logic, 4xx fast-fail, timeout)

## Blocker status for A10
None. All three SUGGEST items are hardening, not correctness.
