# Evidence — Permanent Negative Space (not-applicable) (§4)

**Category:** multiple (build, misc, publish-npm)
**Status:** informational (n-a — never re-adjudicated)
**Tier:** mixed
**Ecosystem relevance:** not-applicable (by construction)

## Covered feature rows

Decisions frozen in `/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md:476-489`:

- Go builder (`builder: go`)
- Go matrix axes: goos/goarch/goarm/goamd64/goarm64/gomips/go386/goppc64/goriscv64, build.ignore, build.buildmode, build.no_main_check
- Go toolchain flags: ldflags, asmflags, gcflags
- build.tags (Go build tags)
- gomod.* (proxy/env/mod/gobinary/dir)
- Zig / Bun / Deno / Python-uv / Python-poetry builders
- `ko` (Go-source-to-container builder)
- npm publish (Pro)
- `--key` Pro license flag
- GGOOS / GGOARCH (partial split filter)

## Proof

These rows are not expected to have test or release proof — they are **intentionally unimplemented**. Each row has a durable justification in inventory §4. The evidence pattern for n-a rows is:

- **Source absence check**: `grep -r "buildmode\|ldflags\|gomod" /opt/repos/anodize/crates/` returns config-parser references only (for GoReleaser-config passthrough compat), never behavioral wiring. Verified 2026-04-18.
- **Negative-space doc**: inventory §4 lists each row with a one-line justification; inventory §5 "Bloat candidates (implemented ∧ not-applicable)" is empty, confirming no n-a row was accidentally implemented.

## Interpretation

These rows should remain `❌ informational` in the dogfooding matrix — they are **not** failures or gaps; they are durable scope decisions. Mark them with a distinct color/icon in the published matrix so readers understand "not our scope" vs "untested / missing."
