# Evidence — anodize-action inputs / outputs / caching / steps (action-layer inventory §1-§5)

**Category:** action (wrapper layer)
**Status:** ✅ release-tag proof (for required inputs/outputs); partial for semver-range/nightly (documented missing)
**Tier:** action wrapper (OSS)
**Ecosystem relevance:** required (GITHUB_TOKEN, artifacts, metadata, args, workdir, install-only, version); strongly-suggested (rest of 19 inputs, 5 outputs, composite steps); niche (semver-range resolution, nightly channel)

## Covered feature rows (anodize-action)

- Inputs: version, args, workdir, install-only, from-artifact, artifact-run-id, artifact-workflow, from-source, install-rust, install (deps CSV), auto-install, resolve-workspace, docker-registry, docker-username, docker-password, upload-dist, download-dist, gpg-private-key, cosign-key
- Outputs: artifacts, metadata, release-url, workspace, crate-path, has-builds, split-matrix
- Composite steps: platform detection, version resolution, download release asset (3-attempt curl retry), install from workflow artifact (auto run-id resolver), bootstrap build from source, dep installer, retry wrapper (3-attempt), GPG/cosign key import
- Caching: `${RUNNER_TOOL_CACHE}/anodize/${version}` (+ `/source` / `/artifact` subpaths — partial)
- Distribution: composite action (not Node) — intentional divergence from goreleaser-action

## Proof

### Release-tag proof

- **anodize v0.2.5** — built through anodize-action (`/opt/repos/anodize/.github/workflows/release.yml:48-60` uses `tj-smith47/anodize-action@master`).
  - `from-artifact: anodize-linux` + `artifact-run-id: auto` + `artifact-workflow: ci.yml` exercised → Linux build reuses CI artifact (proves `from-artifact` + `auto` run-id resolver).
  - `from-source: true` + `install-rust: false` exercised on macOS/Windows build matrix (proves `from-source` bootstrap).
  - `install: zig,cargo-zigbuild,upx` exercised (proves dep installer composite step).
  - `args: release --split --clean` (Pro partial build flag + --clean).
  - Merge job uses `args: release --merge`, `install: nfpm,makeself,snapcraft,rpmbuild,cosign`, `gpg-private-key: ${{ secrets.GPG_PRIVATE_KEY }}` (proves GPG import step) — `/opt/repos/anodize/.github/workflows/release.yml:115-125`.
- **cfgd v0.3.5** — `/opt/repos/cfgd/.github/workflows/release.yml:99-118` uses `tj-smith47/anodize-action@master`:
  - `resolve-workspace: 'true'` + `install-only: 'true'` (resolve job, proves monorepo resolver + install-only short-circuit).
  - Build job: `from-artifact: ${{ matrix.anodize_artifact }}` + `install: zig,cargo-zigbuild,upx` + `upload-dist: 'true'` + `args: release --verbose --debug --strict --split --clean --crate ...` — exercises upload-dist.
  - Release job: `download-dist: ${{ needs.resolve.outputs.has-builds }}` + `docker-registry: ghcr.io` + `docker-password: ${{ secrets.GITHUB_TOKEN }}` — exercises inline QEMU + buildx + registry login.
- Release outputs proven by the asset list at release tier: `artifacts` (from dist/artifacts.json) and `metadata` (from dist/metadata.json).

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — end-to-end exercise of 15+ action inputs in one workflow.
- cfgd release.yml run 24442229349 (core-v0.3.5) — library-only path, exercises `has-builds: false` conditional skip.

### Tests

- Composite action is tested only via production workflow runs; `/opt/repos/anodize-action/scripts/install-deps.sh` is the dep-installer entrypoint (per Action inventory §2 item "auto-install").
- anodize-action has no Rust tests — it's a composite YAML action.

## Known limitations

- **semver-range version input** (`version: ~> v0.1`): missing per Action inventory §4 item "Version range resolution". Users migrating from goreleaser-action may silently get no install.
- **Nightly channel** (`version: nightly`): missing; upstream CLI doesn't ship nightly releases yet.
- **auto-install grep patterns**: miss `pkgs:` / `msis:` / `nsis:` / `dmgs:` / `appbundles:` / `flatpaks:` (Action inventory §6 item 5) — per-format installer tooling (productbuild/wixl/makensis/hdiutil) requires manual `install:` specification today.
- **Cache subpath drift**: `.../source` vs `.../artifact` vs `.../{version}` caches don't inter-share — partial per action inventory §4 item "Cache key shape".
