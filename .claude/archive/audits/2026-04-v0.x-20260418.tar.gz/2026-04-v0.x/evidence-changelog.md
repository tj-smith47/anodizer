# Evidence — Changelog (§2.5)

**Category:** changelog
**Status:** ✅ release-tag proof
**Tier:** OSS + Pro
**Ecosystem relevance:** required (disable, use, sort, filters, groups.title/regexp/order); strongly-suggested (format, abbrev); niche (Pro paths/title/divider/nested groups/ai backends)

## Covered feature rows

- changelog.disable (StringOrBool), use (git/github/gitlab/gitea/github-native), format, sort, abbrev, filters.include/exclude, groups[].title/regexp/order
- Pro: paths (monorepo filter), title, divider, nested groups[].groups[], ai.use/model/prompt (Anthropic/OpenAI/Ollama backends)

## Proof

### Release-tag proof

- **anodize v0.2.5** body — https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — visible changelog body is grouped: `### Features`, `### Bug Fixes`, `### Others` (evidence of `changelog.groups` with regex + order). "Others" title is a Pro nested-group test case. The body has full commit-SHA-prefixed bullets (evidence of `abbrev: 0` default + full SHA prefix).
- **cfgd v0.3.5** — same body shape; changelog generated against monorepo `crates/cfgd/` path (Pro `changelog.paths` monorepo filter applied).

### CI workflow runs

- cfgd release.yml run 24442230191 — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — produces per-workspace changelog using branch_history: full (`/opt/repos/cfgd/.anodize.yaml:32-37`).

### Tests

- `crates/cli/tests/integration.rs::test_e2e_changelog_with_groups` (line 1964) — groups + regex.
- `crates/cli/tests/integration.rs::test_e2e_changelog_header_footer` (line 3091).
- `crates/cli/tests/integration.rs::test_e2e_changelog_exclude_filters` (line 3188).
- `crates/cli/tests/integration.rs::test_check_changelog_disabled_valid` (line 1734) — StringOrBool disable.

## Known limitations

- **AI backends (Anthropic / OpenAI / Ollama)**: wired in `crates/stage-changelog/` but no production release uses AI summarisation — no cfgd/anodize config sets `changelog.ai.use`. Wiring proof is parser-side only.
- **github-native / gitlab / gitea providers**: only `git` provider exercised in production (both projects). Others wired but unrun at release tier.
