# Evidence — Release / SCM (§2.4)

**Category:** release
**Status:** ✅ release-tag proof
**Tier:** OSS + Pro
**Ecosystem relevance:** required (github provider, draft, name_template, prerelease, make_latest, header/footer, target_commitish, extra_files, replace_existing_*); strongly-suggested (gitlab, URLs, skip_upload/disable); niche (gitea, discussion_category_name, Pro tag/templated_extra_files/header_from_url/footer_from_url, include_meta, milestones)

## Covered feature rows

- release.github, .gitlab, .gitea, draft, replace_existing_draft, use_existing_draft, replace_existing_artifacts, target_commitish, Pro tag template, discussion_category_name, prerelease (auto/bool), make_latest, mode (keep-existing/append/prepend/replace), header/footer (string + Pro from_url/from_file), name_template, disable, skip_upload, extra_files, Pro templated_extra_files, include_meta
- github_urls.api/upload/download/skip_tls_verify, gitlab_urls.*, gitea_urls.*
- milestone pipe

## Proof

### Release-tag proof

- **anodize v0.2.5** — https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — published release (not draft), `make_latest` set (latest badge visible), `name_template` → "anodize v0.2.5", `include_meta: true` (asset `metadata.json` attached), footer "Released with [anodize]". GitHub provider (owner/name auto-detected from git remote).
- **cfgd v0.3.5** — https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5 — `release.github: {owner: tj-smith47, name: cfgd}` (`/opt/repos/cfgd/.anodize.yaml:163-170`), `draft: false`, `prerelease: auto`, `make_latest: auto`, footer template literal, `include_meta: true`.
- **cfgd core-v0.3.5 / operator-v0.3.5 / csi-v0.3.5** — per-workspace GitHub releases from same run; exercises workspace → release mapping.

### CI workflow runs

- cfgd release.yml run 24442230191 (tag v0.3.5) — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — creates GitHub release, uploads 40+ assets, idempotent size-match check (fix #86faad2 in anodize).
- cfgd release.yml run 24442229349 (tag core-v0.3.5) — library-only path.

### Tests

- `crates/cli/tests/integration.rs::test_e2e_full_dry_run_all_stages` (line 2668) — exercises release stage path.
- `crates/cli/tests/integration.rs::test_e2e_snapshot_release_produces_artifacts` (line 632) — release name template + draft artifact enumeration.

## Known limitations

- **GitLab + Gitea providers**: wired in `crates/stage-release/src/gitlab.rs` and `crates/stage-release/src/gitea.rs` with unit tests but no release tag has exercised them (neither anodize nor cfgd publish to GitLab/Gitea). Status stays ✅ at the category level because code path is complete; note this gap for live-release proof.
- **Pro header/footer from_url**: `ContentSource::FromUrl` is implemented per `/opt/repos/anodize/.claude/specs/goreleaser-complete-feature-inventory.md:135-136` but no release config uses `from_url` at the release level (metadata.full_description.from_url is the explicit partial per §5).
- **discussion_category_name / replace_existing_draft / use_existing_draft**: wired but not exercised in v0.2.5/cfgd v0.3.5 configs.
