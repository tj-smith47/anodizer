# Evidence — Archives + Source (§2.2)

**Category:** archive, source
**Status:** ✅ release-tag proof
**Tier:** OSS + Pro
**Ecosystem relevance:** required (id/formats/name_template/files/format_overrides); strongly-suggested (wrap_in_directory/builds_info); niche (Pro hooks, templated_files, meta, strip_binary_directory, allow_different_binary_count, source.templated_files)

## Covered feature rows

- archives[].id/ids, format (singular + plural), meta, name_template, wrap_in_directory, strip_binary_directory, allow_different_binary_count, files (string/object), builds_info, format_overrides, Pro hooks before/after (serde-aliased), Pro templated_files
- formats: tar.gz/tgz, tar.xz/txz, tar.zst/tzst, tar, gz, zip, binary, none
- source archive, source.templated_files (Pro)

## Proof

### Release-tag proof

- **anodize v0.2.5** — https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — assets include `anodize-0.2.5-linux-amd64.tar.gz`, `anodize-0.2.5-windows-amd64.zip`, `anodize-0.2.5-source.tar.gz` — tar.gz (Linux/macOS) + zip (Windows format_override) + source archive. Self-config at `/opt/repos/anodize/.anodize.yaml:50-54`:
  ```yaml
  archives:
    format: tar.gz
    format_overrides:
      - os: windows
        format: zip
  ```
- **cfgd v0.3.5** — https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5 — same shape (`cfgd-0.3.5-linux-amd64.tar.gz` / `cfgd-0.3.5-windows-amd64.zip`) plus per-crate archives override with `name_template` (`/opt/repos/cfgd/.anodize.yaml:136-142`) including LICENSE + README.md.

### CI workflow runs

- cfgd release.yml run 24442230191 (tag v0.3.5) — https://github.com/tj-smith47/cfgd/actions/runs/24442230191 — produces the tar.gz/zip/source.tar.gz assets visible in the release.

### Tests

- `crates/cli/tests/integration.rs::test_e2e_multi_format_archive` (line 1770) — asserts multiple archive formats produced in one run.
- `crates/cli/tests/integration.rs::test_e2e_cross_platform_format_overrides_check` (line 2538) — `format_overrides` per-OS.
- `crates/cli/tests/integration.rs::test_e2e_skip_archive_and_checksum` (line 2310) — archive skip path.
- `crates/core/tests/config_parsing_tests.rs::test_parse_archives_accepts_deprecated_builds_alias` (line 326) — legacy alias.
- `crates/core/tests/config_parsing_tests.rs` archive block (lines 842-1224) — 20+ parser tests: binaries, format tar_gz/zip/tar_xz, format_overrides, files glob, wrap_in_directory, null/array/empty.

## Known limitations

- Pro `templated_files` coverage is parser-only in tests; wiring lives in `crates/stage-archive/src/lib.rs` and ran in v0.2.5 release (inferred from produced assets).
- `formats: none` path is wired but not independently exercised in v0.2.5 (no config uses it).
